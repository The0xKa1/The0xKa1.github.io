"""python -m projects.digits.cli --download --epochs 5 --output outputs/mnist-cnn"""
from pathlib import Path
import argparse
import json
from common.runtime import load_functions,json_default
from .dataset import download
from .experiment import train,final_test,checkpoint_bytes


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--download',action='store_true');parser.add_argument('--epochs',type=int,default=5)
    parser.add_argument('--device',default='auto',choices=['auto','cpu','mps','cuda'])
    parser.add_argument('--limit',type=int,default=None,help='仅用于快速调试的训练样本数；省略则使用完整 54000 张')
    parser.add_argument('--mode',choices=['演示','练习'],default='演示')
    parser.add_argument('--test',action='store_true',help='完成训练后评价官方测试集')
    parser.add_argument('--output',type=Path,default=Path('outputs/mnist-cnn'))
    args=parser.parse_args()
    if args.download:download(progress=lambda f,n:print(n,flush=True))
    def progress(f,message,rows):print(message,flush=True)
    result=train(load_functions('digits',args.mode),epochs=args.epochs,device=args.device,limit=args.limit,progress=progress)
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.with_suffix('.pt').write_bytes(checkpoint_bytes(result))
    report=dict(config=result['config'],metrics=result['metrics'],curves=result['curves'])
    if args.test:
        final=final_test(result);report['test_accuracy']=final['accuracy']
        final['samples'].to_csv(args.output.with_suffix('.test.csv'),index=False)
    args.output.with_suffix('.json').write_text(json.dumps(report,default=json_default,ensure_ascii=False,indent=2))
    print(json.dumps(report,default=json_default,ensure_ascii=False),flush=True)


if __name__=='__main__':main()
