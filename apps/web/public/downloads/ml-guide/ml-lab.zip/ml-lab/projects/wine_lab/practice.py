"""各题独立调用读者函数，不用其他题的参考答案补位。"""
import re
from pathlib import Path
import numpy as np
import pandas as pd
import streamlit as st
from common.data import wine_split
from common.checks import check_project
from common.runtime import fingerprint,load_functions
from common.ui import error

TASKS={
'wine_classification': {
 'split_data': ('划出验证样本','输入 X、y 和 seed；返回 X_train、X_valid、y_train、y_valid。验证占 25%，保持类别比例与行索引。相同种子应得到相同划分。','142 行开发数据应得到 106 行训练、36 行验证，互不重叠。','先划出样本再训练，不能在拆分前拟合标准化。','train_test_split(..., test_size=.25, stratify=y, random_state=seed)'),
 'build_model': ('组装分类器','返回未拟合的 StandardScaler → LogisticRegression 管道。C 为正数；只在 fit 时学习缩放参数。','小例子的三类训练点相隔较远；运行后应能给每个点一个类别。','把缩放与分类放进同一个管道，防止预测时重新拟合缩放。','make_pipeline(StandardScaler(), LogisticRegression(C=C, max_iter=2000))'),
 'evaluate': ('找出分类错题','返回 accuracy、matrix、wrong。matrix 固定 3×3，wrong 是错分位置的一维整数数组，不是原表行编号。','[0,1,2] 与 [0,2,2]：accuracy=2/3，wrong=[1]；矩阵第 1 行第 2 列为 1（下标从 0 开始）。','逐位置比较，混淆矩阵行是真实类别、列是预测类别。','np.flatnonzero；confusion_matrix(..., labels=[0,1,2])'),
 'compare_depths': ('进阶：树深对照','每个深度重新训练一棵树，返回 depth、train_accuracy、valid_accuracy 三列 DataFrame。','深度 [1,2,4] 对应三行；记录训练和验证成绩，不用训练分数替代验证分数。','不要在一个深度训练完后只改参数、不重新 fit。','DecisionTreeClassifier(max_depth=depth, random_state=seed)')},
'wine_regression': {
 'split_target': ('把答案从输入移走','返回 X、y；y 是 alcohol 列，X 不含 alcohol，保留并对齐索引，不改原表。','142 行 → X 为 142×12，y 长度 142。','预测酒精含量时，不能把酒精含量本身当输入。','data.drop(columns="alcohol")；data["alcohol"]'),
 'errors': ('手算预测误差','返回 mae 浮点数与 residuals 一维数组。残差是实测减预测，MAE 是绝对残差的均值。','实测 [1,3]，预测 [2,2]：残差 [-1,1]，MAE=1；负残差表示高估。','不要先把残差平均，否则正负可能抵消。','np.asarray(actual)-np.asarray(predicted)；np.abs(residuals).mean()'),
 'build_model': ('组装岭回归','返回未拟合的 StandardScaler → Ridge 管道，alpha 非负。','在固定小数据上 fit 后，应返回与输入样本数相同的数值预测。','alpha 越大，系数的惩罚越强；必须把缩放放在每一折的管道里。','make_pipeline(StandardScaler(), Ridge(alpha=alpha))'),
 'select_alpha': ('用验证误差选参数','输入表含 alpha 与 valid_mae，返回最小验证误差对应的 alpha。并列时取表中第一项。','alpha=[.1,1,10]，valid_mae=[.4,.2,.2] → 1。','看 valid_mae，不能用训练误差或测试误差选。','idxmin() 找行索引，再用 loc 取该行的 alpha。')},
'clustering': {
 'distances': ('计算离中心多远','输入 N×D 样本与 K×D 中心，返回 N×K 欧氏距离平方矩阵。','X=[[0,0],[3,4]]，中心=[[0,0],[3,4]] → [[0,25],[25,0]]。','沿特征维求平方和，不开根号。','X[:,None,:] - centers[None,:,:]'),
 'assign_groups': ('把样本交给最近中心','输入距离平方矩阵，每行返回最近中心编号；平局选编号较小者。','[[1,4],[9,0],[2,2]] → [0,1,0]。','输出长度等于样本数，不是中心数。','argmin(axis=1)'),
 'update_centers': ('移动到组内平均位置','返回与 old_centers 同形状的新数组；空簇保留旧中心，不修改输入。','[[0,0],[2,0],[8,0]]，groups=[0,0,1]，旧中心=[[0,0],[9,0],[20,0]] → [[1,0],[8,0],[20,0]]。','先复制旧中心，只更新有样本的组。','X[groups==i].mean(axis=0)'),
 'converged': ('判断是否可以停止','每个中心的欧氏移动距离都 <= tolerance 才返回 True；不是距离平方。','中心 [0,0] 移到 [.03,.04]，距离 .05；阈值 .05 时返回 True。','不能只看一个中心，也不能让不同方向的移动抵消。','np.linalg.norm(new-old,axis=1)'),
 'best_restart': ('进阶：选初始中心','返回多次初始化中最终组内距离平方和最小者的位置。','[12,7,9] → 1，不是 7。','不同起点可能停在不同分组，多跑几次再选。','np.argmin(inertias)')}
}


def fixture(project,name,value):
    dev,_,target,_=wine_split()
    if project=='wine_classification':
        if name=='split_data':
            def compute(fn):
                a,b,ya,yb=fn.split_data(dev,target,int(value))
                return dict(训练行数=len(a),验证行数=len(b),重叠样本数=len(set(a.index)&set(b.index)),训练类别数量=ya.value_counts(),验证类别数量=yb.value_counts())
            return '固定开发集（142 行），验证比例 25%',compute
        if name=='build_model':
            X=np.array([[0,0],[0,.1],[2,2],[2,2.1],[4,4],[4,4.1]])
            return 'X=[[0,0],[0,.1],[2,2],[2,2.1],[4,4],[4,4.1]]；y=[0,0,1,1,2,2]',lambda fn:fn.build_model(value).fit(X,[0,0,1,1,2,2]).predict(X)
        if name=='evaluate':
            return '[0,1,2] 与 [0,2,2]',lambda fn:fn.evaluate(np.array([0,1,2]),np.array([0,2,2]))
        # 已提供独立划分，本题不依赖读者的 split_data。
        from sklearn.model_selection import train_test_split
        a,b,ya,yb=train_test_split(dev,target,test_size=.25,stratify=target,random_state=42)
        return '已提供的训练/验证数据，深度 [1,2,4]',lambda fn:fn.compare_depths(a,ya,b,yb,[1,2,4],42)
    if project=='wine_regression':
        if name=='split_target':
            def compute(fn):
                X,y=fn.split_target(dev.copy())
                return dict(输入形状=X.shape,目标长度=len(y),输入是否还含答案='alcohol' in X.columns,索引是否对齐=X.index.equals(y.index),目标前五行=y.head())
            return '142 行开发集成分表',compute
        if name=='errors': return '[1,3] 与 [2,2]',lambda fn:fn.errors([1,3],[2,2])
        if name=='build_model':
            return 'X=[[0],[1],[2],[3]]；y=[0,2,4,6]',lambda fn:fn.build_model(value).fit([[0],[1],[2],[3]],[0,2,4,6]).predict([[0],[1],[2],[3]])
        frame=pd.DataFrame({'alpha':[.1,1.,10.],'valid_mae':[.4,.2,.2]})
        return frame,lambda fn:fn.select_alpha(frame.copy())
    if name=='distances':return 'X=centers=[[0,0],[3,4]]',lambda fn:fn.distances(np.array([[0.,0.],[3.,4.]]),np.array([[0.,0.],[3.,4.]]))
    if name=='assign_groups':return '[[1,4],[9,0],[2,2]]',lambda fn:fn.assign_groups(np.array([[1.,4.],[9.,0.],[2.,2.]]))
    if name=='update_centers':return 'X=[[0,0],[2,0],[8,0]]；groups=[0,0,1]；old=[[0,0],[9,0],[20,0]]',lambda fn:fn.update_centers(np.array([[0.,0.],[2.,0.],[8.,0.]]),np.array([0,0,1]),np.array([[0.,0.],[9.,0.],[20.,0.]]))
    if name=='converged':return 'old=[[0,0]]；new=[[.03,.04]]；tolerance=.05',lambda fn:fn.converged(np.array([[0.,0.]]),np.array([[.03,.04]]),.05)
    return '[12,7,9]',lambda fn:fn.best_restart([12.,7.,9.])



def stage_lesson(stage):
    """各阶段先解释问题与方法，接口和代码提示随后展开。"""
    content = Path(__file__).with_name('README.md').read_text(encoding='utf-8')
    sections = re.split(r'^## ([0-6])\. .*$', content, flags=re.M)
    lessons = dict(zip(sections[1::2], sections[2::2]))
    st.markdown(lessons[str(stage)])
