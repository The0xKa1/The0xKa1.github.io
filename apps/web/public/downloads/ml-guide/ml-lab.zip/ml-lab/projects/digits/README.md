# 数字识别

坤坤录入样品编号时，有个数字看着像 3，又像 8。他找来现成的手写数字图片，训练一个小网络，想看看程序会不会也认错。训练结束后，先把错题单独列出来，再逐张查看预测概率。

## 挑一张错题看看

基础环境可以先跑 scikit-learn。装好 PyTorch 后，再补全网络和训练步骤，观察训练曲线。错题墙里的“3 → 8”表示真实数字 3 被认成了 8。选择样本后加一点噪声，或者把图像水平移动，看看预测有没有变化；空出的位置补零，右侧像素不会绕回左侧。

## 填写函数

### `normalize`

原始像素在 0 到 16 之间。把它们缩放到 0 到 1，再将每张图展平为 64 维。

<details><summary>可用的接口</summary>

reshape(-1,64).astype("float32") / 16；先检查形状、范围与有限性。

</details>

### `build_network`

隐藏层使用 ReLU，输出层给出 10 个类别得分。

<details><summary>可用的接口</summary>

nn.Sequential(nn.Linear(64,hidden), nn.ReLU(), nn.Linear(hidden,10))。

</details>

### `train_step`

每个批次开始时先清掉旧梯度。前向计算得到损失后，反向传播，再让优化器更新参数。

<details><summary>可用的接口</summary>

optimizer.zero_grad() → model(x) → cross_entropy → backward() → optimizer.step()。

</details>

### `evaluate`

评价时切到评估模式，关闭梯度计算。返回各类概率，以及概率最大的类别。

<details><summary>可用的接口</summary>

model.eval() 与 torch.no_grad()；softmax(dim=1)，再转 numpy。

</details>

## 接着试什么

固定数据划分和种子，每次只改隐藏层宽度、学习率或训练轮数中的一项，保存结果并比较验证曲线。配置确定后再打开测试结果。TensorFlow 提供完整的接口对照，需要时再安装，不必同时准备三个框架。

保存 `exercises.py`，点“检查练习”后切到练习模式运行。遇到未完成的函数，页面会显示名称；检查失败会列出输入和预期结果。实验记录可以下载，建议给每次比较写一两句解释。参考实现见 `solutions/digits.py`。
