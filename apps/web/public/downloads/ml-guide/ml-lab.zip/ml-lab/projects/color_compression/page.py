import hashlib
from pathlib import Path
import numpy as np
import pandas as pd
import plotly.express as px
import streamlit as st
from PIL import Image
from common.charts import chart
from common.image_ui import show_image
from common.ui import run_panel
from .experiment import fit, rebuild, measure, run, png_bytes
from .workshop import lesson, check, trial, swatches, region, compare


def render(mode):
    st.markdown('<style>@media(max-width:1000px){[class*="st-key-color_comparison_"] [data-testid="stHorizontalBlock"]{flex-direction:column;}[class*="st-key-color_comparison_"] [data-testid="stColumn"]{width:100%!important;flex:1 1 100%!important;}}</style>',unsafe_allow_html=True)
    tabs = st.tabs(['0 · 只留几种颜色', '1 · 替换像素', '2 · 自动挑颜色', '3 · 看哪里失真', '4 · 选颜色并导出'])
    with tabs[0]:
        lesson(0)
        upload = st.file_uploader('换成自己的图片（PNG / JPG）', type=['png','jpg','jpeg'], key='palette_upload')
        source = upload or Path(__file__).parents[1]/'image_lab/assets/fruit-photo.jpg'
        with Image.open(source) as photo:
            photo = photo.convert('RGB'); photo.thumbnail((192,192))
            image = np.asarray(photo, dtype=float)/255
        digest = hashlib.sha256(image.tobytes()).hexdigest()
        show_image(image, '原始照片', 'color_source')
        st.caption(f'工作图为 {image.shape[1]} × {image.shape[0]} 像素，后续比较都使用这个分辨率。默认照片：George Chernilevsky，公共领域；来源见 image_lab/assets/README.md。')
        count = st.select_slider('手选调色板颜色数', [2,4,8], value=4, key='color_manual_count')
        defaults = ['#253322','#e9ce91','#a84425','#eeeeea','#5e2055','#849344','#eda62a','#745444']
        columns = st.columns(4)
        hexes = [columns[i%4].color_picker(f'颜色 {i}', defaults[i], key=f'color_manual_{i}') for i in range(count)]
        manual = np.array([[int(c[j:j+2],16)/255 for j in (1,3,5)] for c in hexes])
        st.caption('这些色块会作为第 1 阶段的输入。可以先用默认配色，再根据重建结果调整。')
    with tabs[1]:
        lesson(1); check('reconstruct')
        kind = st.radio('使用哪组颜色', ['黑白两色','第 0 阶段手选颜色'], key='color_palette_kind')
        palette = np.array([[0.,0,0],[1.,1,1]]) if kind == '黑白两色' else manual
        swatches(palette, 'color_given')
        reconstructed = trial('reconstruct', '用当前函数替换整张图的像素', mode,
                              dict(image=digest,palette=palette.tolist()), lambda fn: rebuild(fn,image,palette))
        if reconstructed is not None:
            compare([image,reconstructed], ['原图','当前函数重建'], 'color_manual_compare')
            area, (row,col) = region(image,digest,'color_pixel')
            compare([image[area],reconstructed[area]], ['选区原图','选区重建'], 'color_pixel_crop')
            distances = ((palette-image[row,col])**2).sum(axis=1)
            st.write(f'选区左上角像素：行 {row}，列 {col}；RGB = {image[row,col].round(4).tolist()}。')
            st.dataframe(pd.DataFrame({'颜色编号':range(len(palette)), 'RGB':palette.round(4).tolist(), 'RGB 平方距离':distances}), hide_index=True)
            st.write(f'最近颜色编号：{int(distances.argmin())}；函数返回颜色：{reconstructed[row,col].round(4).tolist()}。')
            if not np.isclose(((reconstructed[row,col]-image[row,col])**2).sum(), distances.min()):
                st.warning('这个像素没有使用最近颜色，请检查距离计算与 argmin 的轴。')
    with tabs[2]:
        lesson(2); check('fit_palette')
        colors = st.select_slider('自动调色板颜色数', [2,4,8,16,32], value=8, key='color_k')
        seed = st.number_input('抽样与聚类种子', 0, 9999, 42, key='color_seed')
        params = dict(image=digest,colors=colors,seed=seed)
        learned = trial('fit', '找出调色板', mode, params, lambda fn: fit(fn,image,colors,seed))
        if learned is not None:
            swatches(learned,'color_learned')
            automatic = trial('automatic','用自动调色板重建',mode,dict(**params,palette=learned.tolist()),lambda fn: rebuild(fn,image,learned))
            if automatic is not None:
                compare([image,automatic],['原图','自动调色板重建'],'color_auto_compare')
                if reconstructed is not None:
                    compare([reconstructed,automatic],[f'第 1 阶段：{len(palette)} 色',f'自动挑选：{colors} 色'],'color_methods')
                    st.caption('比较挑色方法时，请把两边颜色数量设为相同。')
        else: automatic = None
    with tabs[3]:
        lesson(3); check('mse')
        value = trial('hand_mse','运行小数组 MSE',mode,{},lambda fn: measure(fn,np.zeros((1,2,3)),np.array([[[0.,0,0],[1.,1,1]]])))
        if value is not None:
            st.write(f'函数返回 {value:g}；手算：(0 + 0 + 0 + 1 + 1 + 1) ÷ 6 = 0.5。')
            if not np.isclose(value,.5): st.warning('请对全部像素和全部通道取平均。')
        target = st.radio('检查哪张重建图',['第 1 阶段重建','第 2 阶段自动重建'],key='color_error_source')
        compressed = reconstructed if target == '第 1 阶段重建' else automatic
        if compressed is None:
            st.info('所选阶段还没有有效重建结果。小数组练习可以独立运行。')
        else:
            result_digest = hashlib.sha256(compressed.tobytes()).hexdigest()
            score = trial('photo_mse','计算这张图的 MSE',mode,dict(image=digest,result=result_digest),lambda fn: measure(fn,image,compressed))
            if score is not None:
                st.metric('当前函数 MSE',f'{score:.6f}')
                expected = float(np.mean((image-compressed)**2))
                if not np.isclose(score,expected): st.warning(f'与逐像素核对值 {expected:.6f} 不一致，请检查 mse。')
            heat = ((image-compressed)**2).mean(axis=2)
            chart(px.imshow(heat,zmin=0,zmax=1,color_continuous_scale='magma').update_layout(title='逐像素通道均方误差（固定 0–1）',height=330),key='color_heat')
            area,_ = region(image,digest,'color_error_region')
            compare([image[area],compressed[area]],['选区原图','选区重建'],'color_error_crop')
            st.caption('热图由像素差直接计算，用来核对自己的 mse；不会替代函数返回值。')
    with tabs[4]:
        lesson(4)
        st.caption(f'比较 2、4、8、16、32 色；共用当前照片和种子 {seed}。计算仅在点击按钮后执行。')
        result = run_panel('color_compression',mode,params,lambda fn:run(fn,image,colors,seed))
        if result is not None:
            chosen = st.select_slider('选择要保留的版本',list(result['variants']),value=colors,key='color_export_k')
            final = result['variants'][chosen]
            compare([image,final],['原图',f'{chosen} 色重建'],'color_final')
            swatches(result['palettes'][chosen],'color_final_palette')
            area,_ = region(image,digest,'color_final_region')
            compare([image[area],result['variants'][2][area],final[area]],['原图局部','2 色局部',f'{chosen} 色局部'],'color_final_crop')
            chart(px.line(result['curve'],x='colors',y='mse',markers=True).update_xaxes(title='颜色数').update_yaxes(title='MSE',rangemode='tozero'),key='color_curve')
            row = result['curve'].set_index('colors').loc[chosen]
            original_bytes, output = png_bytes(image), png_bytes(final)
            a,b,c = st.columns(3)
            a.metric('MSE',f'{row.mse:.6f}')
            b.metric('理论存储缩小倍数',f'{row.theoretical_ratio:.2f}×')
            c.metric('下载 PNG 大小',f'{len(output):,} 字节')
            st.caption(f'同尺寸原图编码为 RGB PNG：{len(original_bytes):,} 字节；重建图：{len(output):,} 字节。两者使用相同编码设置。理论值按 24 bit RGB 与颜色索引加调色板比较，不含文件头；下载文件仍为 RGB PNG。')
            st.dataframe(result['curve'].rename(columns=dict(colors='颜色数',mse='MSE',theoretical_ratio='理论倍数',png_bytes='PNG 字节')),hide_index=True)
            note = st.text_area('记录你的选择：哪些细节保住了，哪些颜色合并了？',key='color_note')
            st.download_button('下载重建图片 PNG',output,'palette.png','image/png')
            st.download_button('下载比较表 CSV',result['curve'].to_csv(index=False).encode('utf-8-sig'),'palette-comparison.csv','text/csv')
            st.download_button('下载选择说明',f'颜色数：{chosen}\nMSE：{row.mse:.6f}\n说明：{note}\n','palette-choice.txt','text/plain')
