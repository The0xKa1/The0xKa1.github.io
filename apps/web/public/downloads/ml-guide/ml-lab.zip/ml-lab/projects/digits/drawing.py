"""280×280 continuous handwriting canvas; sent pixels are raw grayscale 0–255."""
import numpy as np
import streamlit.components.v2 as components

JS=r'''
export default function({data,parentElement,setStateValue}){
 const canvas=parentElement.querySelector('canvas'),ctx=canvas.getContext('2d'),status=parentElement.querySelector('[role="status"]');
 canvas.width=280;canvas.height=280;
 const im=ctx.createImageData(280,280);
 for(let i=0;i<78400;i++){im.data[4*i]=im.data[4*i+1]=im.data[4*i+2]=data.pixels[i];im.data[4*i+3]=255;}
 ctx.putImageData(im,0,0);let down=false,last=null;
 const point=e=>{let r=canvas.getBoundingClientRect();return [(e.clientX-r.left)*280/r.width,(e.clientY-r.top)*280/r.height];};
 const stroke=(a,b)=>{ctx.strokeStyle=data.erase?'black':'white';ctx.fillStyle=ctx.strokeStyle;ctx.lineWidth=data.width;ctx.lineCap='round';ctx.lineJoin='round';ctx.beginPath();ctx.moveTo(...a);ctx.lineTo(...b);ctx.stroke();ctx.beginPath();ctx.arc(...b,data.width/2,0,Math.PI*2);ctx.fill();};
 const send=()=>{let bytes=ctx.getImageData(0,0,280,280).data;let values=Array.from({length:78400},(_,i)=>bytes[4*i]);setStateValue('pixels',values);status.textContent='笔迹已保存，可以识别。';};
 canvas.onpointerdown=e=>{if(e.button!==0)return;e.preventDefault();canvas.setPointerCapture(e.pointerId);down=true;last=point(e);stroke(last,last);};
 canvas.onpointermove=e=>{if(!down)return;let next=point(e);stroke(last,next);last=next;};
 canvas.onpointerup=e=>{if(!down)return;stroke(last,point(e));down=false;canvas.releasePointerCapture(e.pointerId);send();};
 canvas.onpointercancel=()=>{down=false;send();};
 status.textContent=data.pixels.some(v=>v>25)?'笔迹已保存，可以识别。':'在黑色区域写一个数字；鼠标或触摸均可。';
 return()=>{canvas.onpointerdown=canvas.onpointermove=canvas.onpointerup=canvas.onpointercancel=null;};
}
'''


def validate_pixels(pixels):
    a=np.asarray(pixels,dtype=np.float32)
    if a.size!=280*280 or not np.isfinite(a).all() or np.any((a<0)|(a>255)):raise ValueError('画板需要 280×280 个 0–255 像素')
    return a.reshape(280,280).astype(np.uint8)


def drawing(pixels,key,erase=False,width=18):
    component=components.component('mnist_handwriting_canvas',html='<canvas role="img" aria-label="MNIST连续手写画板"></canvas><p role="status" aria-live="polite"></p>',css='canvas{display:block;width:280px;max-width:100%;height:auto;touch-action:none;cursor:crosshair;border:1px solid #888;border-radius:8px}p{font:inherit}',js=JS)
    flat=validate_pixels(pixels).ravel().tolist()
    event=component(key=key,data=dict(pixels=flat,erase=erase,width=width),default={'pixels':flat},on_pixels_change=lambda:None)
    return validate_pixels(event.pixels)
