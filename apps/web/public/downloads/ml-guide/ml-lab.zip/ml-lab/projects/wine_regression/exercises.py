"""在这里完成练习。参考实现位于 solutions/，页面不会自动代填。"""
import numpy as np
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge


def split_target(data):
    """把酒精含量作为要预测的答案，从输入特征中移走。
    
    为什么做：如果把 alcohol 同时放进输入和答案，模型就能直接“看到答案”，
    这种数据泄漏会让分数虚高。回归任务要用其他检测指标预测它。
    输入：data 为包含 alcohol 列的 pandas DataFrame (N, D)。
    输出：二元组 (X, y)，X 为去掉 alcohol 的 DataFrame (N, D-1)，
        y 为该列的 Series (N,)，每项是对应酒样的实测酒精含量。
    要求：保留原行索引和剩余列顺序，不修改 data；不在此划分训练/验证集。
    例子：列为 [alcohol, malic_acid, ash] 时，X 只含后两列，y 保存 alcohol。
    """
    # TODO 1: 取出 alcohol 列作为目标 y，并复制以避免共享修改。
    # TODO 2: 生成不含 alcohol 的特征表 X，按 (X, y) 顺序返回。
    raise NotImplementedError('split_target')


def errors(actual, predicted):
    """计算平均绝对误差，并保留每个样本的误差方向。
    
    为什么做：MAE 告诉我们平均偏差多大；带符号的残差则能区分预测偏高或偏低。
    输入：actual、predicted 为等长、非空的一维数值数组或列表，形状 (N,)，
        相同位置对应同一样本，数值单位一致。
    输出：字典 {'mae': Python float, 'residuals': NumPy 数组 (N,)}。
    要求：残差 = 实测值 - 预测值；MAE 是所有残差绝对值的均值。
        正残差表示预测偏低，负残差表示预测偏高；不平方，不改变输入或样本顺序。
    例子：实测 [1, 3]、预测 [2, 2] → 残差 [-1, 1]、mae=1.0。
    """
    # TODO 1: 将输入转换为数组，按“实测减预测”计算每个样本的残差。
    # TODO 2: 对残差取绝对值再平均，将均值转为 float，连同原始残差返回。
    raise NotImplementedError('errors')


def build_model(alpha=1.0):
    """建立标准化与岭回归组成的预测管道。
    
    为什么做：岭回归在拟合数值的同时约束系数大小，减少对训练样本的过度适应。
    特征先标准化，能避免不同单位影响这种约束。
    输入：alpha 为非负正则化系数，默认 1.0；数值越大，对系数的约束越强。
    输出：尚未拟合的 sklearn Pipeline，顺序为 StandardScaler → Ridge。
    要求：把 alpha 传给 Ridge，不在本函数内 fit；缩放参数只在后续训练时学习。
        不使用验证或测试数据计算均值、标准差。
    例子：返回的管道可用 fit(X_train, y_train) 学习，再用 predict 输出酒精含量。
    """
    # TODO 1: 创建 StandardScaler 和使用指定 alpha 的 Ridge。
    # TODO 2: 按先缩放、后回归的顺序组装管道并返回。
    raise NotImplementedError('build_model')


def select_alpha(results):
    """进阶：根据验证误差挑选正则化系数。
    
    为什么做：超参数需要用未参与训练的数据比较；测试集应留到最终评价，
    不能反复用来挑设置。本题只读取已经汇总好的验证结果。
    输入：非空 DataFrame results，含 alpha、valid_mae 两列；
        每行是一个候选系数及其有限验证误差，行索引唯一但不保证从零连续。
    输出：Python float，表示验证 MAE 最小的那一行的 alpha。
    要求：误差并列时选表中首先出现的一行；不返回行号、最小误差或整个模型。
        不修改结果表，不访问测试集。
    例子：alpha=[.1, 1, 10]、valid_mae=[.4, .3, .3] 时返回 1.0。
    """
    # TODO 1: 找出 valid_mae 最小值首次出现的那一行，注意标签索引与行位置的区别。
    # TODO 2: 读取这一行的 alpha，转换成 Python float 后返回。
    raise NotImplementedError('select_alpha')
