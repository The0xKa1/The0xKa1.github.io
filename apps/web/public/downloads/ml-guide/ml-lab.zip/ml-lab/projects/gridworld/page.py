import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st
from common.charts import chart
from common.ui import run_panel, error
from common.runtime import load_functions
from .experiment import run, parse_map, rollout, evaluate, ALGORITHMS
from .board import editor, playback


def render(mode):
    st.write('把样品从起点送到检测台。先自己走，再把选择动作、记住经验和探索策略交给小车。各阶段可以单独尝试。')
    with st.expander('地图编辑器', expanded=False):
        text = editor()
    manual, explore, learn, train, challenge = st.tabs(['0 · 自己送一次', '1 · 让小车探索', '2 · 记住这一步', '3 · 学会送达', '4 · 算法与大地图'])
    from .workshop import trip_panel, action_lab, update_lab, exercise_check, stage_lesson
    with manual:
        stage_lesson(0)
        st.subheader('现在自己走一次')
        trip_panel(text, mode, 'manual')
    with explore:
        stage_lesson(1)
        action_lab(mode)
        st.subheader('把 choose_action 接到小车上')
        trip_panel(text, mode, 'explore')
    with learn:
        stage_lesson(2)
        update_lab(mode)
        st.subheader('你选方向，小车更新一个 Q 值')
        trip_panel(text, mode, 'learn')
    with train:
        stage_lesson(3)
        exercise_check('exploration_rate', '检查第 3 题：探索率')
        outcome = training(mode, text)
    with challenge:
        stage_lesson(4)
        exercise_check('sarsa_update', '检查第 4 题：SARSA 更新')
        exercise_check('expected_sarsa_update', '检查第 5 题：Expected SARSA 更新')
        st.caption('在上方编辑地图，到第 0 页手动试走，再到第 3 页训练。这里比较三种算法，沿用第 3 页的地图与训练参数。')
        if outcome is None:
            st.info('先到第 3 页运行一次实验，再来做多地图对照。')
        else:
            benchmark(mode, *outcome)



def training(mode, text):
    c1, c2 = st.columns(2)
    episodes = c1.select_slider('训练回合', [10, 100, 500, 2000, 5000, 10000, 20000], value=2000)
    algorithm = st.selectbox('学习算法', list(ALGORITHMS), key='grid_algorithm')
    seed = c2.number_input('随机种子', min_value=0, max_value=9999, value=42)
    strategy = st.radio('探索策略', ['衰减', '固定'], horizontal=True)
    epsilon = st.slider('固定探索率', 0., 1., .1, step=.05, disabled=strategy != '固定')
    a, b, c = st.columns(3)
    alpha = a.number_input('学习率 α', .01, 1., .2, .01)
    gamma = b.number_input('折扣率 γ', 0., 1., .95, .01)
    max_steps = c.number_input('每回合步数上限', 1, 2000, min(2000, max(200, parse_map(text)[0].size*4)))
    params = dict(text=text, episodes=episodes, seed=seed, strategy=strategy, epsilon=epsilon,
                  alpha=alpha, gamma=gamma, max_steps=max_steps, algorithm=algorithm)
    status = st.empty()
    def compute(fn):
        return run(fn, **params, progress=lambda n, total: status.progress(n/total, text=f'训练 {n} / {total} 回合'))
    st.caption('每次运行从零 Q 表开始。到达终点才终止；用尽步数属于截断，更新仍保留未来价值。')
    result = run_panel('gridworld', mode, params, compute)
    if result is None:
        return
    metrics = result['metrics']
    cols = st.columns(3)
    cols[0].metric('最终贪心策略', '送达' if metrics['success'] else '未送达')
    cols[1].metric('路径步数', metrics['steps']); cols[2].metric('最短步数', metrics['shortest'])
    checkpoint = st.select_slider('回放训练阶段 / 回合', sorted(result['snapshots']), value=max(result['snapshots']))
    q = result['snapshots'][checkpoint]
    kind = st.radio('回放路线', ['贪心评价', '这一回合的探索轨迹'], horizontal=True)
    if kind == '这一回合的探索轨迹' and checkpoint in result['traces']:
        path, records, success = result['traces'][checkpoint]
    else:
        path, records, success = rollout(result['grid'], result['start'], result['goal'], q, seed+1, result['config']['max_steps'])
        if kind != '贪心评价':
            st.caption('第 0 回合还没有走过路线，这里显示初始 Q 表对应的贪心路线。')
    grid = result['grid']
    st.subheader('送样路线回放')
    playback(grid, result['start'], result['goal'], path, records)
    st.subheader('策略与动作价值')
    values = q.max(axis=2).copy(); values[grid == '#'] = np.nan
    lower = min(-20., min(float(v.min()) for v in result['snapshots'].values()))
    upper = max(10., max(float(v.max()) for v in result['snapshots'].values()))
    heat = go.Figure(go.Heatmap(z=values, colorscale='Cividis', zmin=lower, zmax=upper, colorbar=dict(title='最大 Q 值'), hovertemplate='行 %{y}，列 %{x}<br>Q=%{z:.2f}<extra></extra>'))
    heat.add_trace(go.Heatmap(z=np.where(grid == '#', 1., np.nan), colorscale=[[0, '#64748b'], [1, '#64748b']], showscale=False, hoverinfo='skip'))
    for row in range(grid.shape[0]):
        for col in range(grid.shape[1]):
            if grid.size > 256:
                continue
            if grid[row, col] == '#':
                label = ''
            elif (row, col) == result['goal']:
                label = '终点'
            else:
                choices = np.flatnonzero(q[row, col] == q[row, col].max())
                label = ''.join('↑→↓←'[a] for a in choices)
            heat.add_annotation(x=col, y=row, text=label, showarrow=False, font=dict(color='#111', size=17), bgcolor='rgba(255,255,255,0.8)')
    heat.update_yaxes(range=[grid.shape[0]-.5,-.5], dtick=1, scaleanchor='x', scaleratio=1, constrain='domain', title='行'); heat.update_xaxes(range=[-.5,grid.shape[1]-.5], dtick=1, constrain='domain', title='列')
    event = chart(heat, key='grid_q', select=True)
    cells = [(r, c) for r in range(grid.shape[0]) for c in range(grid.shape[1]) if grid[r, c] != '#']
    cell = st.selectbox('查看格子 (行, 列)', cells)
    if event.selection.points:
        point = event.selection.points[0]
        selected = (int(point['y']), int(point['x']))
        if selected in cells:
            cell = selected
    st.dataframe(pd.DataFrame({'动作': list('上右下左'), 'Q 值': q[cell]}), hide_index=True)
    if grid.size > 256:
        st.caption('大地图用热图显示价值，不逐格叠加箭头。点击格子或用下拉菜单查看四个动作的 Q 值。')
    st.caption(f'同一格里有多个箭头，说明这些动作的 Q 值并列最大。各训练阶段共用 {lower:.1f} 到 {upper:.1f} 的色阶。')
    chart(px.line(result['curve'], x='episode', y='reward', labels=dict(episode='回合', reward='回合奖励')))
    chart(px.line(result['curve'], x='episode', y='success_rate', labels=dict(episode='回合', success_rate='最近 50 回合成功率')).update_yaxes(range=[0, 1]))
    fig = px.line(result['curve'], x='episode', y='mean_steps', labels=dict(episode='回合', mean_steps='最近 50 回合平均步数'))
    fig.add_hline(y=metrics['shortest'], line_dash='dash', annotation_text='BFS 最短距离')
    chart(fig)
    return result, episodes, epsilon


def benchmark(mode, result, episodes, epsilon):
    st.write('在当前编辑地图上比较 Q-learning、SARSA 和 Expected SARSA。每种算法都从零开始，用相同的三个训练种子、参数和回合预算；最后分别关闭探索评价 30 回合。')
    st.caption('大地图可能需要较长训练时间；先用少量回合检查流程，再提高预算。没有送达的运行也保留在结果中。')
    if st.button('比较三种算法 × 三个种子', key='grid_compare'):
        st.session_state.pop('grid_comparison', None)
        try:
            fn = load_functions('gridworld', mode)
            rows, curves, models = [], [], {}
            status = st.progress(0.)
            for index, algorithm in enumerate(ALGORITHMS):
                for seed in [0, 1, 2]:
                    config = dict(result['config'], algorithm=algorithm, seed=seed)
                    r = run(fn, **config, progress=lambda n, total: status.progress((index*3+seed+n/total)/9,
                            text=f'{algorithm} · 种子 {seed} · {n}/{total} 回合'))
                    ev = evaluate(r, episodes=30)
                    rows.append(dict(algorithm=algorithm, seed=seed, **ev['metrics']))
                    curve = r['curve'][['episode', 'success_rate']].copy()
                    curve['algorithm'], curve['seed'] = algorithm, str(seed)
                    curves.append(curve)
                    models[(algorithm, seed)] = (r, ev)
            st.session_state['grid_comparison'] = (result['_signature'], pd.DataFrame(rows), pd.concat(curves), models)
        except Exception as exc:
            error(exc)
    saved = st.session_state.get('grid_comparison')
    if not saved or saved[0] != result['_signature']:
        return
    table = saved[1]
    st.dataframe(table, hide_index=True)
    st.caption('success_rate：成功率；mean_steps：含失败的平均步数；mean_reward：平均回报；mean_collisions：平均碰撞；truncation_rate：截断率；success_path_ratio：只统计成功路径的步数 / BFS 最短步数。无成功回合时路径比留空。')
    st.dataframe(table.groupby('algorithm')[['success_rate', 'mean_steps', 'success_path_ratio']].agg(['mean', 'std']))
    st.caption('均值与标准差来自三个训练种子，标准差使用 ddof=1。同地图固定起点的重复评价不代表跨地图泛化。')
    chart(px.line(saved[2], x='episode', y='success_rate', color='algorithm', line_dash='seed',
                  labels=dict(episode='训练回合', success_rate='最近 50 回合成功率', algorithm='算法', seed='种子')))
    choice = st.selectbox('对照路线', list(saved[3]), format_func=lambda pair: f'{pair[0]} · 种子 {pair[1]}')
    model, evaluation = saved[3][choice]
    trial = st.selectbox('回放评价回合', range(30), format_func=lambda i: f"第 {i+1} 回合 · {'成功' if evaluation['trajectories'][i][2] else '截断'}")
    path, records, _ = evaluation['trajectories'][trial]
    playback(model['grid'], model['start'], model['goal'], path, records)
    st.download_button('下载算法比较 CSV', table.to_csv(index=False).encode('utf-8-sig'), 'grid-algorithms.csv', 'text/csv')
