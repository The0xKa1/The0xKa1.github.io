import numpy as np
from sklearn.ensemble import IsolationForest

def fit_detector(X, seed=42):
    """输入是 N×2 的正常历史记录，两列分别对应温度和重量。用这些训练数据拟合 IsolationForest，再返回模型。"""
    raise NotImplementedError('fit_detector')

def flag_anomalies(scores, threshold):
    """这里的分数越大，表示越异常。分数大于或等于阈值时标为 True，最后返回布尔数组。"""
    raise NotImplementedError('flag_anomalies')

def evaluate(actual, flagged):
    """输入真实异常标签和报警结果，二者都是布尔数组。计算 precision 和 recall；某项指标的分母为零时，该项返回 0。"""
    raise NotImplementedError('evaluate')
