"""在这里完成练习。参考实现位于 solutions/，页面不会自动代填。"""
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, confusion_matrix
from sklearn.tree import DecisionTreeClassifier


def split_data(X, y, seed=42):
    """把开发数据分成用于学习的训练集和用于比较模型的验证集。
    
    为什么做：在学过的数据上评分可能过于乐观，需要留出未参与训练的样本。
    分层划分让两部分尽量保持原来的类别比例，避免某类样本过少。
    输入：X 为 pandas DataFrame (N, D)，每行一瓶酒、每列一个特征；
        y 为对应的 pandas Series (N,)，标签为 0、1、2，索引与 X 对齐；
        seed 为固定随机种子。传入的是开发集，不包含独立测试集。
    输出：依次返回 X_train, X_valid, y_train, y_valid，保持 pandas 类型和原索引。
    要求：使用 train_test_split，test_size=0.25、stratify=y、random_state=seed；
        训练约占 75%，验证约占 25%，具体数量按库的取整规则确定。
        两部分不能重叠或丢失样本；特征和标签必须成对划分，不重置索引。
    例子：原样本索引是 37，划分后它仍使用 37，方便回查同一瓶酒。
    """
    # TODO 1: 把 X、y 一起传入划分函数，指定验证比例、分层标签和随机种子。
    # TODO 2: 按约定顺序返回四个结果；不要先单独打乱 X 或 y。
    raise NotImplementedError('split_data')


def build_model(C=1.0):
    """建立“标准化后再分类”的训练管道。
    
    为什么做：不同检测指标的单位和量级不同。StandardScaler 学习每列的
    均值与标准差，逻辑回归再学习类别边界；管道让训练与预测使用同一套缩放。
    输入：C 为正数，默认 1.0，是正则化强度的倒数；C 越小约束越强。
    输出：未拟合的 sklearn Pipeline，包含 StandardScaler → LogisticRegression。
    要求：逻辑回归使用传入的 C，并设置 max_iter=2000；此处不调用 fit。
        后续 fit 只能接收训练集；不能提前用验证集或全部数据学习缩放参数。
    例子：返回对象支持 model.fit(X_train, y_train)，随后对 X_valid 调用 predict。
    """
    # TODO 1: 创建标准化器与逻辑回归分类器，设置 C 和迭代次数。
    # TODO 2: 用 make_pipeline 按先缩放、后分类的顺序组合并返回。
    raise NotImplementedError('build_model')


def evaluate(y_true, predictions):
    """同时检查总体准确率、类别混淆和具体错分样本。
    
    为什么做：总分不能说明模型错在什么地方；混淆矩阵告诉我们哪些类别
    容易混淆，错分位置则让页面能找到对应的样本。
    输入：y_true、predictions 是等长非空的一维真实/预测标签，值为 0、1、2。
    输出：含三个键的字典：
        accuracy：Python float，正确比例；matrix：整数数组 (3, 3)；
        wrong：一维整数数组，存放预测错误的零起始位置，没有错分时为空数组。
    要求：matrix 的行是真实类别，列是预测类别；固定标签顺序 [0, 1, 2]，
        即使本批少了某一类，也保留该类的行列。wrong 是位置，不是 pandas 索引。
        保持输入顺序，不修改标签。
    例子：[0, 1, 2] 与 [0, 2, 2] → accuracy=2/3、wrong=[1]；
        矩阵在 (0,0)、(1,2)、(2,2) 处各计数 1，其他位置为 0。
    """
    # TODO 1: 计算准确率，并按固定三类生成混淆矩阵。
    # TODO 2: 逐位置比较真实与预测标签，提取不相等项的位置。
    # TODO 3: 用 accuracy、matrix、wrong 三个准确的键名组织字典并返回。
    raise NotImplementedError('evaluate')


def compare_depths(X_train, y_train, X_valid, y_valid, depths, seed=42):
    """进阶：比较不同树深度在训练集和验证集上的准确率。
    
    为什么做：树越深，通常越容易贴合训练数据，但未必更会判断新样本。
    把两种准确率放在一起，可以观察是否出现训练分数高、验证分数低的情况。
    输入：X_train/y_train 与 X_valid/y_valid 是已配对划分的数据；
        depths 为非空的正整数深度序列；seed 为随机种子。
    输出：pandas DataFrame，按 depths 的输入顺序一深度一行，三列依次为
        depth、train_accuracy、valid_accuracy，准确率范围都是 0～1。
    要求：每个深度重新创建 DecisionTreeClassifier，指定 max_depth 和 seed；
        只用训练集 fit，再分别评价两部分。不用验证集训练，也不读取测试集。
    例子：depths=[1, 3, 5] 就返回三行，保留每个深度的两项分数。
    """
    # TODO 1: 遍历 depths，为当前深度创建新的决策树并在训练集上拟合。
    # TODO 2: 分别计算训练、验证准确率，记录成具有指定键名的一行。
    # TODO 3: 将所有行汇成 DataFrame 后返回，不要只返回最好的深度。
    raise NotImplementedError('compare_depths')
