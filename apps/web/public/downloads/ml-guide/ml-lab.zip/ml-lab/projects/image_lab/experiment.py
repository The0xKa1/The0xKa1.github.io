"""图像实验的数据流；每次调用保留学习者实际返回的有限数值。"""
import numpy as np
import pandas as pd


def call_image(fn, name, image, *args):
    """隔离输入，检查可绘制性；不拿参考实现替换错误答案。"""
    expected = image.shape[:2] if name == 'grayscale' else image.shape
    value = np.asarray(getattr(fn, name)(image.copy(), *args))
    if value.shape != expected:
        raise ValueError(f'{name} 应返回形状 {expected}，实际为 {value.shape}')
    if value.dtype.kind not in 'fiu' or not np.isfinite(value).all():
        raise ValueError(f'{name} 应返回有限实数数组，不能包含 NaN 或无穷大')
    return value.astype(float, copy=True)


def add_noise(gray, strength, seed):
    return np.clip(gray + np.random.default_rng(seed).normal(0, strength, gray.shape), 0, 1)


def denoise(fn, gray, noise, size, seed, simulated=True):
    noisy = add_noise(gray, noise, seed) if simulated else gray.copy()
    smooth = call_image(fn, 'mean_filter', noisy, size)
    metrics = {}
    if simulated:
        metrics = dict(noisy_mse=float(np.mean((noisy-gray)**2)),
                       filtered_mse=float(np.mean((smooth-gray)**2)))
    return dict(gray=gray, noisy=noisy, smooth=smooth, metrics=metrics)


def run(fn, image, brightness=0., contrast=1., noise=.12, size=3, seed=42, simulated=True):
    gray = call_image(fn, 'grayscale', image)
    adjusted = call_image(fn, 'adjust', image, brightness, contrast)
    result = denoise(fn, gray, noise, size, seed, simulated)
    edge = call_image(fn, 'edge_strength', gray)
    noisy_edge = call_image(fn, 'edge_strength', result['noisy'])
    smooth_edge = call_image(fn, 'edge_strength', result['smooth'])
    errors = pd.DataFrame({'图像': ['加噪', '均值滤波'],
                           'MSE': list(result['metrics'].values())}) if simulated else pd.DataFrame()
    return dict(result, image=image.copy(), adjusted=adjusted, edge=edge,
                noisy_edge=noisy_edge, smooth_edge=smooth_edge, errors=errors)
