"""图像工作台的分题运行、对照与导出工具。"""
from io import BytesIO
from pathlib import Path
import re
import numpy as np
import pandas as pd
from PIL import Image
import plotly.express as px
import streamlit as st
from common.charts import chart
from common.checks import check_project
from common.runtime import fingerprint, load_functions
from common.ui import error
from .experiment import call_image, denoise
from .pixel_editor import pixel_canvas, paint_region


# 已提供的二维输入，允许滤波与边缘题独立运行。
TEST_GRAY = np.array([[.1, .1, .1, .8, .8, .8],
                      [.1, .1, .1, .8, .8, .8],
                      [.1, .1, .1, .8, .8, .8],
                      [.1, .1, .1, .8, .8, .8]], dtype=float)
HAND_GRID = np.array([[0., .3, .6], [.3, .6, .9], [.6, .9, 1.]])


def stage_lesson(stage):
    content = Path(__file__).with_name('README.md').read_text(encoding='utf-8')
    sections = re.split(r'^## ([0-5])\. .*$', content, flags=re.M)
    text = dict(zip(sections[1::2], sections[2::2]))[str(stage)]
    if stage == 0:
        with st.expander('准备文件与运行方式'):
            st.markdown(sections[0].split('## 开始前', 1)[1])
    blocks = re.split(r'<details><summary>(.*?)</summary>(.*?)</details>', text, flags=re.S)
    st.markdown(blocks[0])
    for i in range(1, len(blocks), 3):
        with st.expander(blocks[i]):
            st.markdown(blocks[i+1])
        st.markdown(blocks[i+2])


def exercise_check(name, number):
    if st.button(f'检查第 {number} 题：{name}', key='image_check_'+name):
        try:
            for report in check_project('image_lab', load_functions('image_lab', '练习'), only=name):
                (st.success if report['passed'] else st.warning)(report['message'])
        except Exception as exc:
            error(exc)


def stage_run(stage, label, mode, params, compute):
    """每题独立缓存；改变代码/模式/相关参数时不展示旧结果。"""
    key = 'image_stage_'+stage
    try:
        signature = fingerprint('image_lab', mode, dict(stage=stage, **params))
    except Exception as exc:
        error(exc)
        return None
    if st.button(label, key='image_run_'+stage):
        st.session_state.pop(key, None)
        try:
            result = compute(load_functions('image_lab', mode))
            st.session_state[key] = dict(signature=signature, result=result)
        except Exception as exc:
            error(exc)
    saved = st.session_state.get(key)
    if saved and saved['signature'] != signature:
        st.info('代码、模式、数据或参数已改变；本题旧结果待更新，请重新运行。')
        return None
    return saved['result'] if saved else None


def picture(array, title, key, edge=False, cells=False):
    limit = float(np.sqrt(2)) if edge else 1.
    if np.any(array < 0) or np.any(array > limit + 1e-6):
        st.warning(f'{title} 的返回值范围为 {array.min():.3g}–{array.max():.3g}，超出约定的 0–{limit:.3g}。图像显示会截断；数值与下载的数组保留原值。')
    # RGB 和灰度均显式固定尺度，避免错误返回或不同图片被自动归一化。
    view = np.clip(array, 0, limit)
    fig = px.imshow(view, zmin=0, zmax=limit, color_continuous_scale='gray',
                    labels=dict(x='列（从 0 开始）', y='行（从 0 开始）', color='强度'),
                    text_auto='.2f' if cells and array.ndim == 2 else False)
    fig.update_layout(title=title, height=300, coloraxis_showscale=edge)
    if cells:
        fig.update_xaxes(dtick=1)
        fig.update_yaxes(dtick=1)
    chart(fig, key=key)


def compare_pictures(arrays, names, key, edge=False):
    for i, (col, array, name) in enumerate(zip(st.columns(len(arrays)), arrays, names)):
        with col:
            picture(array, name, f'{key}_{i}', edge=edge)


def coordinate(label, length, key):
    if length == 1:
        st.caption(f'{label}：0（仅一个像素）')
        return 0
    if key in st.session_state and not 0 <= int(st.session_state[key]) < length:
        del st.session_state[key]
    return st.slider(label, 0, length-1, length//2, key=key)


def pixel_lab(image, digest):
    key = 'image_pixel_edit'
    if key not in st.session_state or st.session_state[key]['source'] != digest:
        st.session_state[key] = dict(source=digest, array=image.copy(), selection=None, undo=None, generation=0)
    state = st.session_state[key]
    selection = pixel_canvas(state['array'],state['selection'],f"image_canvas_{digest}_{state['generation']}")
    if selection != state['selection']:
        state['selection'] = selection
        st.rerun()
    st.caption(f'图片数组：{image.shape[0]} 行 × {image.shape[1]} 列 × 3 通道。按 Esc 取消选区。')
    color = st.color_picker('选区填充颜色','#ff0000',key='image_fill_color')
    a,b,c = st.columns(3)
    if a.button('填充选区',key='image_fill_region',disabled=selection is None):
        rgb = [int(color[i:i+2],16)/255 for i in (1,3,5)]
        state['undo'] = state['array'].copy()
        state['array'] = paint_region(state['array'],selection,rgb)
        st.rerun()
    if b.button('恢复选区',key='image_restore_region',disabled=selection is None):
        x0,y0,x1,y1 = selection
        state['undo'] = state['array'].copy()
        state['array'][y0:y1,x0:x1] = image[y0:y1,x0:x1]
        st.rerun()
    if c.button('撤销上次修改',key='image_undo_region',disabled=state['undo'] is None):
        state['array'] = state['undo']
        state['undo'] = None
        st.rerun()
    if st.button('恢复整张原图',key='image_reset_pixels'):
        state.update(array=image.copy(),selection=None,undo=None,generation=state['generation']+1)
        st.rerun()
    if selection:
        x0,y0,x1,y1 = selection
        original = image[y0:y1,x0:x1]
        edited = state['array'][y0:y1,x0:x1]
        st.write(f'选区切片：image[{y0}:{y1}, {x0}:{x1}]，共 {(y1-y0)*(x1-x0)} 个像素。')
        compare_pictures([original,edited],['选区原始像素','选区当前像素'],'pixel_patch')
        rgb = ', '.join(f'{float(value):.4f}' for value in edited[0,0])
        st.write(f'选区左上角 RGB：[{rgb}]。')
    st.caption('框选后填色会直接修改整张工作图；后续阶段使用修改后的图片。换图会重新开始。')
    st.download_button('下载修改后的图片',png_bytes(state['array']),'edited-photo.png',mime='image/png',key='image_edited_download')
    return state['array'].copy()


def gray_input(fn, image, use_photo):
    return call_image(fn, 'grayscale', image) if use_photo else TEST_GRAY.copy()


def filter_pair(fn, image, use_photo, noise, seed, sizes, simulated):
    gray = gray_input(fn, image, use_photo)
    first = denoise(fn, gray, noise, sizes[0], seed, simulated)
    second = call_image(fn, 'mean_filter', first['noisy'], sizes[1])
    return dict(first, second=second)


def filter_handwork(mode):
    st.subheader('用手算一个像素')
    row = st.selectbox('手算像素行', [0,1,2], index=1, key='hand_row')
    col = st.selectbox('手算像素列', [0,1,2], index=1, key='hand_col')
    padded = np.pad(HAND_GRID, 1, mode='edge')
    window = padded[row:row+3,col:col+3]
    fig = px.imshow(padded, zmin=0, zmax=1, text_auto='.2f', color_continuous_scale='gray')
    fig.add_shape(type='rect', x0=col-.5, x1=col+2.5, y0=row-.5, y1=row+2.5,
                  line=dict(color='#2563a6', width=3))
    fig.update_layout(height=320, title='复制填充后的 5×5 数组，蓝框是参与平均的 3×3 窗口', coloraxis_showscale=False)
    chart(fig, key='hand_window')
    st.write('参与平均的数：' + ' + '.join(f'{x:g}' for x in window.ravel()))
    st.write(f'手算核对：{window.sum():.4g} ÷ 9 = {window.mean():.6f}')
    result = stage_run('hand', '用当前函数算这个像素', mode, dict(row=row,col=col),
                       lambda fn: call_image(fn, 'mean_filter', HAND_GRID, 3))
    if result is not None:
        st.write(f'函数返回：{result[row,col]:.6f}')
        if not np.isclose(result[row,col],window.mean()):
            st.warning('与手算不同。先检查窗口取了哪些数，以及角落是否复制了边缘像素。')
        st.dataframe(pd.DataFrame(result), width='stretch')


def metrics(result):
    if result['metrics']:
        a,b = st.columns(2)
        a.metric('加噪 MSE', f"{result['metrics']['noisy_mse']:.5f}")
        b.metric('滤波 MSE', f"{result['metrics']['filtered_mse']:.5f}")
        st.caption('参照是加模拟噪声前的灰度图。MSE 越小表示越接近这张输入图，不等于视觉效果一定更好。')
    else:
        st.caption('直接处理输入照片：没有干净原图作参照，不计算恢复 MSE。')


def inspect_pair(result, sizes, key, simulated):
    arrays = [result['noisy'], result['smooth'], result['second']]
    names = ['加噪图' if simulated else '输入灰度图', f'窗口 {sizes[0]}', f'窗口 {sizes[1]}']
    compare_pictures(arrays, names, key+'_full')
    if result['metrics']:
        second_mse = float(np.mean((result['second']-result['gray'])**2))
        st.dataframe(pd.DataFrame({'图像':names, 'MSE':[result['metrics']['noisy_mse'], result['metrics']['filtered_mse'], second_mse]}), hide_index=True)
    h,w = result['gray'].shape
    row = coordinate('观察第几行像素', h, key+'_row')
    col = coordinate('放大区域中心列', w, key+'_col')
    region = np.s_[max(0,row-5):row+6, max(0,col-5):col+6]
    st.caption('三张图放大同一区域，灰度显示范围统一为 0–1。')
    compare_pictures([a[region] for a in arrays], names, key+'_crop')
    data = {'像素列':np.arange(w), names[0]:arrays[0][row],
            f'A · {names[1]}':arrays[1][row], f'B · {names[2]}':arrays[2][row]}
    if simulated:
        data['加噪前'] = result['gray'][row]
    frame = pd.DataFrame(data)
    chart(px.line(frame, x='像素列', y=list(data)[1:]).update_yaxes(range=[0,1], title='亮度'), key=key+'_line')
    st.download_button('下载当前像素剖面 CSV', frame.to_csv(index=False).encode('utf-8-sig'), 'pixels.csv', key=key+'_csv')


def png_bytes(array):
    buffer = BytesIO()
    Image.fromarray(np.rint(np.clip(array,0,1)*255).astype(np.uint8)).save(buffer,format='PNG')
    return buffer.getvalue()


def array_bytes(array):
    buffer = BytesIO()
    np.save(buffer, array, allow_pickle=False)
    return buffer.getvalue()
