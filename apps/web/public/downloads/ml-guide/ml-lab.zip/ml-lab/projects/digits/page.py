from io import BytesIO
import hashlib
import importlib.util
import json
import time
import numpy as np
import pandas as pd
import plotly.express as px
import streamlit as st
from PIL import Image
from sklearn.metrics import confusion_matrix
from common.runtime import fingerprint,load_functions,json_default
from common.ui import error,record_final
from common.charts import chart,matrix
from . import dataset
from .experiment import train,normalized,final_test,recognize,predict,perturb,checkpoint_bytes,restore_checkpoint
from .workshop import lesson,check,trial,network_preview,step_preview,evaluation_preview
from .drawing import drawing


def picture(image,title,key):
    chart(px.imshow(image,zmin=0,zmax=255,color_continuous_scale='gray',title=title).update_layout(height=300,coloraxis_showscale=False),key=key)


def probability_plot(probs,key):
    chart(px.bar(x=list(map(str,range(10))),y=probs,labels=dict(x='数字',y='概率')).update_yaxes(range=[0,1]),key=key)


def render(mode):
    tabs=st.tabs(['0 · 数据准备','1 · 整理像素','2 · 卷积网络','3 · 训练与评价','4 · 正式训练','5 · 错题与手写','6 · 测试与模型'])
    ready=dataset.available()
    torch_ready=importlib.util.find_spec('torch') is not None
    with tabs[0]:
        lesson(0)
        if st.button('下载或校验 MNIST',key='digits_download'):
            bar=st.progress(0,text='准备下载…')
            try:
                dataset.download(progress=lambda fraction,name:bar.progress(fraction,text=name));ready=True
            except Exception as exc:error(exc)
        st.caption(f'本地数据缓存：{dataset.ROOT}。首次下载约 12 MB，后续直接读取本地文件。')
        if ready:
            try:images,labels=dataset.load_split();tr,va=dataset.split_ids(labels)
            except Exception as exc:
                error(exc);ready=False
            if ready:
                st.success('MNIST 已就绪：54,000 训练 / 6,000 验证 / 10,000 测试。')
                digit=st.selectbox('查看哪个数字',list(range(10)),key='digits_explore_digit')
                ids=tr[labels[tr]==digit]
                sample_id=st.selectbox('训练样本编号',ids[:100].tolist(),key='digits_explore_id')
                picture(images[sample_id],f'MNIST 训练样本 #{sample_id}','digits_raw')
        else:st.info('请先下载数据。页面不会自动下载或训练。')
        if not torch_ready:st.info('训练与预测需要 PyTorch：python -m pip install -r requirements-torch.txt')
    with tabs[1]:
        lesson(1);check('normalize')
        if ready:
            prepared=trial('normalize','查看我的像素转换结果',mode,dict(sample=int(sample_id)),lambda fn:normalized(fn,images[[sample_id]]))
            if prepared is not None:
                st.write(f'返回形状 {prepared.shape}，类型 {prepared.dtype}。')
                chart(px.imshow(prepared[0,0],zmin=0,zmax=1,color_continuous_scale='gray').update_layout(coloraxis_showscale=False),'digits_normalized')
                if not np.allclose(prepared[0,0],images[sample_id]/255):st.warning('返回值与原像素除以 255 不一致。')
    with tabs[2]:
        lesson(2);check('build_network')
        width=st.selectbox('网络试算隐藏层',[32,64,128,256],index=2,key='digits_preview_hidden')
        if torch_ready:
            network=trial('network','建立 CNN 并检查输出',mode,dict(hidden=width),lambda fn:network_preview(fn,width,42))
            if network is not None:
                st.code(network['structure']);st.metric('可训练参数数量',network['parameters'])
                st.dataframe(pd.DataFrame({'层':['输入','卷积1 + ReLU','池化1','卷积2 + ReLU','池化2','展平','隐藏层','输出得分'],'单样本形状':['1×28×28','16×28×28','16×14×14','32×14×14','32×7×7','1568',str(width),'10']}),hide_index=True)
    with tabs[3]:
        lesson(3);check('train_step')
        steps=st.select_slider('同一批更新次数',[1,5,20],value=5,key='digits_step_count')
        if torch_ready and ready:
            learned=trial('step','运行我的单批训练函数',mode,dict(steps=steps),lambda fn:step_preview(fn,images[tr[:32]],labels[tr[:32]],steps,.1,42))
            if learned is not None:
                chart(px.line(learned['curve'],x='step',y='loss',markers=True),'digits_step_curve')
                st.write(f"参数变化绝对值之和：{learned['delta']:.6f}。")
                if learned['delta']==0:st.warning('参数没有更新，请检查 backward 与 optimizer.step。')
        check('evaluate')
        if torch_ready:
            evaluated=trial('evaluate','运行我的评价函数',mode,{},evaluation_preview)
            if evaluated is not None:
                probability_plot(evaluated['probabilities'][0],'digits_eval_probs')
                st.write(f"固定得分 0–9 的预测：{evaluated['predictions'].tolist()}；核对值 [9,9]。")
                if not np.allclose(evaluated['probabilities'][0],evaluated['expected']):st.warning('概率与 softmax 核对值不符。')
    with tabs[4]:
        lesson(4)
        scope=st.radio('训练规模',['正式训练 · 54,000 张','快速调试 · 6,000 张'],key='digits_scope')
        a,b,c=st.columns(3)
        hidden=a.selectbox('隐藏层宽度',[32,64,128,256],index=2,key='digits_hidden')
        epochs=b.slider('训练轮数',1,20,5,key='digits_epochs')
        learning_rate=c.selectbox('学习率',[.0001,.001,.003],index=1,key='digits_lr')
        a,b,c=st.columns(3)
        batch=a.selectbox('批次大小',[64,128,256],index=1,key='digits_batch')
        device=b.selectbox('计算设备',['auto','cpu','mps','cuda'],key='digits_device')
        seed=c.number_input('训练种子',0,9999,42,key='digits_seed')
        params=dict(hidden=hidden,epochs=epochs,learning_rate=learning_rate,seed=seed,batch_size=batch,device=device,limit=None if scope.startswith('正式') else 6000)
        signature=fingerprint('digits',mode,params)
        if st.button('从头训练 CNN',key='run_digits',disabled=not (ready and torch_ready),type='primary'):
            st.session_state.pop('result_digits',None);st.session_state.pop('digits_final',None)
            bar=st.progress(0,text='建立网络…');table=st.empty()
            def progress(fraction,message,rows):
                bar.progress(fraction,text=message)
                if rows:table.dataframe(pd.DataFrame(rows),hide_index=True)
            try:
                result=train(load_functions('digits',mode),**params,progress=progress)
                result['_signature']=signature
                result['checkpoint']=checkpoint_bytes(result)
                st.session_state['result_digits']=result
                st.session_state.setdefault('history',[]).append(dict(project='digits',mode=mode,time=time.strftime('%Y-%m-%dT%H:%M:%S'),code=signature[:12],parameters=params,metrics=result['metrics'],tables={'curves':result['curves'].to_dict('records')}))
            except Exception as exc:error(exc)
        result=st.session_state.get('result_digits')
        if result and result['_signature']!=signature:
            st.info('训练参数、代码或模式已改变；旧结果待更新，请重新训练。');result=None
        if result:
            a,b,c=st.columns(3)
            a.metric('所选模型验证准确率',f"{result['metrics']['valid_accuracy']:.2%}")
            b.metric('选中轮次',result['best_epoch']);c.metric('训练耗时',f"{result['metrics']['seconds']:.1f} 秒")
            chart(px.line(result['curves'].melt(id_vars='epoch',value_vars=['train_loss','valid_loss']),x='epoch',y='value',color='variable',labels=dict(epoch='轮次',value='交叉熵')),'digits_loss_curve')
            chart(px.line(result['curves'],x='epoch',y='valid_accuracy',labels=dict(epoch='轮次',valid_accuracy='验证准确率')).update_yaxes(range=[0,1]),'digits_accuracy_curve')
            st.caption(f"实际设备：{result['config']['device']}；训练 {len(result['train_ids']):,} 张，验证 {len(result['valid_ids']):,} 张。当前保留验证损失最低轮次的参数。")
    with tabs[5]:
        lesson(5)
        # Imported weights can be used without rerunning training; code/mode changes invalidate them.
        imported=st.session_state.get('digits_imported')
        if imported and imported[0]!=fingerprint('digits',mode,{}):imported=None
        source=st.radio('识别使用的模型',['本次训练','导入的权重'],key='digits_model_source')
        inference=result if source=='本次训练' else imported[1] if imported else None
        if inference is None:st.info('先完成训练，或到第 6 阶段导入本项目的权重文件。')
        else:
            if source=='本次训练':
                samples=result['samples']
                chart(matrix(confusion_matrix(samples.actual,samples.predicted,labels=range(10)),list(map(str,range(10))),'验证集混淆矩阵'),'digits_valid_matrix')
                only_wrong=st.checkbox('只看错题',True,key='digits_wrong')
                shown=samples[samples.actual!=samples.predicted] if only_wrong else samples
                if len(shown):
                    idx=st.selectbox('查看验证样本编号',shown.index.tolist(),key='digits_selected')
                    a,b=st.columns(2)
                    noise=a.slider('噪声标准差',0,100,0,key='digits_noise');shift=b.slider('水平平移 / 像素',-6,6,0,key='digits_shift')
                    altered=perturb(result['images'][idx],noise,shift)
                    with a:picture(result['images'][idx],f'真实 {samples.loc[idx,"actual"]} · 预测 {samples.loc[idx,"predicted"]}','digits_original')
                    with b:picture(altered,'扰动后','digits_changed')
                    try:probability_plot(predict(result,altered[None])[0],'digits_perturb_probs')
                    except Exception as exc:error(exc)
                else:st.success('当前筛选没有错例。')
            st.subheader('连续手写与图片识别')
            generation=st.session_state.setdefault('mnist_generation',0)
            pixels=st.session_state.setdefault('mnist_pixels',np.zeros((280,280),np.uint8))
            a,b,c=st.columns(3)
            erase=a.checkbox('橡皮擦',key='digits_erase');pen=b.slider('笔宽',8,32,18,key='digits_pen')
            if c.button('清空画板',key='digits_clear'):
                generation+=1;st.session_state['mnist_generation']=generation;pixels=np.zeros((280,280),np.uint8)
            pixels=drawing(pixels,'mnist_canvas_'+str(generation),erase,pen);st.session_state['mnist_pixels']=pixels
            upload=st.file_uploader('或上传单个数字图片',type=['png','jpg','jpeg'],key='digits_upload')
            ink=st.radio('上传图片的笔迹颜色',['黑字白底','白字黑底'],key='digits_ink')
            try:
                if upload:
                    with Image.open(upload) as im:input_image=im.copy()
                    digest=hashlib.sha256(upload.getvalue()+ink.encode()).hexdigest()
                else:input_image=pixels;digest=hashlib.sha256(pixels.tobytes()).hexdigest()
                prediction=trial('drawing','识别当前输入',mode,dict(model=inference['_signature'],input=digest),lambda fn:recognize(inference,input_image,'black' if upload and ink=='黑字白底' else 'white'))
                if prediction is not None:
                    processed,probs=prediction
                    picture(processed,'模型实际看到的 28×28 输入','digits_preprocessed')
                    st.write(f'预测数字：{int(probs.argmax())} · 最高概率 {probs.max():.1%}')
                    probability_plot(probs,'digits_draw_probs')
                    st.caption('上传与手写输入都经过前景裁剪、等比例缩放和重心居中；该预览用于检查预处理是否正确。')
            except Exception as exc:error(exc)
    with tabs[6]:
        lesson(6)
        if result:
            if st.button('评价官方 10,000 张测试集',key='digits_test'):
                st.session_state.pop('digits_final',None)
                try:
                    with st.spinner('仅推理，不更新参数…'):final=final_test(result)
                    st.session_state['digits_final']=(signature,final)
                    record_final('digits',mode,result,{'test_accuracy':final['accuracy']},{'predictions':final['samples']})
                except Exception as exc:error(exc)
            final=st.session_state.get('digits_final')
            if final and final[0]==signature:
                st.metric('最终测试准确率',f"{final[1]['accuracy']:.2%}")
                chart(matrix(final[1]['matrix'],list(map(str,range(10))),'测试集混淆矩阵'),'digits_test_matrix')
                st.download_button('下载测试预测 CSV',final[1]['samples'].to_csv(index=False).encode('utf-8-sig'),'mnist-test.csv','text/csv')
            st.download_button('下载最佳模型权重',result['checkpoint'],'mnist-cnn.pt','application/octet-stream')
            st.download_button('下载训练记录 JSON',json.dumps(dict(config=result['config'],metrics=result['metrics'],curves=result['curves']),default=json_default,ensure_ascii=False,indent=2),'mnist-training.json','application/json')
        else:st.info('训练完成后可评价测试集、导出权重与记录。也可以直接导入已训练权重进行识别。')
        weights=st.file_uploader('导入本项目 MNIST CNN 权重',type=['pt'],key='digits_weights')
        if st.button('载入权重用于识别',disabled=weights is None or not torch_ready,key='digits_import'):
            st.session_state.pop('digits_imported',None)
            try:
                imported=restore_checkpoint(load_functions('digits',mode),weights.getvalue())
                imported['_signature']=hashlib.sha256(weights.getvalue()).hexdigest()
                st.session_state['digits_imported']=(fingerprint('digits',mode,{}),imported)
                st.success('已载入。到第 5 阶段选择“导入的权重”。')
            except Exception as exc:error(exc)
