"""一条连续的葡萄酒研究流程；不再嵌入三个独立实验页。"""
import json
from copy import deepcopy
import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st
from sklearn.metrics import adjusted_rand_score
from common.charts import chart,COLORS
from common.data import wine_split
from common.runtime import load_functions
from common.checks import check_project
from common.ui import error
from . import flow
from .practice import TASKS, stage_lesson

STEPS=['0 · 认识成分','1 · 划分数据','2 · 葡萄酒分类','3 · 酒精含量','4 · 聚类与降维','5 · 样本对照','6 · 测试与总结']
DEFAULTS=dict(features=['alcohol','flavanoids','color_intensity','proline'],axes=['alcohol','flavanoids'],seed=42,C=1.,depth=3,model='逻辑回归',k=3,project_first=False)
PROJECTS={1:['wine_classification'],2:['wine_classification'],3:['wine_regression'],4:['clustering'],6:['wine_classification','wine_regression']}


def current(mode,cfg):
    saved=st.session_state.get('wine_flow_results',{})
    signatures={};valid={}
    parameters={1:dict(seed=cfg['seed']),2:dict(features=cfg['features'],C=cfg['C'],depth=cfg['depth']),
                3:dict(features=[f for f in cfg['features'] if f!='alcohol']),
                4:dict(features=cfg['features'],k=cfg['k'],project_first=cfg['project_first'],seed=cfg['seed']),
                6:dict(model=cfg['model'])}
    for step in [1,2,3,4,6]:
        parent={1:None,2:1,3:2,4:3,6:4}[step]
        if parent is not None and parent not in valid:continue
        signatures[step]=flow.signature(mode,PROJECTS[step],parameters[step],signatures.get(parent,''))
        record=saved.get(step)
        if record and record['signature']==signatures[step]:valid[step]=record['result']
    return valid,signatures


def execute(step,label,mode,cfg,compute):
    valid,signatures=current(mode,cfg)
    if st.button(label,key=f'wine_flow_run_{step}',type='primary'):
        saved=st.session_state.setdefault('wine_flow_results',{})
        for downstream in list(saved):
            if downstream >= step:saved.pop(downstream,None)
        try:
            with st.spinner('正在运行这一步…'):result=compute()
            saved[step]=dict(signature=signatures[step],result=result)
        except Exception as exc:error(exc)
    valid,_=current(mode,cfg)
    if step in st.session_state.get('wine_flow_results',{}) and step not in valid:
        st.info('数据、代码或参数已改变，结果待更新，请重新运行。')
    return valid.get(step)


def code_help(project,names):
    with st.expander('这一步的代码与提示'):
        st.caption(f'练习模式使用 projects/{project}/exercises.py 中的函数；演示模式使用参考实现。')
        for name in names:
            title,contract,expected,hint,api=TASKS[project][name]
            st.markdown(f'**{name} · {title}**')
            st.write(contract)
            st.caption('核对例子：'+expected)
            with st.expander(name+' 的提示'):
                st.write(hint);st.code(api,language='python')
        if st.button('检查这一步的代码',key='wine_flow_check_'+names[0]):
            try:
                fn=load_functions(project,'练习')
                for name in names:
                    for report in check_project(project,fn,only=name):
                        (st.success if report['passed'] else st.warning)(f"{name}：{report['message']}")
            except Exception as exc:error(exc)


def render(mode):
    cfg=st.session_state.setdefault('wine_flow_config',deepcopy(DEFAULTS))
    tabs=st.tabs(STEPS,key='wine_active_stage',on_change='rerun')
    for step,tab in enumerate(tabs):
        with tab:render_stage(mode,cfg,step)


def render_stage(mode,cfg,step):
    stage_lesson(step)
    dev,test,ydev,ytest=wine_split()
    # 各步设置保存在研究配置中，翻页不会丢失。
    if step==0:
        st.subheader('先看看葡萄酒的成分')
        st.write('这张表有 178 份葡萄酒样本。选几项成分，看看不同类别的酒分布在哪里。后面的分类和聚类会使用这些成分；预测酒精含量时，会从输入中去掉 alcohol。')
        st.caption('数据集分为三个类别，标签不表示质量高低。')
        cfg['features']=st.multiselect('选择成分',dev.columns,default=cfg['features'],key='wine_flow_features')
        if len(cfg['features'])<2:
            st.info('请至少选两项成分。');return
        cols=st.columns(2)
        cfg['axes'][0]=cols[0].selectbox('横轴',cfg['features'],index=cfg['features'].index(cfg['axes'][0]) if cfg['axes'][0] in cfg['features'] else 0)
        rest=[f for f in cfg['features'] if f!=cfg['axes'][0]]
        cfg['axes'][1]=cols[1].selectbox('纵轴',rest,index=rest.index(cfg['axes'][1]) if cfg['axes'][1] in rest else 0)
        frame=dev.assign(类别=ydev.astype(str),样本=dev.index)
        chart(px.scatter(frame,x=cfg['axes'][0],y=cfg['axes'][1],color='类别',symbol='类别',custom_data=['样本'],category_orders={'类别':['0','1','2']},color_discrete_map={str(i):COLORS[i] for i in range(3)}),key='wine_flow_intro')
        st.write(f"已选 {len(cfg['features'])} 项成分。图中只显示两个坐标轴，其余成分也会用于建模。")
        with st.expander('查看当前成分表'):st.dataframe(dev[cfg['features']])
        return
    if step==1:
        st.subheader('训练集、验证集和测试集')
        st.write('程序已留出 36 份测试样本。将其余 142 份分成训练集和验证集：106 份用于训练，36 份用于比较模型。分类和含量预测沿用这份划分，测试集留到最后评价。')
        cfg['seed']=st.number_input('划分种子',0,9999,cfg['seed'],key='wine_flow_seed')
        code_help('wine_classification',['split_data'])
        result=execute(1,'保存训练与验证划分',mode,cfg,lambda:flow.split(load_functions('wine_classification',mode),dev,ydev,cfg['seed']))
        if result:
            st.dataframe(pd.DataFrame({'用途':['训练','验证','最终测试'],'样本数':[106,36,36],'什么时候使用':['让模型学习','选择模型与参数','完成研究后评价']}),hide_index=True)
            st.success('划分已保存，分类和含量预测会使用这份结果。')
        return
    valid,_=current(mode,cfg)
    required={2:1,3:2,4:3,5:4,6:4}[step]
    if required not in valid:
        st.subheader(STEPS[step].split(' · ')[1])
        st.write({2:'在相同的划分上比较多数类基线、逻辑回归和决策树，查看哪些样本分错了。',3:'沿用分类实验的样本划分，用其他成分估计酒精含量。',4:'根据成分的相似程度给样本分组，再与已知类别对照。',5:'把同一份样本的分类、含量预测和聚类结果放在一起，观察它们是否一致。',6:'确定模型与参数后，用留出的 36 份测试样本评价，并保存实验记录。'}[step])
        st.info(f'请先完成或重新运行「{STEPS[required]}」。已有结果可能因上游修改而失效。')
        return
    partition=valid[1]
    if step==2:
        st.subheader('用成分预测类别')
        st.write(f"使用已划分的训练集和验证集，比较这 {len(cfg['features'])} 项成分的分类效果。多数类基线始终猜训练集中数量最多的类别；逻辑回归和决策树需要学到比它更多的信息。")
        a,b=st.columns(2)
        choices=[.01,.1,1.,10.,100.]
        cfg['C']=a.select_slider('逻辑回归 C',choices,value=cfg['C'])
        cfg['depth']=b.slider('决策树最大深度',1,10,cfg['depth'])
        code_help('wine_classification',['build_model','evaluate'])
        result=execute(2,'运行分类',mode,cfg,lambda:flow.classify(load_functions('wine_classification',mode),partition,cfg['features'],cfg['C'],cfg['depth'],cfg['seed']))
        if result:
            st.dataframe(result['scores'],hide_index=True)
            names=list(result['models'])
            cfg['model']=st.selectbox('选择分类模型',names,index=names.index(cfg['model']))
            pred=result['predictions'][cfg['model']]
            samples=partition['Xv'][cfg['axes']].assign(真实类别=partition['yv'],预测类别=pred)
            view=samples.assign(类别=samples['真实类别'].astype(str),判断=np.where(samples['真实类别']==samples['预测类别'],'正确','错分'),样本=samples.index)
            chart(px.scatter(view,x=cfg['axes'][0],y=cfg['axes'][1],color='类别',symbol='判断',symbol_map={'正确':'circle','错分':'x'},custom_data=['样本'],color_discrete_map={str(i):COLORS[i] for i in range(3)}),key='wine_flow_classification')
            st.caption('同一批验证样本：颜色是真实类别，叉号表示错分。这里只画两项成分的投影，模型使用全部选中成分。')
            with st.expander('逐行查看真实类别与预测'):st.dataframe(samples,hide_index=False)
            wrong=pred.index[pred!=partition['yv']].tolist()
            ids=wrong+[i for i in pred.index if i not in wrong]
            cfg['focus']=st.selectbox('选择要对照的样本',ids,index=ids.index(cfg['focus']) if cfg.get('focus') in ids else 0)
            st.caption('错分样本排在前面。酒精含量和样本对照页也会显示选中的编号。')
            st.write(f"当前选择：样本 {cfg['focus']}。")
        return
    if step==3:
        st.subheader('用其他成分估计酒精含量')
        inputs=[f for f in cfg['features'] if f!='alcohol']
        st.write('这次预测的是 alcohol 的数值。训练和验证样本与分类实验相同，输入中去掉 alcohol，也不使用类别标签。')
        st.caption('输入成分：'+ '、'.join(inputs))
        code_help('wine_regression',['split_target','build_model','errors','select_alpha'])
        result=execute(3,'运行含量预测',mode,cfg,lambda:flow.regress(load_functions('wine_regression',mode),partition,cfg['features']))
        if result:
            a,b=st.columns(2);a.metric('验证 MAE',f"{result['mae']:.3f}");b.metric('总猜训练均值的 MAE',f"{result['baseline_mae']:.3f}")
            st.caption(f"验证集上选出的 alpha={result['alpha']:g}。MAE 是平均绝对误差，越小越好。这里还没有使用测试集。")
            frame=result['samples'].assign(样本=result['samples'].index)
            fig=px.scatter(frame,x='实测酒精含量',y='预测酒精含量',custom_data=['样本'])
            low=min(frame.iloc[:,0].min(),frame.iloc[:,1].min());high=max(frame.iloc[:,0].max(),frame.iloc[:,1].max())
            fig.add_shape(type='line',x0=low,y0=low,x1=high,y1=high,line=dict(dash='dash',color='#888'))
            chart(fig,key='wine_flow_regression')
            focus=cfg.get('focus',int(partition['Xv'].index[0]))
            st.write(f'分类页选中的样本 {focus}：');st.dataframe(result['samples'].loc[[focus]])
            st.caption('残差 = 实测 − 预测，正数是低估，负数是高估。分类认错的样本，含量不一定也预测得差。')
            with st.expander('这次如何选择 alpha'):st.dataframe(result['candidates'],hide_index=True)
            st.write('分类和回归都用已知答案训练。聚类则只根据成分计算相似程度，可以看看它的分组与类别是否一致。')
        return
    if step==4:
        st.subheader('按成分给样本分组')
        st.write('将训练集和验证集合并为 142 份样本，使用选中的成分做 K-means 聚类。程序先标准化各项成分，再按距离分组、更新中心，直到中心基本不再移动。类别标签不参与计算，测试样本也不参与。')
        cfg['k']=st.slider('簇数 K',2,6,cfg['k'])
        cfg['project_first']=st.checkbox('先投影到二维，再计算分组',value=cfg['project_first'])
        st.caption('默认在全部选中成分上计算分组，只在画图时用 PCA 投影到二维；勾选后会改变实际计算距离的空间。')
        code_help('clustering',['distances','assign_groups','update_centers','converged'])
        result=execute(4,'运行聚类',mode,cfg,lambda:flow.group(load_functions('clustering',mode),dev,cfg['features'],cfg['k'],cfg['seed'],cfg['project_first']))
        if result:
            iteration=st.slider('查看迭代步骤',0,len(result['frames'])-1,len(result['frames'])-1)
            frame=result['frames'][iteration];coords=result['coords']
            fig=go.Figure()
            for group in range(cfg['k']):
                mask=frame['groups']==group
                fig.add_scatter(x=coords[mask,0],y=coords[mask,1],mode='markers',name=f'簇 {group}',marker=dict(color=COLORS[group]),customdata=dev.index[mask],hovertemplate='样本 %{customdata}<extra></extra>')
            centers=frame['display_centers'];fig.add_scatter(x=centers[:,0],y=centers[:,1],mode='markers',name='中心',marker=dict(symbol='x',size=15,color='#222'))
            fig.update_layout(xaxis_title='主成分 1',yaxis_title='主成分 2')
            chart(fig,key='wine_flow_groups')
            st.caption(f"两个主成分解释了 {result['variance']:.1%} 的方差。第 {iteration} 次迭代的组内距离平方和为 {frame['inertia']:.2f}。")
            focus=cfg.get('focus',int(partition['Xv'].index[0]))
            st.write(f"样本 {focus} 被分到簇 {result['groups'].loc[focus]}，可在“样本对照”页查看它的其他结果。")
        return
    focus=cfg.get('focus',int(partition['Xv'].index[0]))
    if step==5:
        st.subheader('对照分类、含量预测和分组')
        c,r,g=valid[2],valid[3],valid[4]
        row=r['samples'].loc[focus]
        st.dataframe(pd.DataFrame({'观察':['样本编号','真实类别','预测类别','实测酒精含量','预测酒精含量','最终簇编号'],
                                   '结果':[str(focus),str(ydev.loc[focus]),str(c['predictions'][cfg['model']].loc[focus]),f"{row['实测酒精含量']:.3f}",f"{row['预测酒精含量']:.3f}",str(g['groups'].loc[focus])]}),hide_index=True)
        st.write('下面统计每个簇中各类别的样本数。簇编号可以互换，与类别编号没有固定对应关系。')
        st.dataframe(pd.crosstab(g['groups'],ydev.rename('真实类别')))
        st.metric('分组与标签的一致程度（ARI）',f"{adjusted_rand_score(ydev,g['groups']):.3f}")
        st.caption('ARI=1 表示划分完全一致；随机划分附近约为 0。这是开发样本上的分组对照，不是测试准确率。')
        cfg['observation']=st.text_area('记录这份样本的情况',value=cfg.get('observation',''),placeholder='例如：类别认错了，但含量预测接近实测；所在簇混有两个类别。')
        st.write('可以切换到分类、含量或聚类页调整参数。确定配置后，在“测试与总结”页评价剩余的 36 份样本。')
        return
    st.subheader('在测试集上评价')
    st.write(f"当前选择：{cfg['model']}，{len(cfg['features'])} 项分类输入；酒精含量使用 {len(valid[3]['features'])} 项输入、alpha={valid[3]['alpha']:g}。")
    st.caption('用全部 142 份开发样本重训所选模型，再评价 36 份共用测试样本。聚类仅作为开发阶段的结构探索，不参与测试成绩排名。')
    result=execute(6,'评价测试集',mode,cfg,lambda:flow.final(load_functions('wine_classification',mode),load_functions('wine_regression',mode),valid[2],valid[3],cfg['model'],dev,test,ydev,ytest))
    if result:
        a,b=st.columns(2);a.metric('测试分类准确率',f"{result['accuracy']:.1%}");b.metric('测试含量 MAE',f"{result['mae']:.3f}")
        st.caption('准确率越大越好，MAE 越小越好。反复看测试分数再调参，会失去独立评价的意义。')
        cfg['conclusion']=st.text_area('实验结论',value=cfg.get('conclusion',''))
        report={'项目':'葡萄酒研究室','模式':mode,'配置':cfg,'关注样本观察':cfg.get('observation',''),'结论':cfg.get('conclusion',''),
                '验证分类':valid[2]['scores'].to_dict('records'),'验证含量MAE':valid[3]['mae'],
                '分组ARI':float(adjusted_rand_score(ydev,valid[4]['groups'])),'测试准确率':result['accuracy'],'测试MAE':result['mae']}
        st.download_button('下载完整研究记录',json.dumps(report,ensure_ascii=False,indent=2),'wine-research.json','application/json')
        st.download_button('下载测试样本预测',result['samples'].to_csv().encode('utf-8-sig'),'wine-test.csv','text/csv')
