from collections import deque
import numpy as np
import pandas as pd

ACTIONS = [(-1, 0), (0, 1), (1, 0), (0, -1)]


def parse_map(text):
    grid = [list(row.strip()) for row in text.strip().splitlines()]
    if not grid or not 2 <= len(grid) <= 64 or any(len(row) != len(grid[0]) for row in grid) or not 2 <= len(grid[0]) <= 64:
        raise ValueError('地图须为 2 到 64 行、2 到 64 列的矩形。')
    if any(cell not in 'S.G#' for row in grid for cell in row):
        raise ValueError('地图只能包含 S、G、.、#。')
    positions = {char: [(r, c) for r, row in enumerate(grid) for c, cell in enumerate(row) if cell == char] for char in 'SG'}
    if any(len(positions[char]) != 1 for char in 'SG'):
        raise ValueError('地图需要且只能有一个起点 S 和一个终点 G。')
    return np.array(grid), positions['S'][0], positions['G'][0]


def transition(grid, goal, state, action):
    dr, dc = ACTIONS[action]
    nr, nc = state[0]+dr, state[1]+dc
    nxt = (nr, nc) if 0 <= nr < grid.shape[0] and 0 <= nc < grid.shape[1] and grid[nr, nc] != '#' else state
    done = nxt == goal
    return nxt, 10. if done else -1., done


def shortest_distance(grid, start, goal):
    queue, seen = deque([(start, 0)]), {start}
    while queue:
        state, distance = queue.popleft()
        if state == goal:
            return distance
        for action in range(4):
            nxt, _, _ = transition(grid, goal, state, action)
            if nxt not in seen:
                queue.append((nxt, distance+1)); seen.add(nxt)
    return None


def rollout(grid, start, goal, q, seed=43, max_steps=200):
    rng = np.random.default_rng(seed)
    state, path, records = start, [start], []
    for _ in range(max_steps):
        values = q[state]
        action = int(rng.choice(np.flatnonzero(values == values.max())))
        nxt, reward, done = transition(grid, goal, state, action)
        records.append(dict(action=int(action), reward=reward))
        state = nxt; path.append(state)
        if done:
            return path, records, True
    return path, records, False


def run(fn, text, episodes=2000, seed=42, strategy='衰减', epsilon=.1,
        alpha=.2, gamma=.95, max_steps=None, progress=None, algorithm="Q-learning"):
    if algorithm not in ALGORITHMS:
        raise ValueError("未知算法。")
    validate_config(episodes, seed, strategy, epsilon, alpha, gamma, max_steps)
    grid, start, goal = parse_map(text)
    shortest = shortest_distance(grid, start, goal)
    if shortest is None:
        raise ValueError('终点不可达，请在地图中留出一条通路后重新训练。')
    q = np.zeros((*grid.shape, 4), dtype=float)
    rng = np.random.default_rng(seed)
    rows, snapshots, traces = [], {}, {}
    checkpoints = set([0, 1, 10, 100, episodes])
    checkpoints.update([episodes//4, episodes//2])
    snapshots[0] = q.copy()
    limit = max_steps if max_steps is not None else min(2000, max(80, grid.size*4))
    update = getattr(fn, ALGORITHMS[algorithm])
    for episode in range(episodes):
        state, total, path, records = start, 0., [start], []
        rate = fn.exploration_rate(episode, episodes) if strategy == '衰减' else epsilon
        if np.ndim(rate) != 0 or not np.isfinite(rate) or not 0 <= rate <= 1:
            raise ValueError('探索率必须处于 0 到 1。')
        done = False
        action = checked_action(fn, q[state], rate, rng)
        for step in range(limit):
            nxt, reward, done = transition(grid, goal, state, action)
            next_values = q[nxt].copy()
            next_action = checked_action(fn, next_values, rate, rng) if algorithm == 'SARSA' and not done else None
            if algorithm == 'SARSA':
                value = update(q[state][action], reward, 0. if done else next_values[next_action], done, alpha, gamma)
            elif algorithm == 'Expected SARSA':
                value = update(q[state][action], reward, next_values, done, rate, alpha, gamma)
            else:
                value = update(q[state][action], reward, next_values, done, alpha, gamma)
            if np.ndim(value) != 0 or not np.isfinite(value):
                raise ValueError(f'{ALGORITHMS[algorithm]} 应返回有限标量。')
            q[state][action] = float(value)
            total += reward; state = nxt; path.append(state); records.append(dict(action=int(action), reward=reward))
            if done:
                break
            if step+1 < limit:
                action = next_action if algorithm == 'SARSA' else checked_action(fn, q[state], rate, rng)
        rows.append(dict(episode=episode+1, reward=total, steps=step+1, success=int(done),
                         truncated=not done, collisions=sum(a == b for a, b in zip(path, path[1:])), epsilon=rate))
        if progress and ((episode+1) % max(1, episodes//100) == 0 or episode+1 == episodes):
            progress(episode+1, episodes)
        if episode+1 in checkpoints:
            snapshots[episode+1] = q.copy()
            traces[episode+1] = (path, records, done)
    path, records, success = rollout(grid, start, goal, q, seed+1, limit)
    curve = pd.DataFrame(rows)
    curve['success_rate'] = curve.success.rolling(50, min_periods=1).mean()
    curve['mean_steps'] = curve.steps.rolling(50, min_periods=1).mean()
    return dict(config=dict(text='\n'.join(''.join(row) for row in grid), episodes=episodes, seed=seed,
                            strategy=strategy, epsilon=epsilon, alpha=alpha, gamma=gamma, max_steps=limit, algorithm=algorithm),
                grid=grid, start=start, goal=goal, q=q, path=path, records=records, snapshots=snapshots,
                traces=traces, curve=curve, metrics=dict(success=success, steps=len(path)-1, shortest=shortest,
                extra_steps=len(path)-1-shortest if success else None, reward=sum(r['reward'] for r in records)))



def validate_config(episodes, seed, strategy, epsilon, alpha, gamma, max_steps):
    for name, value, low, high in [('回合数', episodes, 1, 100000), ('种子', seed, 0, 2**32-1)]:
        if isinstance(value, bool) or not isinstance(value, (int, np.integer)) or not low <= value <= high:
            raise ValueError(f'{name}必须是 {low} 到 {high} 的整数。')
    if strategy not in ('衰减', '固定'):
        raise ValueError('探索策略应为衰减或固定。')
    for name, value in [('epsilon', epsilon), ('alpha', alpha), ('gamma', gamma)]:
        if np.ndim(value) != 0 or not np.isfinite(value) or not 0 <= value <= 1:
            raise ValueError(f'{name} 必须在 0 到 1 之间。')
    if alpha == 0:
        raise ValueError('学习率 alpha 必须大于 0。')
    if max_steps is not None and (isinstance(max_steps, bool) or not isinstance(max_steps, int) or not 1 <= max_steps <= 2000):
        raise ValueError('步数上限必须是 1 到 2000 的整数。')


def evaluate(result, episodes=100, seed=2026, random_policy=False):
    """固定地图和起点；独立随机流只用于平局或随机策略，不更新 Q。"""
    config = result['config']
    validate_config(episodes, seed, '固定', 0., .2, .95, config['max_steps'])
    grid, start, goal = result['grid'], result['start'], result['goal']
    q = np.zeros_like(result['q']) if random_policy else result['q']
    shortest = shortest_distance(grid, start, goal)
    rows, trajectories = [], []
    for i, stream in enumerate(np.random.SeedSequence(seed).spawn(episodes)):
        path, records, success = rollout(grid, start, goal, q, stream, config['max_steps'])
        steps = len(records)
        rows.append(dict(episode=i+1, success=success, steps=steps,
                         reward=sum(r['reward'] for r in records), truncated=not success,
                         collisions=sum(a == b for a, b in zip(path, path[1:])),
                         path_ratio=steps/shortest if success else np.nan))
        trajectories.append((path, records, success))
    table = pd.DataFrame(rows)
    ratios = table.loc[table.success, 'path_ratio']
    metrics = dict(success_rate=float(table.success.mean()), mean_steps=float(table.steps.mean()),
                   mean_reward=float(table.reward.mean()), mean_collisions=float(table.collisions.mean()),
                   truncation_rate=float(table.truncated.mean()),
                   success_path_ratio=float(ratios.mean()) if len(ratios) else None)
    return dict(table=table, trajectories=trajectories, metrics=metrics, seed=seed, episodes=episodes)


ALGORITHMS = {'Q-learning': 'update_value', 'SARSA': 'sarsa_update', 'Expected SARSA': 'expected_sarsa_update'}


def checked_action(fn, values, rate, rng):
    action = fn.choose_action(values.copy(), rate, rng)
    if isinstance(action, (bool, np.bool_)) or not isinstance(action, (int, np.integer)) or not 0 <= action < 4:
        raise ValueError('动作必须是 0、1、2、3 中的一个整数。')
    return int(action)


def generate_map(rows=16, cols=16, density=.25, seed=42):
    """随机墙壁，并打通一条随机单调通路；生成器不参与训练。"""
    if not 2 <= rows <= 64 or not 2 <= cols <= 64 or not 0 <= density <= .6:
        raise ValueError('地图尺寸应为 2 到 64，墙壁比例应在 0 到 .6。')
    rng = np.random.default_rng(seed)
    grid = np.where(rng.random((rows, cols)) < density, '#', '.')
    r = c = 0
    while r != rows-1 or c != cols-1:
        grid[r, c] = '.'
        if r == rows-1 or (c < cols-1 and rng.random() < .5):
            c += 1
        else:
            r += 1
    grid[0, 0], grid[-1, -1] = 'S', 'G'
    return '\n'.join(''.join(row) for row in grid)


MAPS = {f'扩展 · {n}×{n}': generate_map(n, n, .25, 42) for n in [16, 32, 64]}
