import pandas as pd
import plotly.express as px
import streamlit as st
from common.charts import chart
from common.ui import run_panel,sample_detail
from .experiment import run,catalog,FEATURES,NAMES

def render(mode):
    st.caption('菜单里的口味属性是为练习手工设置的，没有使用真实用户记录，也不能据此判断营养价值。调整偏好后重新运行，可以查看推荐的前五名。')
    prefs=[col.slider(feature,0,10,value) for col,feature,value in zip(st.columns(4),FEATURES,[8,3,7,4])]
    excluded_names=st.multiselect('已经尝过，暂不推荐',NAMES,default=['原味曲奇'])
    excluded=[NAMES.index(name) for name in excluded_names]
    r=run_panel('recommender',mode,dict(preferences=prefs,excluded=excluded,count=5),lambda fn:run(fn,prefs,excluded,5))
    if r is None: return
    if not any(prefs): st.info('偏好全部为零，匹配分数也都是 0。相同分数按菜单中的顺序排列。')
    if r['ranked'].empty: st.info('所有食品都被排除了。在“已经尝过”中取消几项，就能重新推荐。');return
    chart(px.bar(r['ranked'],x='匹配分数',y='食品',orientation='h').update_xaxes(range=[0,1]).update_yaxes(autorange='reversed'))
    idx=sample_detail(r['ranked'],'recommend_item')
    frame=pd.DataFrame({'属性':FEATURES,'你的偏好':r['profile'],'食品属性':r['catalog'].loc[idx,FEATURES].astype(float).to_numpy()})
    chart(px.bar(frame.melt(id_vars='属性'),x='属性',y='value',color='variable',barmode='group').update_yaxes(range=[0,1],title='属性强度'))
    st.caption('余弦相似度比较向量的方向。把所有偏好同时减半，再运行一次，看看排序是否改变。')
    with st.expander('完整教学菜单'): st.dataframe(r['catalog'],hide_index=True)
