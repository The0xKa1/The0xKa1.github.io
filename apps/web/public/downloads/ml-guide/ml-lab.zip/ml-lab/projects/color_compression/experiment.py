"""颜色量化的分步计算；只调用当前模式提供的函数。"""
from io import BytesIO
import numpy as np
import pandas as pd
from PIL import Image


def rgb_array(value, shape, name):
    value = np.asarray(value, dtype=float)
    if value.shape != shape:
        raise ValueError(f'{name} 形状应为 {shape}，实际为 {value.shape}')
    if not np.isfinite(value).all() or np.any((value < 0) | (value > 1)):
        raise ValueError(f'{name} 必须是 0–1 范围内的有限数值')
    return value


def sample_pixels(image, seed=42):
    pixels = image.reshape(-1, 3)
    return pixels[np.random.default_rng(seed).choice(len(pixels), min(5000, len(pixels)), replace=False)].copy()


def fit(fn, image, colors, seed=42):
    sample = sample_pixels(image, seed)
    if not 1 <= colors <= len(sample):
        raise ValueError('颜色数不能超过抽样像素数')
    return rgb_array(fn.fit_palette(sample, colors, seed), (colors, 3), 'fit_palette 返回的调色板')


def rebuild(fn, image, palette):
    palette = rgb_array(palette, (len(palette), 3), '调色板')
    if not len(palette):
        raise ValueError('调色板不能为空')
    result = rgb_array(fn.reconstruct(image.copy(), palette.copy()), image.shape, 'reconstruct 返回的图片')
    # 分块核对颜色归属，避免整图与调色板的广播占用过多内存。
    flat = result.reshape(-1, 3)
    for start in range(0, len(flat), 2048):
        matches = np.isclose(flat[start:start+2048, None, :], palette[None, :, :], atol=1e-7).all(axis=2)
        if not matches.any(axis=1).all():
            raise ValueError('reconstruct 返回了调色板以外的颜色，请检查索引与 reshape')
    return result


def measure(fn, original, compressed):
    value = fn.mse(original.copy(), compressed.copy())
    if not np.isscalar(value) or not np.isfinite(value) or not 0 <= value <= 1:
        raise ValueError('mse 应返回 0–1 范围内的有限标量')
    return float(value)


def png_bytes(image):
    buffer = BytesIO()
    Image.fromarray(np.rint(image * 255).astype(np.uint8), 'RGB').save(buffer, format='PNG')
    return buffer.getvalue()


def run(fn, image, colors=8, seed=42):
    if not 2 <= colors <= image.shape[0] * image.shape[1]:
        raise ValueError('比较时颜色数至少为 2，且不能超过图片像素数；请减少颜色数或换一张更大的图片')
    variants, palettes, rows = {}, {}, []
    for k in sorted(set([2, 4, 8, 16, 32, colors])):
        if k > image.shape[0] * image.shape[1]:
            continue
        palette = fit(fn, image, k, seed)
        compressed = rebuild(fn, image, palette)
        variants[k], palettes[k] = compressed, palette
        n = image.shape[0] * image.shape[1]
        bits = max(1, int(np.ceil(np.log2(k))))
        rows.append(dict(colors=k, mse=measure(fn, image, compressed),
                         theoretical_ratio=n*24/(n*bits+k*24), png_bytes=len(png_bytes(compressed))))
    selected = next(row for row in rows if row['colors'] == colors)
    return dict(image=image.copy(), compressed=variants[colors], palette=palettes[colors],
                variants=variants, palettes=palettes, curve=pd.DataFrame(rows), metrics=selected)
