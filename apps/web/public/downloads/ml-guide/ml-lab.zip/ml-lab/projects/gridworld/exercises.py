"""在这里完成练习。参考实现位于 solutions/，页面不会自动代填。"""
import numpy as np


def choose_action(values, epsilon, rng):
    """按 epsilon-greedy 策略决定小车下一步做什么。
    
    为什么做：只选当前分数最高的动作可能错过更好的路线，因此保留 epsilon
    的概率随机试路；其余时候利用当前经验。Q 值是动作的预期累计回报。
    输入：values 为形状 (4,) 的数值数组，依次存放四个动作的 Q 值；
        epsilon 为 0～1 的探索概率；rng 为外部提供的 np.random.Generator。
    输出：Python int，范围 0～3，表示动作索引；方向解释由环境负责。
    要求：以 epsilon 概率从四个动作均匀随机选一个，否则从所有最高 Q 值
        对应的动作中均匀随机选择。探索时也可以恰好选到最优动作。
        只使用传入的 rng，不新建或重置种子，也不修改 values。
    例子：values=[1, 3, 3, 0] 且 epsilon=0 时，应在索引 1、2 之间随机选；
        epsilon=1 时四个动作都可能被选到，不要固定选第一个最大值。
    """
    # TODO 1: 用 rng 产生随机数，判断本次走探索分支还是利用分支。
    # TODO 2: 探索时在四个索引中均匀取样；利用时先找全体最大值索引，再随机取一个。
    # TODO 3: 返回 int 动作，不返回该动作的 Q 值。
    raise NotImplementedError('choose_action')


def update_value(current, reward, next_values, terminated, alpha=.2, gamma=.95):
    """用 Q-learning 更新当前状态下一个动作的价值。
    
    为什么做：一次行动给出即时奖励，并把小车带到下一格。Q-learning 用
    “即时奖励 + 下一格最好动作的折扣价值”作为目标，逐步修正原有估计。
    输入：current 是当前 Q(s,a) 标量；reward 是本次奖励标量；
        next_values 为下一状态四个动作的 Q 值数组 (4,)；
        terminated 为是否真正到达终止状态的 bool；alpha 为学习率（默认 .2），
        gamma 为未来奖励折扣（默认 .95），二者在 0～1。
    输出：Python float，更新后的单个 Q 值，由调用方写回 Q 表。
    要求：非终止时 target=reward+gamma*max(next_values)，终止时 target=reward；
        new=current+alpha*(target-current)。不修改传入数组。
        达到步数上限只是截断，仍传 terminated=False，不能把未来价值清零。
    例子：current=0、reward=10、terminated=True、alpha=.2 → 2.0，
        即使 next_values 很大也不能影响这个终止目标。
    """
    # TODO 1: 先根据 terminated 计算目标：到终点只看奖励，否则加入下一格最大价值。
    # TODO 2: 计算“目标减当前估计”的误差，用 alpha 控制本次修正幅度。
    # TODO 3: 返回更新后的 float；此函数不选择下一动作，也不更新整个 Q 表。
    raise NotImplementedError('update_value')


def exploration_rate(episode, episodes):
    """随训练进度逐渐降低随机试路的概率。
    
    为什么做：训练初期需要多试路，后期更多利用已有经验；保留少量探索，
    能避免完全停止尝试其他动作。
    输入：episode 为从 0 开始的当前回合编号，0<=episode<episodes；
        episodes 为计划训练的正整数回合数。
    输出：Python float，作为 choose_action 的 epsilon，范围 .05～1。
    要求：使用 max(.05, 1 - episode / (.8 * episodes))；
        这是按回合下降，不是按当前回合走了多少步下降；不产生随机数。
    例子：episodes=100 时，episode=0 → 1.0，40 → .5，76 及以后 → .05。
        注意约到总进度 76% 就触及下限，不是到 80% 才开始使用下限。
    """
    # TODO 1: 按当前回合占计划总回合的比例计算线性下降值，使用浮点除法。
    # TODO 2: 将结果的下限限制为 .05，再以 float 返回。
    raise NotImplementedError('exploration_rate')


def sarsa_update(current, reward, next_value, terminated, alpha=.2, gamma=.95):
    """用 SARSA 更新当前动作价值，把下一步实际行动也考虑进去。
    
    为什么做：小车接下来可能仍会随机探索。SARSA 使用策略实际选中的
    下一动作价值，而不是假定下一步一定选最优动作。
    输入：current、reward 为当前 Q 值和即时奖励标量；next_value 为下一状态
        已经选定的动作的 Q 值标量（不是四个值的数组）；
        terminated 为真正终止的 bool；alpha、gamma 为 0～1 的学习率和折扣。
    输出：更新后的 Python float，不在此选择动作或修改 Q 表。
    要求：非终止时 target=reward+gamma*next_value，终止时 target=reward；
        再用 current+alpha*(target-current) 更新。步数截断不等于真正终止。
    例子：current=0、reward=-1、next_value=2、alpha=.2、gamma=.95，
        非终止时得到 .18；即便其他动作更高，也只使用传入的 next_value。
    """
    # TODO 1: 依据是否真正终止，决定是否把实际下一动作的折扣价值加入目标。
    # TODO 2: 按学习率修正当前估计，返回 float，不对 next_value 求最大值。
    raise NotImplementedError('sarsa_update')


def expected_sarsa_update(current, reward, next_values, terminated, epsilon, alpha=.2, gamma=.95):
    """用 epsilon-greedy 策略下的下一步平均价值更新 Q 值。
    
    为什么做：Expected SARSA 不只看一次抽到的动作，而是按各动作被选中的
    概率计算期望，从而把随机探索的影响也计入目标。
    输入：current、reward 为标量；next_values 为下一状态 Q 值数组 (4,)；
        terminated 为真正终止的 bool；epsilon 为下一步策略的探索概率（0～1）；
        alpha、gamma 为 0～1 的学习率和折扣系数。
    输出：更新后的 Python float，不修改 next_values 或 Q 表。
    要求：探索部分以 epsilon/4 的概率分给每个动作；剩余 1-epsilon 的概率
        均分给价值最高的动作。因此期望为
        epsilon*mean(next_values)+(1-epsilon)*max(next_values)。
        非终止目标=reward+gamma*期望；终止目标=reward；
        最后按 current+alpha*(target-current) 更新。这里不需要随机抽动作。
    例子：next_values=[0, 0, 0, 4]、epsilon=.2 时，期望为 .2*1+.8*4=3.4；
        epsilon=0 时用最高价值，epsilon=1 时用四个动作的平均价值。
    """
    # TODO 1: 非终止时先求最高价值和平均价值，再按 epsilon 加权得到期望。
    # TODO 2: 组成目标；真正终止时只使用即时奖励，截断时仍保留未来项。
    # TODO 3: 计算学习率控制的单步修正，返回 float。
    raise NotImplementedError('expected_sarsa_update')
