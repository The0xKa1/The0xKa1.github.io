"""在这里完成练习。参考实现位于 solutions/，页面不会自动代填。"""
import numpy as np


def choose_action(values, epsilon, rng):
    """values 为四个 Q 值；rng 为 numpy Generator；返回 0..3。

    epsilon 概率随机探索；否则从所有最大值动作中随机选一个。
    """
    # TODO: 按 README 对应题目的规则完成；保存后可单独检查本题。
    raise NotImplementedError('choose_action')


def update_value(current, reward, next_values, terminated, alpha=.2, gamma=.95):
    """返回更新后的一个 Q 值，不修改数组。

    终止目标=reward；其他情况目标=reward+gamma*max(next_values)。
    达到回合步数上限是截断，仍用 terminated=False。
    """
    # TODO: 按 README 对应题目的规则完成；保存后可单独检查本题。
    raise NotImplementedError('update_value')


def exploration_rate(episode, episodes):
    """episode 从 0 开始；返回 max(.05, 1 - episode / (.8 * episodes))；约 76% 时达到下限。
    """
    # TODO: 按 README 对应题目的规则完成；保存后可单独检查本题。
    raise NotImplementedError('exploration_rate')
