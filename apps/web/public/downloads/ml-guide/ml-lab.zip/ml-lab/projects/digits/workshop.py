"""分题运行与网络练习的小规模输入。"""
from pathlib import Path
import re
import numpy as np
import pandas as pd
import streamlit as st
from common.runtime import load_functions, fingerprint
from common.checks import check_project
from common.ui import error
from .experiment import normalized, checked_evaluate


def lesson(stage):
    sections = re.split(r'^## ([0-6])\. .*$', Path(__file__).with_name('README.md').read_text(), flags=re.M)
    blocks = re.split(r'<details><summary>(.*?)</summary>(.*?)</details>', dict(zip(sections[1::2],sections[2::2]))[str(stage)], flags=re.S)
    st.markdown(blocks[0])
    for i in range(1,len(blocks),3):
        with st.expander(blocks[i]): st.markdown(blocks[i+1])
        st.markdown(blocks[i+2])


def check(name):
    if st.button(f'检查 {name}',key='digits_check_'+name):
        try:
            for report in check_project('digits',load_functions('digits','练习'),only=name):
                (st.success if report['passed'] else st.warning)(report['message'])
        except Exception as exc: error(exc)


def trial(stage,label,mode,params,compute):
    key='digits_trial_'+stage
    signature=fingerprint('digits',mode,dict(stage=stage,**params))
    if st.button(label,key='digits_run_'+stage):
        st.session_state.pop(key,None)
        try: st.session_state[key]=(signature,compute(load_functions('digits',mode)))
        except Exception as exc: error(exc)
    saved=st.session_state.get(key)
    if saved and saved[0]!=signature:
        st.info('本题代码、模式或输入已改变；旧结果待更新，请重新运行。')
        return None
    return saved[1] if saved else None


def network_preview(fn,hidden,seed):
    import torch
    torch.manual_seed(seed)
    model=fn.build_network(hidden)
    if not isinstance(model,torch.nn.Module): raise ValueError('build_network 应返回 PyTorch Module')
    with torch.no_grad(): logits=model(torch.zeros(1,1,28,28))
    if tuple(logits.shape)!=(1,10) or not torch.isfinite(logits).all():
        raise ValueError('网络应把 (1,1,28,28) 输入变成有限的 (1,10) 得分')
    return dict(structure=str(model),parameters=sum(p.numel() for p in model.parameters()),logits=logits.numpy()[0])


def step_preview(fn,images,targets,steps,learning_rate,seed):
    """提供线性模型与固定输入，仅考察读者的 train_step。"""
    import torch
    torch.manual_seed(seed)
    model=torch.nn.Sequential(torch.nn.Flatten(),torch.nn.Linear(784,10))
    optimizer=torch.optim.SGD(model.parameters(),lr=learning_rate)
    x=torch.tensor(images[:,None,:,:]/255,dtype=torch.float32)
    y=torch.tensor(targets,dtype=torch.long)
    original=[p.detach().clone() for p in model.parameters()]
    rows=[]
    with torch.no_grad():
        initial=float(torch.nn.functional.cross_entropy(model(x),y))
        before=torch.softmax(model(x[:1]),dim=1).numpy()[0]
    rows.append(dict(step=0,loss=initial))
    returned=[]
    for i in range(steps):
        loss=fn.train_step(model,optimizer,x,y)
        if not np.isscalar(loss) or not np.isfinite(loss) or loss<0:
            raise ValueError('train_step 应返回有限、非负的标量损失')
        returned.append(float(loss))
        with torch.no_grad(): current=float(torch.nn.functional.cross_entropy(model(x),y))
        if not np.isfinite(current): raise ValueError('训练后损失不是有限数值，请检查更新步骤或降低学习率')
        rows.append(dict(step=i+1,loss=current))
    with torch.no_grad(): after=torch.softmax(model(x[:1]),dim=1).numpy()[0]
    delta=sum(float((p.detach()-old).abs().sum()) for p,old in zip(model.parameters(),original))
    return dict(curve=pd.DataFrame(rows),returned=returned,before=before,after=after,delta=delta,target=int(targets[0]))


def evaluation_preview(fn):
    """提供固定 logits，独立运行 evaluate，不依赖其余练习。"""
    import torch
    model=torch.nn.Sequential(torch.nn.Flatten(),torch.nn.Linear(784,10))
    with torch.no_grad():
        model[1].weight.zero_();model[1].bias.copy_(torch.arange(10,dtype=torch.float32))
    pred,probs=checked_evaluate(fn,model,torch.zeros(2,1,28,28))
    expected=torch.softmax(torch.arange(10,dtype=torch.float32),dim=0).numpy()
    return dict(predictions=pred,probabilities=probs,expected=expected)
