# 酒精含量预测

坤坤把成分表里的 `alcohol` 列单独取出来，想用另外 12 项指标估计酒精含量。预测值和实测值差得多的样品，在残差图里会比较显眼，也方便翻回原表查原因。

## 先找预测偏得最远的样品

实测值和预测值相等时，点会落在虚线上。残差按实测减预测计算，零线上方表示低估，下方表示高估。选一个偏离明显的点，查看它的原始成分。再看不同 alpha 对应的误差和系数，判断增大正则化有没有改善验证结果。

## 填写函数

### `split_target`

把酒精含量单独取出作为目标，输入表中删除这一列。两边保留相同索引，避免成分与答案错行。

<details><summary>可用的接口</summary>

X=data.drop(columns="alcohol")；y=data["alcohol"]。

</details>

### `errors`

残差用实测值减预测值，保留正负号。计算 MAE 时，再把残差取绝对值后求平均。

<details><summary>可用的接口</summary>

np.asarray(actual)-np.asarray(predicted)；np.abs(...).mean()。

</details>

### `build_model`

返回标准化与岭回归的管道。每一折开始训练时，都只用这一折的训练数据重新拟合缩放器。

<details><summary>可用的接口</summary>

用 make_pipeline(StandardScaler(), Ridge(alpha=alpha)) 返回未拟合模型。

</details>

### `select_alpha`

从 valid_mae 最小的一行取出 alpha。训练误差可以用来观察拟合情况，选参数要看验证误差。

<details><summary>可用的接口</summary>

idxmin() 找到最小验证误差所在行，再取 alpha。

</details>

## 接着试什么

只选两三项成分运行，再恢复全部 12 项，保存两次结果，比较五折验证误差及其波动。把均值基线、普通线性回归和岭回归放在一起看，选定配置后再评价测试集。

保存 `exercises.py`，点“检查练习”后切到练习模式运行。遇到未完成的函数，页面会显示名称；检查失败会列出输入和预期结果。实验记录可以下载，建议给每次比较写一两句解释。参考实现见 `solutions/wine_regression.py`。
