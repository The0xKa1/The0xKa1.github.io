# 葡萄酒分类

坤坤拿到一张葡萄酒成分表：178 条记录，每条有 13 项指标，分属 3 个类别。只看酒精、苹果酸或总酚，很难逐条判断。他用一部分带标签的记录训练模型，把余下的数据留作验证和测试，认错的样品再翻回成分表里看。

## 两项成分够不够

运行后先看多数类基线，再比较逻辑回归和决策树。上方图只使用选中的两项成分，背景是这个两特征模型的分类结果；下方另列完整 13 特征模型的成绩。换两个坐标轴，看哪些类别开始混在一起。选中错分点，可以查它的成分和各类概率。

## 填写函数

### `split_data`

测试集已经留出。这个函数收到余下的开发数据，需要从中划出四分之一作为验证集，并保持各类别的比例。

<details><summary>可用的接口</summary>

train_test_split(..., test_size=.25, stratify=y, random_state=seed)。

</details>

### `build_model`

把缩放器和分类器放进同一个管道，只在训练时 fit。预测时沿用训练集的均值和标准差，不能重新计算。

<details><summary>可用的接口</summary>

Pipeline 或 make_pipeline；StandardScaler 后接 LogisticRegression。

</details>

### `evaluate`

返回预测正确的比例、混淆矩阵和错分位置。这里的位置是数组下标，与原表中的样本编号要分清楚。

<details><summary>可用的接口</summary>

np.flatnonzero；confusion_matrix(..., labels=[0,1,2]) 保持三类矩阵形状。

</details>

### `compare_depths（进阶）`

每换一个深度，都重新训练一棵树，记下训练准确率和验证准确率。这样才能看出树变深后改善了哪一部分。

<details><summary>可用的接口</summary>

DecisionTreeClassifier(max_depth=depth, random_state=seed)。

</details>

## 接着试什么

打开树深度对照，找出训练准确率继续增加、验证准确率却不再改善的位置。根据验证结果选好配置后，再评价测试集。保存两次配置不同的记录，说明你为什么选择其中一个；测试分数不能再拿来反复选配置。

保存 `exercises.py`，点“检查练习”后切到练习模式运行。遇到未完成的函数，页面会显示名称；检查失败会列出输入和预期结果。实验记录可以下载，建议给每次比较写一两句解释。参考实现见 `solutions/wine_classification.py`。
