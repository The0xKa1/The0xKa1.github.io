"""各阶段的说明、独立运行与照片选区。"""
from pathlib import Path
import re
import numpy as np
import streamlit as st
from common.checks import check_project
from common.runtime import fingerprint, load_functions
from common.ui import error
from common.image_ui import show_image
from projects.image_lab.pixel_editor import pixel_canvas


def lesson(stage):
    sections = re.split(r'^## ([0-4])\. .*$', Path(__file__).with_name('README.md').read_text(), flags=re.M)
    text = dict(zip(sections[1::2], sections[2::2]))[str(stage)]
    blocks = re.split(r'<details><summary>(.*?)</summary>(.*?)</details>', text, flags=re.S)
    st.markdown(blocks[0])
    for i in range(1, len(blocks), 3):
        with st.expander(blocks[i]): st.markdown(blocks[i+1])
        st.markdown(blocks[i+2])


def check(name):
    if st.button(f'检查 {name}', key='color_check_'+name):
        try:
            for report in check_project('color_compression', load_functions('color_compression', '练习'), only=name):
                (st.success if report['passed'] else st.warning)(report['message'])
        except Exception as exc: error(exc)


def trial(stage, label, mode, params, compute):
    key = 'color_trial_'+stage
    signature = fingerprint('color_compression', mode, dict(stage=stage, **params))
    if st.button(label, key='color_run_'+stage):
        st.session_state.pop(key, None)
        try: st.session_state[key] = (signature, compute(load_functions('color_compression', mode)))
        except Exception as exc: error(exc)
    saved = st.session_state.get(key)
    if saved and saved[0] != signature:
        st.info('代码、模式或输入已改变；本题旧结果待更新，请重新运行。')
        return None
    return saved[1] if saved else None


def swatches(palette, key):
    st.caption('调色板：从左到右编号 0、1、2…')
    blocks = []
    for i, color in enumerate(palette):
        rgb = ','.join(str(int(v)) for v in np.rint(color*255))
        blocks.append(f'<div style="flex:1;min-width:12px;text-align:center"><div title="颜色 {i} · RGB {rgb}" style="height:40px;background:rgb({rgb});border:1px solid #999"></div><small>{i}</small></div>')
    st.markdown('<div style="display:flex;gap:3px;margin-bottom:16px">'+''.join(blocks)+'</div>',unsafe_allow_html=True)


def region(image, digest, key):
    state_key = key+'_selection_'+digest
    previous = st.session_state.get(state_key)
    selected = pixel_canvas(image, previous, key+'_'+digest)
    st.session_state[state_key] = selected
    if selected is None:
        h, w = image.shape[:2]
        selected = [w//3, h//3, max(w//3+1, 2*w//3), max(h//3+1, 2*h//3)]
        st.caption('尚未框选，下面先显示中央区域。点击选一个像素，拖动可选择矩形区域。')
    x0, y0, x1, y1 = selected
    return np.s_[y0:y1, x0:x1], (y0, x0)


def compare(arrays, names, key):
    with st.container(key='color_comparison_'+key):
        for i, (col, array, name) in enumerate(zip(st.columns(len(arrays)), arrays, names)):
            with col: show_image(array, name, f'{key}_{i}')
