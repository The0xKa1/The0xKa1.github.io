"""直接在照片上框选像素；坐标使用左闭右开的数组切片。"""
import base64
from io import BytesIO
import numpy as np
from PIL import Image
import streamlit.components.v2 as components


CANVAS_JS = r'''
export default function({data, parentElement, setStateValue}) {
  const canvas = parentElement.querySelector('canvas');
  const status = parentElement.querySelector('[role="status"]');
  const ctx = canvas.getContext('2d');
  const w = data.width, h = data.height, scale = 4;
  canvas.width = w * scale; canvas.height = h * scale;
  let selection = data.selection, start = null, image = new Image(), disposed = false;
  function draw() {
    ctx.imageSmoothingEnabled = false;
    ctx.clearRect(0,0,canvas.width,canvas.height);
    if (image.complete && image.naturalWidth) ctx.drawImage(image,0,0,canvas.width,canvas.height);
    if (selection) {
      const [x0,y0,x1,y1] = selection;
      ctx.strokeStyle = 'white'; ctx.lineWidth = 4;
      ctx.strokeRect(x0*scale,y0*scale,(x1-x0)*scale,(y1-y0)*scale);
      ctx.strokeStyle = '#2563a6'; ctx.lineWidth = 2;
      ctx.strokeRect(x0*scale,y0*scale,(x1-x0)*scale,(y1-y0)*scale);
      status.textContent = `已框选 ${x1-x0} × ${y1-y0} 像素 · 列 ${x0}–${x1-1}，行 ${y0}–${y1-1}`;
    } else status.textContent = '在照片上按住鼠标拖出一个矩形；单击可选一个像素。';
  }
  function point(event) {
    const r = canvas.getBoundingClientRect();
    return [Math.max(0,Math.min(w-1,Math.floor((event.clientX-r.left)/r.width*w))),
            Math.max(0,Math.min(h-1,Math.floor((event.clientY-r.top)/r.height*h)))];
  }
  function rectangle(end) {
    return [Math.min(start[0],end[0]),Math.min(start[1],end[1]),
            Math.max(start[0],end[0])+1,Math.max(start[1],end[1])+1];
  }
  canvas.onpointerdown = event => {
    if (event.button !== 0) return;
    event.preventDefault(); canvas.focus(); canvas.setPointerCapture(event.pointerId);
    start = point(event); selection = rectangle(start); draw();
  };
  canvas.onpointermove = event => {
    if (start) {selection = rectangle(point(event)); draw();}
  };
  canvas.onpointerup = event => {
    if (!start) return;
    selection = rectangle(point(event)); start = null;
    canvas.releasePointerCapture(event.pointerId); draw();
    setStateValue('selection',selection);
  };
  canvas.onpointercancel = () => { start = null; selection = data.selection; draw(); };
  canvas.onkeydown = event => {
    if (event.key === 'Escape') {selection = null; start = null; draw(); setStateValue('selection',null);}
  };
  image.onload = () => {if (!disposed) draw();};
  image.src = data.image;
  draw();
  return () => {disposed = true; image.onload = null;
    canvas.onpointerdown = canvas.onpointermove = canvas.onpointerup = canvas.onpointercancel = canvas.onkeydown = null;};
}
'''



def normalize_selection(selection, shape):
    if selection is None:
        return None
    if not isinstance(selection,(list,tuple)) or len(selection) != 4:
        raise ValueError('选区必须包含四个整数坐标')
    if any(isinstance(v,bool) or not isinstance(v,(int,np.integer)) for v in selection):
        raise ValueError('选区坐标必须为整数')
    x0,y0,x1,y1 = map(int,selection)
    height,width = shape[:2]
    if not 0 <= x0 < x1 <= width or not 0 <= y0 < y1 <= height:
        raise ValueError('选区超出图片范围')
    return [x0,y0,x1,y1]


def paint_region(image, selection, color):
    x0,y0,x1,y1 = normalize_selection(selection,image.shape)
    rgb = np.asarray(color,dtype=float)
    if rgb.shape != (3,) or not np.isfinite(rgb).all() or np.any((rgb < 0)|(rgb > 1)):
        raise ValueError('颜色应是 0–1 范围内的 RGB 三个数')
    result = image.copy()
    result[y0:y1,x0:x1] = rgb
    return result


def pixel_canvas(image, selection, key):
    buffer = BytesIO()
    Image.fromarray(np.rint(image*255).astype(np.uint8)).save(buffer,format='PNG')
    encoded = base64.b64encode(buffer.getvalue()).decode('ascii')
    # Register in the active Streamlit runtime (also works across AppTest runtimes).
    pixel_canvas_component = components.component(
        'image_lab_pixel_canvas',
        html='<canvas tabindex="0" role="img" aria-label="框选像素的照片画布"></canvas><p role="status" aria-live="polite"></p>',
        css='canvas{display:block;width:100%;max-width:768px;height:auto;cursor:crosshair;touch-action:none;image-rendering:pixelated;border-radius:4px}canvas:focus-visible{outline:2px solid #2563a6;outline-offset:3px}p{font:inherit;color:inherit;margin:10px 0}',
        js=CANVAS_JS,
    )
    result = pixel_canvas_component(key=key,data=dict(image='data:image/png;base64,'+encoded,
                                    width=image.shape[1],height=image.shape[0],selection=selection),
                                    default={'selection':None},on_selection_change=lambda:None)
    return normalize_selection(result.selection,image.shape)
