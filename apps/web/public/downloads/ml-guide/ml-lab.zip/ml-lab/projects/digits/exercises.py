"""在这里完成练习。参考实现位于 solutions/，页面不会自动代填。"""
import numpy as np

def normalize(images):
    """把原始灰度像素整理成卷积网络能接收的格式。
    
    为什么做：像素统一缩放到 0～1，便于网络训练；补上通道维度后，
    卷积层才能按“批次、通道、高、宽”读取图片，而不是把图片当成一串数字。
    
    输入：
        images：NumPy 数组，形状 (N, 28, 28)，N 是图片张数。
        每个像素是 0～255 的有限数值；0 表示黑色，255 表示白色。
    输出：
        新的 np.float32 数组，形状 (N, 1, 28, 28)，数值在 0～1。
        新增的 1 表示一个灰度通道，图片和像素的顺序保持不变。
    要求：
        只能除以固定的 255，不能除以这批图片的最大值，也不做均值标准化。
        形状不符、像素越界、含 NaN 或无穷大时，抛出 ValueError。
        不修改原数组；空批次 (0, 28, 28) 也要返回 (0, 1, 28, 28)。
    例子：两张图片输入 (2, 28, 28)，输出 (2, 1, 28, 28)；
        像素 0 → 0.0，255 → 1.0，128 → 约 0.502。
    """
    # TODO 1: 检查数组维数和后两个维度，再检查像素是否有限且处于合法范围。
    # TODO 2: 转换成 float32，添加通道轴；保留 28×28 的行列结构，不要展平。
    # TODO 3: 按固定比例缩放并返回新数组；不要用裁剪掩盖非法输入。
    raise NotImplementedError('normalize')

def build_network(hidden=128):
    """组装一个从笔画特征预测数字的卷积神经网络。
    
    为什么做：卷积提取局部笔画，池化缩小特征图，全连接层综合特征，
    最后为 0～9 十个数字分别给出一个分数。权重会在后续训练中学习。
    
    输入：hidden 是正整数，表示全连接隐藏层的宽度，默认 128。
    输出：一个尚未训练的 torch.nn.Module；本函数不读取数据、不训练。
        网络接收 float32 Tensor (N, 1, 28, 28)，输出 Tensor (N, 10)。
        第 i 行第 j 列是第 i 张图属于数字 j 的原始分数（logit）。
    要求：
        两组 Conv2d → ReLU → MaxPool2d；卷积核 3×3、步长 1、padding=1，
        通道依次为 1→16→32；池化窗口和步长都是 2。
        再接 Flatten → Linear(1568, hidden) → ReLU → Linear(hidden, 10)。
        输出是 logits，不加 softmax：训练用的交叉熵已包含相应计算。
    维度检查：28×28 → 14×14 → 7×7，展平后每张图有 32×7×7=1568 个值。
        例如 N=3 时，输出必须是 (3, 10)，不能把批次轴也展平。
    """
    # TODO 1: 在函数内导入 torch.nn（没有安装 PyTorch 时，其他项目仍应能打开）。
    # TODO 2: 按指定通道数搭建两组卷积、激活和池化，可以用 nn.Sequential 串联。
    # TODO 3: 从特征维开始展平，接隐藏层和十分类输出层，返回网络对象。
    raise NotImplementedError('build_network')

def train_step(model, optimizer, x, y):
    """让模型用一小批带标签的图片学习一次。
    
    为什么做：交叉熵衡量预测与正确标签的差距，反向传播计算梯度，
    优化器用梯度调整参数。PyTorch 会累加梯度，所以每批都要先清空。
    
    输入：
        model：输出 (N, 10) logits 的网络；optimizer：绑定其参数的优化器。
        x：已归一化的 float32 Tensor，形状 (N, 1, 28, 28)，N>0。
        y：long Tensor，形状 (N,)，每项是 0～9 的正确类别，不是 one-hot。
        model、x、y 已放在同一设备上，函数不负责加载数据或创建优化器。
    输出：Python float，表示本次前向计算的平均交叉熵损失。
    要求：
        切到训练模式；每次调用恰好执行一次参数更新。
        返回本批更新前算出的损失，不在更新后重新计算；不返回 Tensor。
        允许更新模型参数和优化器状态，不修改 x、y。
    例子：32 张图片调用一次就是一个训练步，不是训练完整个数据集。
    """
    # TODO 1: 调用 model.train()，再用 optimizer.zero_grad() 清除上一批的梯度。
    # TODO 2: 前向计算 logits，并用 cross_entropy(logits, y) 得到平均损失。
    # TODO 3: 对损失反向传播，再调用 optimizer.step() 更新参数。
    # TODO 4: 将已计算的损失脱离计算图，转换成 Python float 后返回。
    raise NotImplementedError('train_step')

def evaluate(model, x):
    """固定模型参数，输出每张图片的预测数字和类别概率。
    
    为什么做：评价时只观察模型，不能继续学习。eval 切换层的运行模式，
    no_grad 关闭梯度记录；两者作用不同，这里都需要。
    
    输入：model 为十分类网络；x 为 float32 Tensor (N, 1, 28, 28)，
        像素已在 0～1，且和模型处于同一设备。
    输出：二元组 (predictions, probabilities)，两项都是 NumPy 数组。
        predictions：形状 (N,) 的整数数组，每项是预测的数字 0～9。
        probabilities：形状 (N, 10)，第 j 列对应数字 j，每行概率之和约为 1。
    要求：沿类别轴做 softmax，再取每行最大概率的位置作为预测；
        不能沿批次轴归一化。不更新参数，也不执行 backward 或 optimizer.step。
    例子：某张图第 7 列概率最大，它的预测就是 7；结果顺序与输入图片一致。
    """
    # TODO 1: 切换 model.eval()，在 torch.no_grad() 上下文中运行前向计算。
    # TODO 2: 沿 dim=1 将 logits 转换为概率，再移到 CPU 并转成 NumPy 数组。
    # TODO 3: 沿每行求 argmax，按“预测、概率”的顺序返回两个数组。
    raise NotImplementedError('evaluate')
