import numpy as np
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier

def build_model(kind, complexity, seed=42):
    """创建用于比较分类边界的模型。
    
    为什么做：同一批点可以用不同模型划分。先统一特征尺度，再比较模型
    复杂度如何影响边界；创建与训练分开，才能只用训练数据学习参数。
    
    输入：kind 为“逻辑回归”“决策树”或“RBF 核方法”之一；
        complexity 为正数，决策树时表示正整数最大深度，其他模型时表示 C；
        seed 为随机种子，默认 42。
    输出：未拟合的 sklearn Pipeline，顺序为 StandardScaler → 分类器。
    要求：逻辑回归使用 C=complexity、max_iter=2000；
        决策树使用 max_depth=int(complexity)、random_state=seed；
        RBF 使用 SVC 的 RBF 核、C=complexity、gamma='scale'、
        probability=True、random_state=seed。未知 kind 抛 ValueError。
        这里不调用 fit；标准化参数留到训练管道时再学习。
    例子：决策树 complexity=3 表示最多三层分裂深度；C 越大，正则约束越弱。
    """
    # TODO 1: 按 kind 选择分类器，设置该模型对应的复杂度和随机种子。
    # TODO 2: 处理未知名称；把 StandardScaler 与分类器按顺序放进管道。
    # TODO 3: 返回管道对象，不要返回预测结果，也不要在此训练。
    raise NotImplementedError('build_model')

def accuracy(actual, predicted):
    """计算模型答对的样本比例。
    
    为什么做：边界图只能帮助观察，准确率可以量化模型在一批样本上的表现。
    输入：actual 和 predicted 为等长、非空的一维标签数组或列表，
        形状均为 (N,)，相同位置对应同一个样本。
    输出：Python float，范围 0～1，即正确个数 / N，不是百分数 0～100。
    要求：按位置比较标签，不排序，不修改输入；不要返回正确个数。
    例子：[0, 1, 1] 与 [0, 0, 1] 得到 2/3；全部答对得到 1.0。
    """
    # TODO 1: 将输入整理为一维数组，逐项比较真实标签和预测标签。
    # TODO 2: 统计相等项的比例，转换为 Python float 后返回。
    raise NotImplementedError('accuracy')
