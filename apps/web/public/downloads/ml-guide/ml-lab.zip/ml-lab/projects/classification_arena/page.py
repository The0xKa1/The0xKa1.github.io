import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st
from common.charts import chart,COLORS,matrix
from common.ui import run_panel,sample_detail,error,record_final
from common.runtime import load_functions
from sklearn.metrics import confusion_matrix
from .experiment import run,final_test,KINDS,data,preview
from .workshop import lesson,check,trial

def boundary(r,name):
    axes=r['axes'];z=r['boundaries'][name]
    fig=go.Figure(go.Contour(x=axes[0],y=axes[1],z=z,contours=dict(start=.5,end=.5,size=1),colorscale=[[0,COLORS[0]],[1,COLORS[1]]],opacity=.16,showscale=False,hoverinfo='skip'))
    for label in [0,1]:
        ids=r['valid'][r['y'].loc[r['valid']].to_numpy()==label];X=r['X'].loc[ids]
        fig.add_scatter(x=X.iloc[:,0],y=X.iloc[:,1],mode='markers',name=f'类别 {label}',customdata=ids,marker=dict(color=COLORS[label],symbol=['circle','diamond'][label],size=7),hovertemplate='样本 %{customdata}<extra></extra>')
    wrong=r['valid'][r['predictions'][name]!=r['y'].loc[r['valid']].to_numpy()]
    fig.add_scatter(x=r['X'].loc[wrong].iloc[:,0],y=r['X'].loc[wrong].iloc[:,1],mode='markers',name='错分',customdata=wrong,marker=dict(color='#253044',symbol='x-open',size=12),hovertemplate='错分样本 %{customdata}<extra></extra>')
    fig.update_layout(title=name,height=360,xaxis_title='特征 1',yaxis_title='特征 2',legend=dict(orientation='h',y=-.3,x=0))
    fig.update_xaxes(range=[axes[0][0],axes[0][-1]],constrain='domain');fig.update_yaxes(range=[axes[1][0],axes[1][-1]],scaleanchor='x',scaleratio=1,constrain='domain')
    return fig

def render(mode):
    st.markdown('''<style>
    @media (max-width: 1000px) {
      .st-key-arena_comparison [data-testid="stHorizontalBlock"] {flex-direction:column;}
      .st-key-arena_comparison [data-testid="stColumn"] {width:100%!important;flex:1 1 100%!important;}
    }
    </style>''',unsafe_allow_html=True)
    tabs=st.tabs(['0 · 看懂数据','1 · 算准确率','2 · 做出分类器','3 · 同场比较','4 · 选模型与错分'],key='arena_stage',on_change='rerun')
    with tabs[0]:
        lesson(0)
        a,b=st.columns(2)
        shape=a.selectbox('点集形状',['同心圆','月牙','交叉棋盘'],key='arena_shape')
        noise=b.slider('数据噪声',0.,.45,.15,step=.05,key='arena_noise')
        seed=st.number_input('数据种子',0,9999,42,key='arena_seed')
        X,y,train,valid,test=data(shape,noise,seed)
        fig=go.Figure()
        for label in [0,1]:
            ids=train[y.loc[train].to_numpy()==label]
            fig.add_scatter(x=X.loc[ids].iloc[:,0],y=X.loc[ids].iloc[:,1],mode='markers',name=f'类别 {label}',marker=dict(color=COLORS[label],symbol=['circle','diamond'][label]))
        fig.update_layout(height=400,xaxis_title='特征 1',yaxis_title='特征 2')
        fig.update_yaxes(scaleanchor='x',scaleratio=1)
        chart(fig,key='arena_data')
        st.radio('你的猜测：一条直线能把两类点分得很好吗？',['先试试看','应该可以','可能需要弯曲或分块的边界'],key='arena_guess')
    with tabs[1]:
        lesson(1)
        check('accuracy')
        actual=[0,1,1,0]
        columns=st.columns(4)
        predicted=[col.selectbox(f'第 {i+1} 个：真实类别 {value}',[0,1],index=[0,0,1,0][i],key=f'arena_hand_{i}') for i,(col,value) in enumerate(zip(columns,actual))]
        answer=trial('accuracy','运行我的计分函数',mode,dict(predicted=predicted),lambda fn:fn.accuracy(actual,predicted))
        if answer is not None:
            st.write(f'函数返回：{answer}')
            correct=sum(a==b for a,b in zip(actual,predicted));expected=correct/4
            st.write(f'逐项核对：{correct} 个正确 ÷ 4 = {expected:.2f}')
            if np.isscalar(answer) and np.isclose(answer,expected): st.success('与手算一致。')
            else: st.warning('与手算不一致，请检查逐项比较和分母。')
    with tabs[2]:
        lesson(2)
        check('build_model')
        name=st.selectbox('先观察哪种模型',KINDS,key='arena_preview_model')
        value=st.select_slider('最大树深' if name=='决策树' else '正则参数 C',[1.,2.,3.,5.,10.,20.],value=3.,key='arena_preview_value')
        st.caption(f'当前点集：{shape}，噪声 {noise:g}，种子 {seed}。在第 0 阶段修改。')
        result=trial('model','训练这个模型并画出边界',mode,dict(shape=shape,noise=noise,seed=seed,name=name,value=value),lambda fn:preview(fn,shape,noise,seed,name,value))
        if result is not None:
            chart(boundary(result,name),key='arena_preview')
            st.caption('背景是模型划分的区域；黑色叉号标出验证集中分错的点。')
    with tabs[3]:
        lesson(3)
        st.caption(f'当前点集：{shape} · 噪声 {noise:g} · 种子 {seed}。换点集请到第 0 阶段。')
        columns=st.columns(3)
        values={}
        for column,name,label in zip(columns,KINDS,['逻辑回归的 C','决策树的最大深度','RBF 核方法的 C']):
            values[name]=column.select_slider(label,[1.,2.,3.,5.,10.,20.],value=3.,key='arena_parameter_'+name)
        st.caption('一次只改一个参数。C 控制正则约束，树深控制切分层数；数值相同不代表复杂度相同。')
        r=run_panel('classification_arena',mode,dict(shape=shape,noise=noise,complexity=values,seed=seed),lambda fn:run(fn,shape,noise,values,seed))
        if r is not None:
            with st.container(key='arena_comparison'):
                for col,name in zip(st.columns(3),KINDS):
                    with col:
                        chart(boundary(r,name),key='arena_'+name)
                        row=r['scores'].set_index('model').loc[name]
                        st.write(f"训练 {row.train_accuracy:.1%} · 验证 {row.valid_accuracy:.1%}")
            scores=r['scores'].rename(columns=dict(model='模型',train_accuracy='训练准确率',valid_accuracy='验证准确率'))
            st.dataframe(scores,hide_index=True,column_config={x:st.column_config.NumberColumn(format='percent') for x in ['训练准确率','验证准确率']})
            st.caption('训练 360 点 · 验证 120 点。要把错分位置放大查看，进入第 4 阶段。')
    with tabs[4]:
        lesson(4)
        if r is None:
            st.info('先在第 3 阶段运行对照，再来检查错分和选择模型。')
            return
        name=st.selectbox('根据验证结果选择模型',list(r['models']),index=1,key='arena_choice')
        event=chart(boundary(r,name),key='arena_inspect',select=True)
        points=event.selection.points if event else []
        selected=points[0].get('customdata') if points else None
        if isinstance(selected,(list,tuple)): selected=selected[0]
        X=r['X'].loc[r['valid']];actual=r['y'].loc[r['valid']];pred=r['predictions'][name]
        table=X.assign(真实类别=actual,预测类别=pred)
        wrong=st.checkbox('仅查看错分',True)
        shown=table[table['真实类别']!=table['预测类别']] if wrong else table
        if shown.empty: st.success('当前验证集没有错分；取消筛选可以查看其他样本。')
        else:
            idx=sample_detail(shown,'arena_sample',selected)
            prob=r['models'][name].predict_proba(X.loc[[idx]])[0]
            chart(px.bar(x=['类别 0','类别 1'],y=prob,labels=dict(x='类别',y='模型给出的概率')).update_yaxes(range=[0,1]))
        with st.expander('查看混淆矩阵：哪一类容易认错？'):
            st.caption('行是真实类别，列是预测类别；对角线是正确分类。')
            chart(matrix(confusion_matrix(actual,pred,labels=[0,1]),['0','1']))
        note=st.text_area('为什么选择这个模型？',placeholder='结合验证准确率和一个具体错分位置说明。',key='arena_note')
        if st.button('确定模型并评价测试集',key='arena_test'):
            try:
                value=final_test(load_functions('classification_arena',mode),r,name)
                record_final('classification_arena',mode,r,{'model':name,'test_accuracy':value},{})
                st.session_state['arena_final']=(r['_signature'],name,value)
            except Exception as exc: error(exc)
        final=st.session_state.get('arena_final')
        if final and final[:2]==(r['_signature'],name):
            st.metric('最终测试准确率',f'{final[2]:.1%}')
            report=f'模型：{name}\n点集：{shape}；噪声：{noise}；种子：{seed}\n参数：{values}\n测试准确率：{final[2]:.1%}\n理由：{note}\n'
            st.download_button('下载我的选择和结果',report,'classification-choice.txt',mime='text/plain')
