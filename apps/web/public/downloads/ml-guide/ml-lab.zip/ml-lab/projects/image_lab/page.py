from pathlib import Path
import hashlib
import numpy as np
import streamlit as st
from common.pictures import read_image
from common.ui import error, run_panel
from .experiment import call_image, denoise
from .workshop import (stage_lesson, exercise_check, stage_run, picture,
                       compare_pictures, pixel_lab, gray_input, filter_pair,
                       filter_handwork, inspect_pair, coordinate, png_bytes)


def render(mode):
    upload = st.file_uploader('换成自己的图片（PNG / JPG，自动缩小）', type=['png','jpg','jpeg'], key='image_upload')
    try:
        image = read_image(upload if upload is not None else Path(__file__).with_name('assets')/'fruit-photo.jpg')
    except Exception as exc:
        error(exc)
        return
    digest = hashlib.sha256(image.tobytes()).hexdigest()
    st.caption('默认照片：George Chernilevsky · [Fruit on a plate](https://commons.wikimedia.org/wiki/File:Fruit_on_a_plate_2019_G1.jpg) · Public domain。上传照片只在本机处理。')
    tabs = st.tabs(['0 · 像素里的数字', '1 · 黑白照片', '2 · 调亮与细节',
                    '3 · 去掉噪点', '4 · 观察轮廓', '5 · 选一个更好的结果'],
                   key='image_active_stage', on_change='rerun')
    with tabs[0]:
        stage_lesson(0)
        image = pixel_lab(image, digest)
    digest = hashlib.sha256(image.tobytes()).hexdigest()
    with tabs[1]:
        stage_lesson(1)
        exercise_check('grayscale', 1)
        source = st.radio('灰度题输入', ['当前图片', '红绿蓝与白色色块'], horizontal=True)
        colors = np.array([[[1.,0.,0.], [0.,1.,0.], [0.,0.,1.], [1.,1.,1.]]])
        original = image if source == '当前图片' else colors
        result = stage_run('gray', '生成我的灰度图', mode, dict(image=digest, source=source),
                           lambda fn: call_image(fn, 'grayscale', original))
        if result is not None:
            compare_pictures([original, result], ['输入 RGB', '函数返回的灰度图'], 'gray')
            if source != '当前图片':
                st.write('函数返回：', result.tolist())
                st.caption('按题目权重核对：[[0.2126, 0.7152, 0.0722, 1.0]]。')
    with tabs[2]:
        stage_lesson(2)
        exercise_check('adjust', 2)
        brightness = st.slider('亮度偏移', -.5, .5, 0., .05, key='image_brightness')
        contrast = st.slider('对比度', 0., 3., 1., .1, key='image_contrast')
        def adjust_trial(fn):
            adjusted = call_image(fn, 'adjust', image, brightness, contrast)
            restored = call_image(fn, 'adjust', adjusted, -brightness/contrast, 1/contrast) if contrast else None
            return dict(adjusted=adjusted, restored=restored)
        adjusted = stage_run('adjust', '运行调色与反向调节', mode,
                             dict(image=digest, brightness=brightness, contrast=contrast), adjust_trial)
        if adjusted is not None:
            arrays, names = [image, adjusted['adjusted']], ['输入图', '调节后']
            if adjusted['restored'] is not None:
                arrays.append(adjusted['restored']); names.append('反向调节后')
            compare_pictures(arrays, names, 'adjust')
            values = adjusted['adjusted']
            st.write(f'输出通道值中，等于 0 的占 {np.mean(values == 0):.1%}，等于 1 的占 {np.mean(values == 1):.1%}。')
            st.caption('统计单位是 R/G/B 通道值，包含原本已在边界的值；它不是新增裁剪像素比例。')
            if contrast == 0:
                st.info('对比度为 0 时所有输入变成同一值，无法反向调节。')
            else:
                st.caption('反向参数：亮度 −b/c，对比度 1/c；同样调用当前模式的 adjust。发生裁剪后不能保证还原。')
    with tabs[3]:
        stage_lesson(3)
        exercise_check('mean_filter', 3)
        filter_handwork(mode)
        st.subheader('同一份噪声，两个窗口')
        filter_source = st.radio('滤波题输入', ['已提供的二维阶跃图', '当前图片（需要 grayscale）'], key='filter_source')
        use_photo = filter_source.startswith('当前')
        noise = st.slider('模拟噪声强度', 0., .5, .12, .01, key='image_noise')
        seed = st.number_input('噪声种子', 0, 9999, 42, key='image_seed')
        a,b = st.columns(2)
        size = a.select_slider('窗口 A', [1,3,5,9,15], value=3, key='image_size_a')
        size_b = b.select_slider('窗口 B', [1,3,5,9,15], value=9, key='image_size_b')
        params = dict(image=digest, use_photo=use_photo, noise=noise, seed=seed, sizes=[size,size_b])
        result = stage_run('filter', '比较两个滤波窗口', mode, params,
                           lambda fn: filter_pair(fn,image,use_photo,noise,seed,[size,size_b],True))
        if result is not None:
            inspect_pair(result, [size,size_b], 'filter', True)
    with tabs[4]:
        stage_lesson(4)
        exercise_check('edge_strength', 4)
        edge_source = st.radio('边缘题输入', ['已提供的二维阶跃图（仅需 edge_strength）',
                               '照片的降噪对照（需要 grayscale、mean_filter）'], key='edge_source')
        photo_edges = edge_source.startswith('照片')
        st.caption(f'照片对照沿用第 3 阶段的噪声强度 {noise:g}、种子 {seed}、窗口 A={size}。')
        def edges(fn):
            gray = gray_input(fn,image,photo_edges)
            if not photo_edges:
                return dict(inputs=[gray], outputs=[call_image(fn,'edge_strength',gray)])
            result = denoise(fn,gray,noise,size,seed)
            inputs = [result['gray'],result['noisy'],result['smooth']]
            return dict(inputs=inputs,outputs=[call_image(fn,'edge_strength',x) for x in inputs])
        result = stage_run('edge', '查看当前函数的边缘图', mode,
                           dict(image=digest,photo=photo_edges,noise=noise,seed=seed,size=size), edges)
        if result is not None:
            names = ['加噪前','加噪后','滤波后'] if photo_edges else ['二维阶跃图']
            compare_pictures(result['inputs'],names,'edge_inputs')
            compare_pictures(result['outputs'],[s+' · 边缘' for s in names],'edge_outputs',edge=True)
            st.caption('边缘强度统一显示为 0–√2，亮度代表相邻像素变化大小，不代表物体类别。')
    with tabs[5]:
        stage_lesson(5)
        left,right = st.columns(2)
        windows = [1,3,5,9,15]
        first = left.selectbox('第一张结果的滤波窗口',windows,index=1,
                               format_func=lambda n:f'{n}×{n}',key='image_final_first')
        remaining = [n for n in windows if n != first]
        second = right.selectbox('第二张结果的滤波窗口',remaining,
                                 index=remaining.index(9) if 9 in remaining else 0,
                                 format_func=lambda n:f'{n}×{n}',key='image_final_second')
        strength = st.slider('给原图添加多少噪声',0.,.5,.12,.01,key='image_final_noise')
        st.caption('两张结果处理同一份噪声，只有滤波窗口不同。这里使用第 0 阶段的当前工作图，转为灰度后比较。')
        seed_final = 42
        params = dict(image=digest,noise=strength,seed=seed_final,sizes=[first,second])
        def final_run(fn):
            result = filter_pair(fn,image,True,strength,seed_final,[first,second],True)
            result['metrics']['second_filtered_mse'] = float(np.mean((result['second']-result['gray'])**2))
            return result
        result = run_panel('image_lab',mode,params,final_run)
        if result is not None:
            labels = [f'{first}×{first} 滤波结果',f'{second}×{second} 滤波结果']
            compare_pictures([result['gray'],result['noisy']],['原图（加噪前）','同一张加噪图'],'final_reference')
            compare_pictures([result['smooth'],result['second']],labels,'final_results')
            with st.expander('放大同一处细节'):
                row = coordinate('放大区域中心行',image.shape[0],'final_row')
                col = coordinate('放大区域中心列',image.shape[1],'final_col')
                region = np.s_[max(0,row-5):row+6,max(0,col-5):col+6]
                st.caption(f'共同查看第 {max(0,row-5)}–{min(image.shape[0]-1,row+5)} 行、第 {max(0,col-5)}–{min(image.shape[1]-1,col+5)} 列；下标从 0 开始。')
                compare_pictures([result['gray'][region],result['noisy'][region]],['原图局部','加噪图局部'],'final_reference_crop')
                compare_pictures([result['smooth'][region],result['second'][region]],labels,'final_result_crop')
            with st.expander('用数值辅助比较（MSE）'):
                cols = st.columns(3)
                for column,label,value in zip(cols,['加噪图',*labels],result['metrics'].values()):
                    column.metric(label,f'{value:.5f}')
                st.caption('数值越小，表示越接近加噪前的输入图。这里只衡量新增模拟噪声的恢复，不能判断上传照片原本是否干净；也要看细节是否被抹掉。')
            st.subheader('你更愿意保留哪张？')
            choice_key = f'image_final_choice_{first}_{second}'
            chosen = st.radio('选择要保留的滤波结果',labels,horizontal=True,key=choice_key)
            note = st.text_area('指出图中的一个位置，说明为什么选它',
                                placeholder='例如：梨的边缘还比较清楚，同时盘子上的噪点少了。',key='image_note')
            array = result['smooth'] if chosen == labels[0] else result['second']
            chosen_size = first if chosen == labels[0] else second
            st.download_button(f'下载 {chosen_size}×{chosen_size} 滤波图片',png_bytes(array),
                               f'denoised-{chosen_size}x{chosen_size}.png',mime='image/png',key='image_final_png')
            conclusion = (f'我选择：{chosen}\n理由：{note or "未填写"}\n'
                          f'对比窗口：{first}×{first} 与 {second}×{second}\n'
                          f'模拟噪声强度：{strength}；种子：{seed_final}\n运行模式：{mode}\n')
            st.download_button('下载我的选择和理由',conclusion,'denoising-choice.txt',
                               mime='text/plain',key='image_final_reason')
