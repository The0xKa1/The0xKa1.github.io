# 分类边界擂台

如果一类点在圆心附近，另一类围在外面，一条直线就很难把它们分开。坤坤把同一批点交给逻辑回归、决策树和 RBF 核方法，画出各自的分类边界。这里用合成数据比较模型；葡萄酒项目再处理真实的成分表。

## 模型与边界

默认的同心圆适合比较直线和曲线。运行后，把三张图里的同一个点对照着看：模型把它划到了哪一侧？再切换月牙或交叉棋盘。数据与噪声保持不变时，分别试试复杂度 1、3、20，记录训练和验证准确率。增加噪声后，再比较两种准确率的差距。

## 函数接口

### `build_model`

kind 指定逻辑回归、决策树或 RBF 核方法，complexity 必须大于 0。决策树把它转成整数作为最大深度，其他模型把它用作 C。返回模型时先不要拟合。

### `accuracy`

比较两个等长、非空的一维标签数组，返回预测正确的比例。例如真实标签为 [0,1]、预测为 [0,0]，准确率就是 0.5。

<details><summary>提示一：思路</summary>

交叉分布的点不能只靠一条直线分开。RBF 核方法可以形成弯曲边界，决策树则沿坐标轴切分区域。可以对照图看看这些区别。

</details>

<details><summary>提示二：接口</summary>

用 make_pipeline(StandardScaler(), model) 把缩放和分类器放在一起。三种分类器分别是 LogisticRegression、DecisionTreeClassifier 和 SVC(probability=True)。

</details>

完整实现：`solutions/classification_arena.py`。练习模式只调用 `projects/classification_arena/exercises.py`。

## 接着试什么

build_model 和 accuracy 通过检查后，用练习模式完成至少两次对照。模型要根据验证结果选择，确定配置后再评价测试集。还可以加入 KNN，比较邻居数对边界的影响。
