# 异常批次侦探

坤坤在检查一批样品的温度和重量记录。这个实验用合成数据设定两项指标的关系，再混入异常批次。阈值放宽，会有更多正常记录被报出来；阈值收紧，又可能漏掉异常。

## 一次报警有多少可信

用默认设置运行后，先看哪些点被标成了报警，再勾选真实标签核对。固定种子，把正常校准集的分位数分别设为 80%、95%、99%，保存各次结果，比较误报和漏报。报警准确率回答“报出来的有多少真异常”，召回率回答“真正的异常找到了多少”。

## 函数接口

### `fit_detector`

输入是 N×2 的正常历史记录，两列分别对应温度和重量。用这些训练数据拟合 IsolationForest，再返回模型。

### `flag_anomalies`

这里的分数越大，表示越异常。分数大于或等于阈值时标为 True，最后返回布尔数组。

### `evaluate`

输入真实异常标签和报警结果，二者都是布尔数组。计算 precision 和 recall；某项指标的分母为零时，该项返回 0。

<details><summary>提示一：思路</summary>

IsolationForest 的 score_samples 越低越异常。页面计算分数时已经取了负号，因此传入练习函数的是“越大越异常”的分数。阈值由另一份正常校准数据确定。

</details>

<details><summary>提示二：接口</summary>

训练模型用 IsolationForest.fit，报警条件是 scores >= threshold。指标分别为 precision = TP/(TP+FP)、recall = TP/(TP+FN)，记得检查分母是否为零。

</details>

完整实现：`solutions/anomaly.py`。练习模式只调用 `projects/anomaly/exercises.py`。

## 建议

完成 fit_detector、flag_anomalies 和 evaluate，用练习模式比较至少两个阈值。检查时尤其留意没有报警的情况，计算指标不能除以零。想做进一步对照，可以加一条只看温度的报警规则，比较它与同时看温度、重量的模型。
