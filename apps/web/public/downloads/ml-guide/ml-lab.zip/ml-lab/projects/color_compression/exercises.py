import numpy as np
from sklearn.cluster import KMeans

def fit_palette(pixels, colors, seed=42):
    """从像素中学习一组代表色。
    
    为什么做：一张图可能有很多颜色。K-Means 把相近颜色分成 K 组，
    各组中心就是代表色，之后可用少量颜色近似整张图。
    输入：pixels 为浮点数组 (N, 3)，每行是 0～1 的 RGB 像素；
        colors 为代表色数量 K（正整数，K<=N）；seed 为随机种子。
    输出：浮点数组 (K, 3)，每行一个 RGB 代表色，不是每个像素的分组标签。
    要求：使用 KMeans，n_clusters=colors、n_init=3、random_state=seed；
        拟合后返回 cluster_centers_，不修改 pixels，也不自行转成 0～255。
        相同输入和种子应可复现；中心行的顺序没有颜色语义。
    例子：等量黑白像素用 K=1 得到 [.5, .5, .5]，用 K=2 可保留黑白两色。
    """
    # TODO 1: 按指定 K、重启次数和种子创建 KMeans。
    # TODO 2: 只用传入的 RGB 像素拟合，提取并返回聚类中心。
    raise NotImplementedError('fit_palette')

def reconstruct(image, palette):
    """把图片中的每个像素替换成最接近的代表色。
    
    为什么做：调色板只列出可用颜色，还需要为每个像素决定使用哪一种。
    这里用 RGB 空间中的平方欧氏距离衡量颜色差异。
    输入：image 为浮点数组 (H, W, 3)；palette 为浮点数组 (K, 3)，K>0；
        两者 RGB 分量都在 0～1。
    输出：形状仍为 (H, W, 3) 的重建图，每个像素都取自 palette 的某一行。
    要求：保持像素位置不变，不修改 image 或 palette；距离并列时选较小索引。
        不在此重新训练调色板，也不将代表色取平均。
    例子：只有黑白两色时，[.1, .1, .1] 替换成黑色，[.9, .9, .9] 替换成白色。
    """
    # TODO 1: 把图像整理为 (H*W, 3)，记录原来的高和宽。
    # TODO 2: 计算每个像素到 K 个代表色的平方距离，对每行取最小距离的索引。
    # TODO 3: 按索引取代表色，再恢复为 (H, W, 3) 后返回。
    raise NotImplementedError('reconstruct')

def mse(original, compressed):
    """用均方误差衡量压缩图损失了多少像素信息。
    
    为什么做：代表色越少，存储颜色越省，但与原图的差异通常越大。
    MSE 将各位置的差异平方后平均，让不同压缩设置可以比较。
    输入：original、compressed 为同形状 (H, W, 3) 的非空浮点图像，范围 0～1。
    输出：Python float，所有像素、所有通道的平方误差均值，数值非负。
    要求：计算 mean((original-compressed)²)，不再开平方，不只沿一个轴平均；
        不修改输入，不能将浮点像素转换成整数后计算。
    例子：两图完全相同时为 0；所有分量都相差 0.2 时为 0.04。
    """
    # TODO 1: 逐项相减并平方，再对全部元素求平均。
    # TODO 2: 将标量转换成 Python float 后返回。
    raise NotImplementedError('mse')
