import numpy as np
from sklearn.cluster import KMeans

def fit_palette(pixels, colors, seed=42):
    """输入 N×3 的 RGB 像素，取值在 0 到 1 之间，以及要保留的颜色数 K。只用这些像素拟合，返回 K×3 的调色板。"""
    raise NotImplementedError('fit_palette')

def reconstruct(image, palette):
    """对 H×W×3 图像中的每个像素，找到调色板里距离最近的颜色，用它替换原值。返回图像的形状应与输入相同。"""
    raise NotImplementedError('reconstruct')

def mse(original, compressed):
    """把所有像素、所有通道的误差平方后取平均。两张图完全相同时，结果应为 0。"""
    raise NotImplementedError('mse')
