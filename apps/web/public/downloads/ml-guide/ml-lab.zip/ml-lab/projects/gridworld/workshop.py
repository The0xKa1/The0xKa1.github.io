"""分阶段送样练习。每一步只调用该阶段需要的学习者函数。"""
import re
from pathlib import Path
import numpy as np
import pandas as pd
import streamlit as st
from common.checks import check_project
from common.runtime import fingerprint, load_functions
from common.ui import error
from .experiment import parse_map, transition, shortest_distance
from .board import playback


def stage_lesson(stage):
    content = Path(__file__).with_name('README.md').read_text(encoding='utf-8')
    sections = re.split(r'^## ([0-4])\. .*$', content, flags=re.M)
    text = dict(zip(sections[1::2], sections[2::2]))[str(stage)]
    if stage == 0:
        setup = sections[0].split('## 开始前：哪些代码归你写', 1)[1]
        with st.expander('准备文件与运行方式'):
            st.markdown(setup)
    blocks = re.split(r'<details><summary>(.*?)</summary>(.*?)</details>', text, flags=re.S)
    st.markdown(blocks[0])
    for i in range(1, len(blocks), 3):
        with st.expander(blocks[i]):
            st.markdown(blocks[i+1])
        st.markdown(blocks[i+2])


def new_trip(text):
    grid, start, goal = parse_map(text)
    return dict(grid=grid, start=start, goal=goal, state=start, path=[start], records=[],
                q=np.zeros((*grid.shape, 4)), done=False, last=None)


def take_step(trip, action, update=None, alpha=.5, gamma=.9):
    """先验证函数输出，再提交位置和 Q 表，失败时保留原状态。"""
    if trip['done']:
        return
    if not isinstance(action, (int, np.integer)) or not 0 <= action < 4:
        raise ValueError(f'动作应为 0 到 3 的整数，实际得到 {action!r}。')
    state = trip['state']
    nxt, reward, done = transition(trip['grid'], trip['goal'], state, action)
    old = float(trip['q'][state][action])
    next_values = trip['q'][nxt].copy()
    target = reward if done else reward + gamma * float(next_values.max())
    new = old
    if update is not None:
        result = update(old, reward, next_values.copy(), done, alpha, gamma)
        if np.ndim(result) != 0 or not np.isfinite(result):
            raise ValueError(f'update_value 应返回有限数值，实际得到 {result!r}。')
        new = float(result)
    trip['q'][state][action] = new
    trip['last'] = dict(state=state, action=action, reward=reward, next_state=nxt,
                        terminated=done, old=old, target=target, new=new,
                        expected=old+alpha*(target-old), alpha=alpha, gamma=gamma)
    trip['state'] = nxt
    trip['path'].append(nxt)
    trip['records'].append(dict(action=int(action), reward=reward))
    trip['done'] = done


def exercise_check(name, label):
    if st.button(label, key='stage_check_'+name):
        try:
            reports = check_project('gridworld', load_functions('gridworld', '练习'), only=name)
            for r in reports:
                (st.success if r['passed'] else st.warning)(r['message'])
        except Exception as exc:
            error(exc)


def trip_panel(text, mode, kind):
    signature = fingerprint('gridworld', mode, dict(text=text, kind=kind))
    key = 'trip_'+kind
    if key not in st.session_state or st.session_state[key]['signature'] != signature:
        st.session_state[key] = dict(signature=signature, trip=new_trip(text))
    trip = st.session_state[key]['trip']
    shortest = shortest_distance(trip['grid'], trip['start'], trip['goal'])
    if shortest is None:
        st.warning('这张地图没有通往终点的路。可以试走观察碰撞，也可以回到地图编辑器拆掉一块墙。')
    if st.button('重新出发', key='restart_'+kind):
        trip = new_trip(text)
        st.session_state[key]['trip'] = trip
    st.caption('修改地图、运行模式或练习代码后，这里的路线与 Q 表会重置。')
    action = None
    if kind == 'explore':
        epsilon = st.slider('这一步的探索率 ε', 0., 1., 1., .05, key='step_epsilon')
        st.caption('本阶段还没有学习，Q 表全为 0。即使 ε=0，也会在并列动作中随机选择；下面的小实验可以观察非零 Q 值的效果。')
        if st.button('让小车自己走一步', key='explore_step', disabled=trip['done']):
            try:
                fn = load_functions('gridworld', mode)
                rng = np.random.default_rng(42 + len(trip['records']))
                action = fn.choose_action(trip['q'][trip['state']].copy(), epsilon, rng)
            except Exception as exc:
                error(exc)
    else:
        for i, col in enumerate(st.columns(4)):
            if col.button(['↑ 上', '→ 右', '↓ 下', '← 左'][i], key=f'{kind}_move_{i}', disabled=trip['done']):
                action = i
    if action is not None:
        try:
            update = load_functions('gridworld', mode).update_value if kind == 'learn' else None
            take_step(trip, action, update)
            if trip['done']:
                st.rerun()
        except Exception as exc:
            error(exc)
    a,b,c = st.columns(3)
    a.metric('已走步数', len(trip['records']))
    b.metric('累计奖励', sum(r['reward'] for r in trip['records']))
    c.metric('最短步数参照', shortest if shortest is not None else '不可达')
    playback(trip['grid'], trip['start'], trip['goal'], trip['path'], trip['records'], initial_step=len(trip['records']))
    if trip['done']:
        st.success(f"样品送达。你走了 {len(trip['records'])} 步，比最短路线多 {len(trip['records'])-shortest} 步。重新出发可以再试一次。")
    if kind == 'learn':
        if trip['last']:
            r = trip['last']
            st.write(f"刚才从第 {r['state'][0]+1} 行、第 {r['state'][1]+1} 列向{['上','右','下','左'][r['action']]}走。奖励 {r['reward']:g}，{'到达终点' if r['terminated'] else '尚未到达终点'}。")
            st.dataframe(pd.DataFrame({'旧 Q 值':[r['old']], '本次目标':[r['target']], '函数返回的新 Q 值':[r['new']], '按公式核对':[r['expected']]}), hide_index=True)
            st.caption('这一步使用 α=0.5、γ=0.9。表里的“函数返回”来自当前模式；“按公式核对”只作比较，不会替换你的结果。')
            if not np.isclose(r['new'], r['expected']):
                st.warning('两个结果不同。检查学习率是否乘在整个差值上，以及终点是否仍加了未来价值。')
        st.dataframe(pd.DataFrame(trip['q'].reshape(-1,4), columns=['上','右','下','左'], index=[f'{r+1}行{c+1}列' for r in range(trip['grid'].shape[0]) for c in range(trip['grid'].shape[1])]), height=200)


def action_lab(mode):
    exercise_check('choose_action', '检查第 1 题：动作选择')
    scenario = st.selectbox('动作选择小实验', ['唯一最大值 [0,5,0,0]', '两个并列 [0,5,5,0]', '全为零 [0,0,0,0]'])
    values = np.array({'唯一最大值 [0,5,0,0]':[0,5,0,0], '两个并列 [0,5,5,0]':[0,5,5,0], '全为零 [0,0,0,0]':[0,0,0,0]}[scenario])
    rate = st.slider('重复选择的探索率', 0.,1.,0.,.05)
    if st.button('调用当前函数 200 次', key='action_samples'):
        try:
            fn = load_functions('gridworld', mode)
            rng = np.random.default_rng(42)
            samples = [fn.choose_action(values.copy(), rate, rng) for _ in range(200)]
            if any(not isinstance(a,(int,np.integer)) or not 0<=a<4 for a in samples):
                raise ValueError('每次应返回 0 到 3 的整数动作编号。')
            st.bar_chart(pd.DataFrame({'次数':np.bincount(samples,minlength=4)}, index=['上','右','下','左']))
            st.caption('样本数只有 200，随机选择的次数不必完全相等。')
        except Exception as exc:
            error(exc)


def update_lab(mode):
    case = st.radio('试算情形', ['普通一步', '到达终点', '步数耗尽（截断）'], horizontal=True)
    if st.button('用当前函数计算这一步', key='q_example'):
        try:
            terminal = case == '到达终点'
            reward = 10. if terminal else -1.
            out = load_functions('gridworld',mode).update_value(2., reward, np.array([1.,4.,0.,2.]), terminal,.5,.9)
            expected = 6. if terminal else 2.3
            if np.ndim(out)!=0 or not np.isfinite(out):
                raise ValueError(f'应返回有限数值，实际为 {out!r}')
            st.write(f'函数返回 {float(out):g}；这个例子的预期值为 {expected:g}。')
            if not np.isclose(out,expected): st.warning('检查终止分支与更新式。截断时还有未来价值，不能当作到达终点。')
        except Exception as exc:
            error(exc)
    exercise_check('update_value','检查第 2 题：Q 值更新')
