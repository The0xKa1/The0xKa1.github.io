"""分类实验的分题说明与独立运行。"""
from pathlib import Path
import re
import streamlit as st
from common.checks import check_project
from common.runtime import fingerprint, load_functions
from common.ui import error


def lesson(stage):
    content=Path(__file__).with_name('README.md').read_text()
    sections=re.split(r'^## ([0-4])\. .*$',content,flags=re.M)
    text=dict(zip(sections[1::2],sections[2::2]))[str(stage)]
    blocks=re.split(r'<details><summary>(.*?)</summary>(.*?)</details>',text,flags=re.S)
    st.markdown(blocks[0])
    for i in range(1,len(blocks),3):
        with st.expander(blocks[i]): st.markdown(blocks[i+1])
        st.markdown(blocks[i+2])


def check(name):
    if st.button(f'检查 {name}',key='arena_check_'+name):
        try:
            reports=check_project('classification_arena',load_functions('classification_arena','练习'),only=name)
            for report in reports:
                (st.success if report['passed'] else st.warning)(report['message'])
        except Exception as exc: error(exc)


def trial(stage,label,mode,params,compute):
    key='arena_trial_'+stage
    try: signature=fingerprint('classification_arena',mode,dict(stage=stage,**params))
    except Exception as exc:
        error(exc);return None
    if st.button(label,key='arena_run_'+stage):
        st.session_state.pop(key,None)
        try:
            result=compute(load_functions('classification_arena',mode))
            st.session_state[key]=(signature,result)
        except Exception as exc: error(exc)
    saved=st.session_state.get(key)
    if saved and saved[0]!=signature:
        st.info('本题代码、模式或参数已改变；旧结果待更新，请重新运行。')
        return None
    return saved[1] if saved else None
