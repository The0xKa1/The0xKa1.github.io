# 默认照片来源

`fruit-photo.jpg` 是真实摄影作品 **Fruit on a plate 2019 G1** 的 Wikimedia 缩略图（1280 × 1013），内容为盘中的梨、无花果、柿子、苦瓜、李子和橘子。

- 摄影：George Chernilevsky，2019-10-03。
- 来源与授权声明：[Wikimedia Commons 文件页](https://commons.wikimedia.org/wiki/File:Fruit_on_a_plate_2019_G1.jpg)。作者将作品发布至公共领域；若当地不能这样做，作者允许任何人无条件用于任何目的（法律要求的条件除外）。
- 下载地址：[1280px JPEG](https://upload.wikimedia.org/wikipedia/commons/thumb/9/98/Fruit_on_a_plate_2019_G1.jpg/1280px-Fruit_on_a_plate_2019_G1.jpg)。
- 下载日期：2026-09-27。
- 本地保存下载内容；运行时转为 RGB 并等比例缩至最长边 192 像素，便于逐像素操作和 NumPy 实验。无需联网。

照片与本文件一同随项目包分发。合成图片仍可用于其他实验与确定性测试，第一个实验的默认输入使用本照片。
