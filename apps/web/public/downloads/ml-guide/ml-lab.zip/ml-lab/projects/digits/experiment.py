"""MNIST training, validation-selected checkpoint, held-out test, and inference."""
from io import BytesIO
import time
import copy
import numpy as np
import pandas as pd
from sklearn.metrics import accuracy_score,log_loss,confusion_matrix
from .dataset import load_split,split_ids


def normalized(fn,images):
    output=np.asarray(fn.normalize(np.asarray(images).copy()))
    if output.shape!=(len(images),1,28,28) or output.dtype!=np.float32:raise ValueError('normalize 应返回 float32 (N,1,28,28)')
    if not np.isfinite(output).all() or np.any((output<0)|(output>1)):raise ValueError('normalize 返回值须为 0–1 的有限值')
    return output


def checked_evaluate(fn,model,x):
    import torch
    before={k:v.detach().clone() for k,v in model.state_dict().items()}
    try:
        pred,probs=fn.evaluate(model,x)
        if any(not torch.equal(v,model.state_dict()[k]) for k,v in before.items()):raise ValueError('evaluate 不能改变模型参数或状态')
        if not isinstance(pred,np.ndarray) or not isinstance(probs,np.ndarray) or pred.shape!=(len(x),) or probs.shape!=(len(x),10):raise ValueError('evaluate 应返回 numpy (N,) 与 (N,10)')
        if not np.isfinite(probs).all() or np.any((probs<0)|(probs>1)) or not np.allclose(probs.sum(1),1,atol=1e-5):raise ValueError('概率应有限、非负，每行和为 1')
        if not np.issubdtype(pred.dtype,np.integer) or not np.array_equal(pred,probs.argmax(1)):raise ValueError('预测必须是每行最大概率的整数类别')
    except Exception:
        model.load_state_dict(before);raise
    return pred,probs


def device_name(request):
    import torch
    if request=='auto':return 'cuda' if torch.cuda.is_available() else 'mps' if torch.backends.mps.is_available() else 'cpu'
    if request not in {'cpu','cuda','mps'}:raise ValueError('未知计算设备')
    if request=='cuda' and not torch.cuda.is_available():raise ValueError('CUDA 不可用')
    if request=='mps' and not torch.backends.mps.is_available():raise ValueError('MPS 不可用')
    return request


def predict(result,images):
    import torch
    probabilities=[]
    device=next(result['model'].parameters()).device
    for start in range(0,len(images),256):
        x=normalized(result['fn'],images[start:start+256])
        probabilities.append(checked_evaluate(result['fn'],result['model'],torch.from_numpy(x).to(device))[1])
    return np.concatenate(probabilities) if probabilities else np.empty((0,10))


def train(fn,hidden=128,epochs=5,learning_rate=.001,seed=42,batch_size=128,device='auto',limit=None,progress=None):
    import torch
    from torch.utils.data import DataLoader,TensorDataset
    if epochs<1 or hidden<1 or batch_size<1 or not np.isfinite(learning_rate) or learning_rate<=0:raise ValueError('训练参数必须为正')
    images,labels=load_split()
    train_ids,valid_ids=split_ids(labels,limit)
    torch.manual_seed(seed);np.random.seed(seed);torch.set_num_threads(4)
    target=device_name(device)
    model=fn.build_network(hidden).to(target)
    optimizer=torch.optim.Adam(model.parameters(),lr=learning_rate)
    Xt=normalized(fn,images[train_ids]);yt=labels[train_ids].astype(np.int64)
    loader=DataLoader(TensorDataset(torch.from_numpy(Xt),torch.from_numpy(yt)),batch_size=batch_size,shuffle=True,generator=torch.Generator().manual_seed(seed))
    config=dict(hidden=hidden,epochs=epochs,learning_rate=learning_rate,seed=seed,batch_size=batch_size,device=target,limit=limit)
    result=dict(model=model,fn=fn,config=config,train_ids=train_ids,valid_ids=valid_ids,images=images,labels=labels)
    rows=[];best=float('inf');best_state=None;began=time.perf_counter()
    for epoch in range(epochs):
        loss_sum=0.;count=0
        for batch,(x,y) in enumerate(loader):
            loss=fn.train_step(model,optimizer,x.to(target),y.to(target))
            if not np.isscalar(loss) or not np.isfinite(loss) or loss<0:raise ValueError('train_step 应返回有限、非负标量')
            loss_sum+=float(loss)*len(x);count+=len(x)
            if progress and (batch%20==0 or batch+1==len(loader)):
                progress((epoch+(batch+1)/len(loader))/epochs,f'第 {epoch+1}/{epochs} 轮 · 批次 {batch+1}/{len(loader)} · 已训练 {count:,}/{len(train_ids):,} 张',list(rows))
        probs=predict(result,images[valid_ids]);valid_loss=float(log_loss(labels[valid_ids],probs,labels=np.arange(10)))
        if not np.isfinite(valid_loss):raise ValueError('验证损失不是有限值')
        row=dict(epoch=epoch+1,train_loss=loss_sum/count,valid_loss=valid_loss,valid_accuracy=float(accuracy_score(labels[valid_ids],probs.argmax(1))),seconds=time.perf_counter()-began)
        rows.append(row)
        if valid_loss<best:
            best=valid_loss;best_state={k:v.detach().cpu().clone() for k,v in model.state_dict().items()};result['best_epoch']=epoch+1
        if progress:progress((epoch+1)/epochs,f'第 {epoch+1} 轮完成 · 验证准确率 {row["valid_accuracy"]:.2%}',list(rows))
    model.load_state_dict(best_state);model.eval()
    result['curves']=pd.DataFrame(rows)
    probabilities=predict(result,images[valid_ids]);pred=probabilities.argmax(1)
    result.update(probabilities=probabilities,samples=pd.DataFrame(dict(actual=labels[valid_ids],predicted=pred),index=valid_ids),
      metrics=dict(valid_accuracy=float(accuracy_score(labels[valid_ids],pred)),valid_loss=best,best_epoch=result['best_epoch'],train_samples=len(train_ids),valid_samples=len(valid_ids),seconds=time.perf_counter()-began))
    return result


def final_test(result):
    images,actual=load_split(test=True)
    pred=predict(result,images).argmax(1)
    return dict(accuracy=float(accuracy_score(actual,pred)),matrix=confusion_matrix(actual,pred,labels=range(10)),samples=pd.DataFrame(dict(sample=np.arange(len(actual)),actual=actual,predicted=pred)))


def checkpoint_bytes(result):
    import torch
    buffer=BytesIO()
    torch.save(dict(format='mnist-cnn-v1',state_dict={k:v.detach().cpu() for k,v in result['model'].state_dict().items()},config=result['config'],best_epoch=result['best_epoch'],metrics=result['metrics'],curves=result['curves'].to_dict('records')),buffer)
    return buffer.getvalue()


def restore_checkpoint(fn,content):
    import torch
    payload=torch.load(BytesIO(content),map_location='cpu',weights_only=True)
    if not isinstance(payload,dict) or payload.get('format')!='mnist-cnn-v1':raise ValueError('不是本项目的 MNIST CNN 权重文件')
    config=payload['config'];hidden=int(config['hidden'])
    if hidden not in [32,64,128,256]:raise ValueError('不支持的隐藏层宽度')
    model=fn.build_network(hidden);model.load_state_dict(payload['state_dict'],strict=True);model.eval()
    return dict(model=model,fn=fn,config=config,best_epoch=payload['best_epoch'],metrics=payload['metrics'],curves=pd.DataFrame(payload['curves']))


def preprocess(image,ink='white'):
    """Crop foreground, fit 20×20, center by intensity centroid in a 28×28 field."""
    from PIL import Image,ImageOps
    if isinstance(image,Image.Image):
        if image.mode=='RGBA':
            background=Image.new('RGBA',image.size,'white' if ink=='black' else 'black');background.alpha_composite(image);image=background
        image=ImageOps.exif_transpose(image).convert('L')
        a=np.asarray(image,dtype=np.float32)
    else:a=np.asarray(image,dtype=np.float32)
    if a.ndim!=2 or not np.isfinite(a).all() or a.min()<0 or a.max()>255:raise ValueError('需要 0–255 灰度图')
    if ink=='black':a=255-a
    mask=a>25
    if not mask.any():raise ValueError('没有可见笔迹，请写一个数字或调整背景选项')
    y,x=np.where(mask);crop=a[y.min():y.max()+1,x.min():x.max()+1]
    scale=20/max(crop.shape);size=(max(1,round(crop.shape[1]*scale)),max(1,round(crop.shape[0]*scale)))
    small=np.asarray(Image.fromarray(crop.astype(np.uint8)).resize(size,Image.Resampling.LANCZOS))
    field=np.zeros((28,28),dtype=np.uint8);top=(28-size[1])//2;left=(28-size[0])//2;field[top:top+size[1],left:left+size[0]]=small
    yy,xx=np.indices(field.shape);mass=field.sum()
    if mass==0:raise ValueError('缩放后没有可见笔迹')
    dy=int(round(13.5-(yy*field).sum()/mass));dx=int(round(13.5-(xx*field).sum()/mass))
    shifted=np.zeros_like(field)
    y0,y1=max(0,-dy),min(28,28-dy);x0,x1=max(0,-dx),min(28,28-dx)
    shifted[y0+dy:y1+dy,x0+dx:x1+dx]=field[y0:y1,x0:x1]
    return shifted


def recognize(result,image,ink='white'):
    ready=preprocess(image,ink)
    return ready,predict(result,ready[None])[0]


def perturb(image,noise,shift,seed=42):
    out=np.zeros_like(image)
    if 0<shift<image.shape[1]:out[:,shift:]=image[:,:-shift]
    elif -image.shape[1]<shift<0:out[:,:shift]=image[:,-shift:]
    elif shift==0:out[:]=image
    return np.clip(out+np.random.default_rng(seed).normal(0,noise,out.shape),0,255).astype(np.uint8)
