"""逐步积累的研究产物；后续计算显式接收前一步的数据与模型。"""
import hashlib
import json
import numpy as np
import pandas as pd
from sklearn.base import clone
from sklearn.dummy import DummyClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.metrics import silhouette_score
from common import runtime
from projects.clustering.experiment import iterate


def signature(mode, projects, parameters, parent=''):
    payload=json.dumps([mode,parameters,parent],sort_keys=True,default=str).encode()
    for project in projects:payload+=runtime.source_path(project,mode).read_bytes()
    return hashlib.sha256(payload).hexdigest()


def split(fn,dev,target,seed):
    Xt,Xv,yt,yv=fn.split_data(dev.copy(),target.copy(),seed)
    if len(Xv)!=36 or len(Xt)!=106 or set(Xt.index)&set(Xv.index) or set(Xt.index)|set(Xv.index)!=set(dev.index):
        raise ValueError('请将 142 个开发样本分为 106 个训练样本和 36 个验证样本，保留原索引且不重叠、不遗漏。')
    for X,y in [(Xt,yt),(Xv,yv)]:
        pd.testing.assert_frame_equal(X,dev.loc[X.index])
        pd.testing.assert_series_equal(y,target.loc[X.index])
    return dict(Xt=Xt,Xv=Xv,yt=yt,yv=yv)


def classify(fn,partition,features,C,depth,seed):
    Xt,Xv,yt,yv=[partition[k] for k in ['Xt','Xv','yt','yv']]
    models={'多数类基线':DummyClassifier(strategy='most_frequent'),
            '逻辑回归':fn.build_model(C),
            '决策树':DecisionTreeClassifier(max_depth=depth,random_state=seed)}
    scores=[];predictions={}
    for name,model in models.items():
        model.fit(Xt[features],yt)
        pred=model.predict(Xv[features]);report=fn.evaluate(yv,pred)
        predictions[name]=pd.Series(pred,index=Xv.index)
        scores.append({'模型':name,'训练准确率':model.score(Xt[features],yt),'验证准确率':report['accuracy']})
    return dict(models=models,predictions=predictions,scores=pd.DataFrame(scores),features=list(features))


def regress(fn,partition,features):
    # 使用上一阶段划出的同一批行，不另生成数据或重新划分。
    Xt,yt=fn.split_target(partition['Xt'].copy())
    Xv,yv=fn.split_target(partition['Xv'].copy())
    if 'alcohol' in Xt or 'alcohol' in Xv:raise ValueError('split_target 的输入仍含 alcohol，必须把答案移出输入。')
    for X,y,source in [(Xt,yt,partition['Xt']),(Xv,yv,partition['Xv'])]:
        pd.testing.assert_frame_equal(X,source.drop(columns='alcohol'))
        pd.testing.assert_series_equal(y,source['alcohol'])
    inputs=[f for f in features if f!='alcohol']
    if not inputs:raise ValueError('至少保留一项 alcohol 之外的成分。')
    rows=[];models={}
    for alpha in [.01,.1,1.,10.,100.]:
        model=fn.build_model(alpha).fit(Xt[inputs],yt)
        train=fn.errors(yt,model.predict(Xt[inputs]))
        valid=fn.errors(yv,model.predict(Xv[inputs]))
        rows.append(dict(alpha=alpha,train_mae=train['mae'],valid_mae=valid['mae']))
        models[alpha]=model
    candidates=pd.DataFrame(rows);best=fn.select_alpha(candidates.copy())
    if best not in models:raise ValueError('select_alpha 必须返回候选表中的 alpha。')
    prediction=models[best].predict(Xv[inputs]);report=fn.errors(yv,prediction)
    samples=pd.DataFrame({'实测酒精含量':yv,'预测酒精含量':prediction,'残差':report['residuals']},index=Xv.index)
    baseline=fn.errors(yv,np.repeat(yt.mean(),len(yv)))['mae']
    return dict(model=models[best],alpha=best,candidates=candidates,samples=samples,features=inputs,
                mae=report['mae'],baseline_mae=baseline)


def group(fn,dev,features,k,seed,project_first):
    scaled=StandardScaler().fit_transform(dev[features])
    pca=PCA(n_components=2).fit(scaled);coords=pca.transform(scaled)
    fit=coords if project_first else scaled
    frames=iterate(fn,fit,k,seed)
    for frame in frames:
        frame['display_centers']=frame['centers'] if project_first else pca.transform(frame['centers'])
    groups=frames[-1]['groups']
    return dict(coords=coords,groups=pd.Series(groups,index=dev.index,name='簇'),frames=frames,
                variance=float(pca.explained_variance_ratio_.sum()),
                inertia=frames[-1]['inertia'],
                silhouette=float(silhouette_score(fit,groups)) if 1<len(np.unique(groups))<len(dev) else None)


def final(class_fn,reg_fn,classification,regression,name,dev,test,ydev,ytest):
    cm=clone(classification['models'][name]).fit(dev[classification['features']],ydev)
    cp=cm.predict(test[classification['features']]);cr=class_fn.evaluate(ytest,cp)
    rm=clone(regression['model']).fit(dev[regression['features']],dev.alcohol)
    rp=rm.predict(test[regression['features']]);rr=reg_fn.errors(test.alcohol,rp)
    rows=pd.DataFrame({'真实类别':ytest,'预测类别':cp,'实测酒精含量':test.alcohol,'预测酒精含量':rp,'残差':rr['residuals']},index=test.index)
    return dict(accuracy=cr['accuracy'],mae=rr['mae'],samples=rows)
