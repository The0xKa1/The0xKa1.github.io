"""MNIST IDX reader; download only on explicit request, verify official checksums."""
from pathlib import Path
from functools import lru_cache
import gzip
import hashlib
import struct
import urllib.request
import numpy as np
from sklearn.model_selection import train_test_split

ROOT=Path(__file__).resolve().parents[2]/'outputs/mnist'
SOURCE='https://ossci-datasets.s3.amazonaws.com/mnist/'
RESOURCES={
 'train-images-idx3-ubyte.gz':'f68b3c2dcbeaaa9fbdd348bbdeb94873',
 'train-labels-idx1-ubyte.gz':'d53e105ee54ea40749a09fcbcd1e9432',
 't10k-images-idx3-ubyte.gz':'9fb629c4189551a2d022fa330f9573f3',
 't10k-labels-idx1-ubyte.gz':'ec29112dd5afa0611ce80d1b7f02629c',
}


def available(root=None):
    root=Path(root or ROOT)
    return all((root/name).is_file() for name in RESOURCES)


def download(root=None,progress=None):
    root=Path(root or ROOT);root.mkdir(parents=True,exist_ok=True)
    for i,(name,checksum) in enumerate(RESOURCES.items()):
        path=root/name
        if not path.exists() or hashlib.md5(path.read_bytes()).hexdigest()!=checksum:
            temp=path.with_suffix('.part')
            try:
                with urllib.request.urlopen(SOURCE+name,timeout=60) as source, temp.open('wb') as output:
                    while block:=source.read(1024*1024):output.write(block)
                if hashlib.md5(temp.read_bytes()).hexdigest()!=checksum:raise ValueError(f'{name} 校验失败，请重新下载')
                temp.replace(path)
            finally:temp.unlink(missing_ok=True)
        if progress:progress((i+1)/4,name)
    _read.cache_clear()


@lru_cache(maxsize=8)
def _read(path,mtime):
    path=Path(path)
    if hashlib.md5(path.read_bytes()).hexdigest()!=RESOURCES[path.name]:raise ValueError(f'{path.name} 校验失败，请在数据页重新下载')
    raw=gzip.decompress(path.read_bytes())
    magic,count=struct.unpack('>II',raw[:8])
    if magic==2051:
        h,w=struct.unpack('>II',raw[8:16])
        if (h,w)!=(28,28) or len(raw)!=16+count*784:raise ValueError('MNIST 图像文件格式错误')
        array=np.frombuffer(raw,dtype=np.uint8,offset=16).reshape(count,28,28)
    elif magic==2049:
        if len(raw)!=8+count:raise ValueError('MNIST 标签文件格式错误')
        array=np.frombuffer(raw,dtype=np.uint8,offset=8)
        if array.max()>9:raise ValueError('MNIST 标签超出范围')
    else:raise ValueError('未知 IDX 文件')
    return array


def load_split(test=False,root=None):
    root=Path(root or ROOT);prefix='t10k' if test else 'train'
    paths=[root/f'{prefix}-images-idx3-ubyte.gz',root/f'{prefix}-labels-idx1-ubyte.gz']
    if not all(p.exists() for p in paths):raise FileNotFoundError('请先在数据阶段下载 MNIST')
    images,labels=[_read(str(p.resolve()),p.stat().st_mtime_ns) for p in paths]
    expected=10000 if test else 60000
    if len(images)!=expected or len(labels)!=expected:raise ValueError('MNIST 样本数量不完整')
    return images,labels


def split_ids(labels,limit=None):
    train,valid=train_test_split(np.arange(len(labels)),test_size=.1,stratify=labels,random_state=42)
    if limit is not None and limit<len(train):
        train,_=train_test_split(train,train_size=limit,stratify=labels[train],random_state=42)
    return train,valid
