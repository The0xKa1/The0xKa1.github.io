import numpy as np
from numpy.lib.stride_tricks import sliding_window_view

def grayscale(image):
    """把彩色图片转换成灰度图片。
    
    为什么做：后续滤波与边缘检测只需要明暗。人眼对绿色更敏感，
    所以这里用加权亮度，而不是简单平均三个通道。
    输入：image 是浮点数组 (H, W, 3)，H/W 是高/宽；最后一轴按 R、G、B
        排列，每个分量在 0～1。不是 0～255 的整数像素。
    输出：浮点数组 (H, W)，每个位置只有一个灰度值，范围 0～1。
    要求：gray = 0.2126×R + 0.7152×G + 0.0722×B；不修改原图。
    例子：纯红 [1, 0, 0] → 0.2126，白色 [1, 1, 1] → 1.0。
    """
    # TODO 1: 分别取最后一轴的红、绿、蓝通道，注意不要把行或列当成通道。
    # TODO 2: 按给定权重相加，返回二维灰度数组。
    raise NotImplementedError('grayscale')

def adjust(image, brightness, contrast):
    """调整图片的亮度和对比度。
    
    为什么做：亮度让整张图一起变亮或变暗；对比度改变像素与中间灰度的距离。
    输入：image 为 0～1 的浮点数组，通常是灰度 H×W 或彩色 H×W×3；
    也支持用于检查的一维像素序列，逐元素计算规则相同；
        brightness 为加到像素上的亮度偏移，contrast 为非负对比度倍率。
    输出：与 image 形状相同的浮点数组，所有值限制在 0～1。
    要求：以 0.5 为中心，先算 (image - 0.5) * contrast + 0.5，
        再加 brightness，最后裁剪范围。不能原地修改 image。
    例子：像素 0.2、contrast=2、brightness=0 得到 -0.1，裁剪后为 0；
        brightness=0、contrast=1 时图片不变。
    """
    # TODO 1: 减去中心 0.5，按 contrast 拉伸，再加回中心并叠加亮度偏移。
    # TODO 2: 使用 np.clip 将最终结果限制在 [0, 1]，返回新数组。
    raise NotImplementedError('adjust')

def mean_filter(image, size=3):
    """用邻域平均值平滑灰度图。
    
    为什么做：把一个像素与周围像素一起平均，可以减弱局部噪声，
    但也会模糊细节。边缘像素缺少邻居，需要先约定边界如何补齐。
    输入：image 为二维浮点数组 (H, W)；size 为正奇数窗口边长，默认 3。
    输出：同形状 (H, W) 的浮点数组，每项是相应 size×size 邻域的均值。
    要求：边界用最近的边缘像素复制填充（np.pad 的 mode='edge'），
        四周各补 size//2 格；不能补零，也不能缩小输出图像。
        size<=0 或为偶数时抛 ValueError；不修改输入，size=1 时数值不变。
    例子：[[0, .3], [.6, .9]] 用窗口 3 后为 [[.3, .4], [.5, .6]]。
        窗口比图片大也能通过边缘填充计算。
    """
    # TODO 1: 检查窗口大小，再根据 size//2 为原图复制填充边界。
    # TODO 2: 用 sliding_window_view 取每个位置的窗口，或自行遍历各个邻域。
    # TODO 3: 只对窗口内两个轴求平均，保留原图的高、宽两个轴并返回。
    raise NotImplementedError('mean_filter')

def edge_strength(image):
    """用相邻像素的亮度差估计边缘强度。
    
    为什么做：区域内部亮度通常变化较小，边界两侧变化较大。
    把水平和垂直差分合起来，就能标出变化明显的位置。
    输入：image 为二维浮点灰度数组 (H, W)，像素在 0～1。
    输出：同形状的非负浮点数组；值越大表示局部变化越强。
    要求：dx=右侧像素-当前像素，dy=下方像素-当前像素；
        最右列的 dx 设为 0，最下行的 dy 设为 0。结果为 sqrt(dx²+dy²)。
        不改变输入，不缩小图像；强度可能超过 1，不要裁剪或归一化。
    例子：均匀灰度图得到全零；[[0, 1], [0, 1]] 得到 [[1, 0], [1, 0]]。
    """
    # TODO 1: 建立与原图同形状的水平和垂直差分数组，先全部置零。
    # TODO 2: 在存在右邻居、下邻居的位置分别填写差分，边界保留零。
    # TODO 3: 逐像素合成两个方向的强度并返回。
    raise NotImplementedError('edge_strength')
