import numpy as np
from numpy.lib.stride_tricks import sliding_window_view

def grayscale(image):
    """输入是一张 H×W×3 的 RGB 图，像素值在 0 到 1 之间。把三个通道按权重合成亮度，返回 H×W 的灰度图。纯红像素的结果应约为 0.2126。"""
    raise NotImplementedError('grayscale')

def adjust(image, brightness, contrast):
    """以 0.5 为中心调整对比度，再加上亮度偏移。超出 0 到 1 的部分要裁剪，返回图像的形状保持不变。"""
    raise NotImplementedError('adjust')

def mean_filter(image, size=3):
    """输入二维灰度图和一个奇数窗口大小。用窗口内的均值替换像素，边缘用复制填充，返回图像与输入一样大。"""
    raise NotImplementedError('mean_filter')

def edge_strength(image):
    """计算横向和纵向的相邻像素差，再合成梯度幅度。最右列的横向差、最下行的纵向差设为零，输出形状为 H×W。"""
    raise NotImplementedError('edge_strength')
