from sklearn.datasets import load_wine
from sklearn.model_selection import train_test_split
import numpy as np


def wine_split():
    data = load_wine(as_frame=True)
    return train_test_split(data.data, data.target, test_size=0.2, stratify=data.target, random_state=42)
