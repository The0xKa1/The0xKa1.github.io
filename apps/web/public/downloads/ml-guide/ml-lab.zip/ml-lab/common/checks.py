"""小输入行为检查，不比较源码，也不要求唯一实现。"""
import numpy as np
import pandas as pd
from sklearn.datasets import load_wine
from common.runtime import source_path


def check_project(project, fn, only=None):
    reports = []
    def check(name, example, expected, action):
        if only is not None and name != only:
            return
        try:
            detail = action()
            reports.append(dict(function=name, passed=True, message=f'通过。{detail or ""}'))
        except NotImplementedError as exc:
            reports.append(dict(function=name, passed=False, message=f'待完成：{exc}'))
        except Exception as exc:
            reports.append(dict(function=name, passed=False, message=f'输入：{example}；预期：{expected}；实际：{type(exc).__name__}: {exc}'))

    def equal(actual, expected):
        np.testing.assert_allclose(actual, expected, rtol=1e-5, atol=1e-6, err_msg=f'实际 {actual}，预期 {expected}')

    if project == 'wine_classification':
        def split():
            data = load_wine(as_frame=True)
            a, b, ya, yb = fn.split_data(data.data, data.target, 42)
            assert set(a.index).isdisjoint(b.index), '训练和验证行重叠'
            assert len(a)+len(b) == len(data.data), '有样本遗漏'
            assert len(b) == 45, f'验证样本数为 {len(b)}'
            assert set(yb) == {0, 1, 2}, '验证集缺类别'
            for label in range(3):
                assert abs((yb == label).mean() - (data.target == label).mean()) < .03, '类别比例偏差过大'
        def pipeline():
            model = fn.build_model(1.)
            from sklearn.pipeline import Pipeline
            from sklearn.preprocessing import StandardScaler
            assert isinstance(model, Pipeline), '需要管道'
            assert any(isinstance(step, StandardScaler) for _, step in model.steps), '缺少 StandardScaler'
            X = pd.DataFrame({'a': [0., 1., 3., 4.], 'b': [1., 0., 4., 3.]})
            model.fit(X, [0, 0, 1, 1])
            scaler = next(step for _, step in model.steps if isinstance(step, StandardScaler))
            before = scaler.mean_.copy(); model.predict(X * 100)
            equal(scaler.mean_, before)
        def report():
            r = fn.evaluate(np.array([0, 1, 2]), np.array([0, 2, 2]))
            equal(r['accuracy'], 2/3); equal(r['wrong'], [1])
            equal(r['matrix'], [[1,0,0], [0,0,1], [0,0,1]])
        def depths():
            data = load_wine(as_frame=True)
            X, y = data.data, data.target
            from sklearn.model_selection import train_test_split
            a, b, ya, yb = train_test_split(X, y, test_size=.25, stratify=y, random_state=42)
            result = fn.compare_depths(a, ya, b, yb, [1, 3], 42)
            assert len(result) == 2 and set(result.depth) == {1, 3}, str(result)
            assert result[['train_accuracy', 'valid_accuracy']].ge(0).all().all()
            assert result[['train_accuracy', 'valid_accuracy']].le(1).all().all()
        check('split_data', 'Wine 178 行', '133/45 行且分层、无重叠', split)
        check('build_model', '四行训练数据与放大100倍预测数据', '缩放只 fit 训练集', pipeline)
        check('evaluate', '[0,1,2] 对 [0,2,2]', '准确率 2/3、错位 [1]、3×3矩阵', report)
        check('compare_depths（进阶）', 'depths=[1,3]', '两行合法准确率', depths)
    elif project == 'wine_regression':
        def target():
            data = load_wine(as_frame=True).data
            X, y = fn.split_target(data)
            assert 'alcohol' not in X.columns and X.shape == (178,12), str(X.shape)
            equal(y, data.alcohol)
        def errors():
            r = fn.errors([1,3], [2,2]); equal(r['mae'],1); equal(r['residuals'],[-1,1])
        def model():
            from sklearn.pipeline import Pipeline
            from sklearn.preprocessing import StandardScaler
            from sklearn.linear_model import Ridge
            m = fn.build_model(10.)
            assert isinstance(m, Pipeline)
            assert isinstance(m[-1], Ridge) and m[-1].alpha == 10.
            assert any(isinstance(s, StandardScaler) for _,s in m.steps)
        check('split_target', 'Wine 成分表', '12 输入列且移除 alcohol', target)
        check('errors', '[1,3] 与 [2,2]', 'MAE=1，残差[-1,1]', errors)
        check('build_model', 'alpha=10', '标准化与 Ridge 管道', model)
        check('select_alpha', 'alpha=[.1,1,10], MAE=[2,1,3]', '选择1', lambda: equal(fn.select_alpha(pd.DataFrame({'alpha':[.1,1,10], 'valid_mae':[2,1,3]})),1))
    elif project == 'clustering':
        X = np.array([[0.,0.], [2.,0.], [9.,0.]])
        centers = np.array([[0.,0.], [10.,0.], [20.,0.]])
        check('distances', '[[0,0]] 到 [[3,4]]', '平方距离25', lambda: equal(fn.distances(np.array([[0.,0.]]),np.array([[3.,4.]])), [[25]]))
        check('assign_groups', '[[1,4],[3,0],[2,2]]', '编号[0,1,0]', lambda: equal(fn.assign_groups(np.array([[1,4],[3,0],[2,2]])), [0,1,0]))
        def update():
            old = centers.copy()
            equal(fn.update_centers(X, np.array([0,0,1]), centers), [[1,0],[9,0],[20,0]])
            equal(centers, old)
        check('update_centers', '第三簇为空', '中心为[1,0],[9,0],[20,0]，原数组不变', update)
        def stop():
            assert fn.converged(centers, centers.copy())
            assert not fn.converged(centers, centers+1)
        check('converged', '相同中心与移动1的中心', '分别True/False', stop)
        check('best_restart（进阶）', '[4,1,3]', '返回位置1', lambda: equal(fn.best_restart([4,1,3]),1))
    elif project == 'digits':
        def normalize():
            values=(np.arange(2*784).reshape(2,28,28)%256).astype(float)
            before=values.copy();r=fn.normalize(values)
            assert r.shape==(2,1,28,28) and r.dtype==np.float32
            equal(r[:,0],values/255);equal(values,before)
            assert fn.normalize(np.zeros((0,28,28))).shape==(0,1,28,28)
            for bad in [np.zeros((2,8,8)),np.full((1,28,28),256.),np.full((1,28,28),-1.),np.full((1,28,28),np.nan)]:
                try:fn.normalize(bad)
                except ValueError:continue
                raise AssertionError('非法形状或范围须抛 ValueError')
        def network():
            import torch
            model=fn.build_network(32)
            assert model(torch.zeros(3,1,28,28)).shape==(3,10)
            layers=list(model.modules())
            assert sum(isinstance(m,torch.nn.Conv2d) for m in layers)==2, '需要两层卷积'
            assert sum(isinstance(m,torch.nn.MaxPool2d) for m in layers)==2, '需要两次池化'
            assert not any(isinstance(m,torch.nn.Softmax) for m in layers), '输出应为 logits'
        def step():
            import torch,copy
            torch.manual_seed(42)
            model=torch.nn.Sequential(torch.nn.Flatten(),torch.nn.Linear(784,10));expected=copy.deepcopy(model)
            optimizer=torch.optim.SGD(model.parameters(),lr=.01);other=torch.optim.SGD(expected.parameters(),lr=.01)
            x,y=torch.ones(2,1,28,28),torch.tensor([0,1])
            for p in model.parameters():p.grad=torch.ones_like(p)*7
            for _ in range(2):
                other.zero_grad();loss=torch.nn.functional.cross_entropy(expected(x),y);loss.backward();other.step()
                actual=fn.train_step(model,optimizer,x,y)
                assert isinstance(actual,float);equal(actual,float(loss.detach()))
                for p,q in zip(model.parameters(),expected.parameters()):equal(p.detach().numpy(),q.detach().numpy())
        def evaluate():
            import torch
            class Probe(torch.nn.Module):
                def __init__(self):
                    super().__init__();self.linear=torch.nn.Linear(784,10)
                def forward(self,x):
                    assert not self.training and not torch.is_grad_enabled(), '需要 eval 和 no_grad'
                    return self.linear(x.flatten(1))
            model=Probe();x=torch.ones(2,1,28,28);old={k:v.clone() for k,v in model.state_dict().items()}
            with torch.no_grad():expected=torch.softmax(model.linear(x.flatten(1)),dim=1).numpy()
            pred,probs=fn.evaluate(model,x)
            assert isinstance(pred,np.ndarray) and isinstance(probs,np.ndarray)
            equal(probs,expected);equal(pred,expected.argmax(1))
            assert pred.shape==(2,) and np.issubdtype(pred.dtype,np.integer)
            assert all(torch.equal(v,model.state_dict()[k]) for k,v in old.items())
        check('normalize','MNIST 两张灰度图、空批次和非法输入','float32 N×1×28×28，除255，不改输入',normalize)
        check('build_network','3×1×28×28 输入','两层卷积与池化，输出3×10 logits；需要PyTorch',network)
        check('train_step','有旧梯度的连续两次更新','清空梯度、正确交叉熵及参数更新；需要PyTorch',step)
        check('evaluate','模式和梯度探针','eval/no_grad，正确概率与预测，不改参数；需要PyTorch',evaluate)
    elif project == 'gridworld':
        def choice():
            rng = np.random.default_rng(42)
            equal(fn.choose_action(np.array([0,5,0,0]),0,rng), 1)
            choices = {fn.choose_action(np.zeros(4),0,rng) for _ in range(100)}
            assert choices == {0,1,2,3}, f'平局只出现{choices}'
            choices = {fn.choose_action(np.array([0,5,0,0]),1,rng) for _ in range(100)}
            assert choices == {0,1,2,3}, f'探索只出现{choices}'
        def update():
            equal(fn.update_value(0,10,np.array([100]*4),True),2)
            equal(fn.update_value(0,-1,np.array([2]*4),False),.18)
            values = np.array([1.,4.,0.,2.])
            equal(fn.update_value(2.,-1.,values,False,.5,.9),2.3)
            equal(values,[1,4,0,2])
            equal(fn.update_value(2.,10.,values,True,.5,.9),6.)
            equal(fn.update_value(2.,-1.,values,False,0.,.9),2.)
            equal(fn.update_value(2.,-1.,values,False,1.,0.),-1.)
        def rate():
            equal(fn.exploration_rate(0,100),1)
            equal(fn.exploration_rate(40,100),.5)
            equal(fn.exploration_rate(76,100),.05)
            equal(fn.exploration_rate(99,100),.05)
            rates = [fn.exploration_rate(i,100) for i in range(100)]
            assert all(.05 <= r <= 1 for r in rates) and all(a>=b for a,b in zip(rates,rates[1:]))
        check('choose_action', '唯一最大值、四值平局、epsilon=1', '贪心/随机平局/探索正确', choice)
        check('update_value', '默认参数的终止/普通一步；旧值2、奖励-1、下一最大值4、α=.5、γ=.9', '默认分别2和.18；自定义参数2.3；不改输入数组', update)
        check('exploration_rate', '100回合的0、40、76、99回合', '分别1、.5、.05、.05，单调不增', rate)
        def sarsa():
            equal(fn.sarsa_update(2., -1., 1., False, .5, .9), .95)
            equal(fn.sarsa_update(2., 10., 999., True, .5, .9), 6.)
            equal(fn.sarsa_update(2., -1., 4., False, 0., .9), 2.)
        def expected_sarsa():
            values = np.array([1., 4., 0., 2.]); before = values.copy()
            equal(fn.expected_sarsa_update(2., -1., values, False, .2, .5, .9), 2.0975)
            equal(fn.expected_sarsa_update(2., -1., values, False, 0., .5, .9), 2.3)
            equal(fn.expected_sarsa_update(2., -1., values, False, 1., .5, .9), 1.2875)
            equal(fn.expected_sarsa_update(2., 10., values, True, .2, .5, .9), 6.)
            equal(fn.expected_sarsa_update(0., 0., np.array([0.,4.,4.,0.]), False, .5, 1., 1.), 3.)
            equal(values, before)
        check('sarsa_update', '旧值2、奖励-1、下一动作值1、α=.5、γ=.9；终点', '.95；终点6；α=0保留旧值', sarsa)
        check('expected_sarsa_update', '下一值[1,4,0,2]，ε=.2/0/1；终点与平局', '2.0975/2.3/1.2875；终点6；不改输入', expected_sarsa)


    elif project == 'image_lab':
        def image_equal(name, image, expected, *args):
            before = image.copy()
            actual = getattr(fn, name)(image, *args)
            assert np.shape(actual) == np.shape(expected), f'形状为 {np.shape(actual)}，预期 {np.shape(expected)}'
            equal(actual, expected)
            equal(image, before)

        def gray():
            image_equal('grayscale', np.array([[[1.,0,0],[0,1.,0],[0,0,1.],[1.,1,1],[0.,0,0]]]),
                        [[.2126,.7152,.0722,1.,0.]])
            image_equal('grayscale', np.ones((2,1,3)), np.ones((2,1)))

        def adjust_image():
            image_equal('adjust', np.array([0.,.5,1.]), [0.,.7,1.], .2, 2.)
            image_equal('adjust', np.array([[[.1,.4,.9]]]), [[[.1,.4,.9]]], 0., 1.)
            image_equal('adjust', np.array([[.1,.9]]), [[.3,.3]], -.2, 0.)

        def mean():
            values = np.array([[0.,.3],[.6,.9]])
            image_equal('mean_filter', values, [[.3,.4],[.5,.6]], 3)
            image_equal('mean_filter', values, values.copy(), 1)
            image_equal('mean_filter', np.array([[.4]]), [[.4]], 9)
            for size in [0,-1,2]:
                try:
                    fn.mean_filter(values.copy(), size)
                except ValueError:
                    continue
                raise AssertionError(f'窗口 {size} 应抛 ValueError')

        def edges():
            image_equal('edge_strength', np.array([[0.,1.],[0.,1.]]), [[1.,0.],[1.,0.]])
            image_equal('edge_strength', np.array([[0.,1.],[1.,1.]]), [[np.sqrt(2),0.],[0.,0.]])
            image_equal('edge_strength', np.array([[0.],[1.]]), [[1.],[0.]])
            image_equal('edge_strength', np.array([[1.,0.]]), [[1.,0.]])
            image_equal('edge_strength', np.ones((2,3)), np.zeros((2,3)))
            image_equal('edge_strength', np.array([[.4]]), [[0.]])

        check('grayscale', '红绿蓝白黑色块与单列 RGB 图', '灰度 .2126/.7152/.0722/1/0，保留二维形状且不改输入', gray)
        check('adjust', '[0,.5,1]，亮度 .2 对比度 2；恒等与零对比度', '[0,.7,1]；同形状且不改输入', adjust_image)
        check('mean_filter', '[[0,.3],[.6,.9]]，窗口3；窗口1/9与非法窗口', '复制填充得到[[.3,.4],[.5,.6]]；不改输入，拒绝非法窗口', mean)
        check('edge_strength', '横向/纵向/双向阶跃、单行单列、恒定图', '双向变化为√2，边界保留另一个方向的差，形状不变', edges)
    elif project == 'classification_arena':
        def models():
            from sklearn.pipeline import Pipeline
            from sklearn.preprocessing import StandardScaler
            X=np.array([[-1,-1],[-1,1],[1,-1],[1,1]]);y=[1,0,0,1]
            for kind in ['逻辑回归','决策树','RBF 核方法']:
                model=fn.build_model(kind,3.,42)
                assert isinstance(model,Pipeline) and any(isinstance(step,StandardScaler) for _,step in model.steps),'缺少标准化管道'
                model.fit(X,y);assert model.predict_proba(X).shape==(4,2)
            assert fn.build_model('RBF 核方法',10.,42).fit(X,y).score(X,y)==1,'核模型应能拟合四个交叉点'
        check('build_model','四个 XOR 点、三种模型','管道、概率输出、非线性拟合',models)
        def arena_accuracy():
            for actual,predicted,expected in [([0,1,1],[0,0,1],2/3),([0,1],[0,1],1.),([0,1],[1,0],0.),([1],[1],1.)]:
                equal(fn.accuracy(actual,predicted),expected)
                a=np.array(actual);p=np.array(predicted)
                equal(fn.accuracy(a,p),expected)
                np.testing.assert_array_equal(a,actual)
                np.testing.assert_array_equal(p,predicted)
        check('accuracy','部分正确、全对、全错、单样本；列表和数组','正确比例，不修改输入',arena_accuracy)
    elif project == 'color_compression':
        def palette():
            pixels = np.array([[0.,0,0],[0,0,0],[1,1,1],[1,1,1]])
            before = pixels.copy()
            r = np.asarray(fn.fit_palette(pixels,2,42))
            assert r.shape == (2,3), '调色板形状应为 K×3'
            equal(np.sort(r[:,0]),[0,1]); equal(r[:,0],r[:,1]); equal(r[:,1],r[:,2])
            equal(pixels,before)
            equal(fn.fit_palette(pixels,1,42),[[.5,.5,.5]])
            equal(fn.fit_palette(pixels,2,42),r)
        def reconstruct():
            image = np.array([[[.1]*3,[.9]*3,[.5]*3]])
            colors = np.array([[0.]*3,[1.]*3])
            before, original_palette = image.copy(), colors.copy()
            actual = np.asarray(fn.reconstruct(image,colors))
            assert actual.shape == image.shape, '重建图形状必须与原图相同'
            equal(actual,[[[0.]*3,[1.]*3,[0.]*3]])
            equal(image,before); equal(colors,original_palette)
            equal(fn.reconstruct(image,colors[1:]),np.ones_like(image))
            # 彩色样本区分 RGB 距离与只看一个通道的错误实现。
            equal(fn.reconstruct(np.array([[[.1,.8,.1],[.1,.1,.8]]]),
                                 np.array([[0.,1,0],[0,0,1.]])), [[[0.,1,0],[0,0,1.]]])
        def compression_mse():
            a = np.zeros((1,2,3)); b = np.array([[[0.,0,0],[1.,1,1]]])
            before = b.copy()
            value = fn.mse(a,b)
            assert np.isscalar(value), 'MSE 应为标量'
            equal(value,.5); equal(fn.mse(a,a),0); equal(fn.mse(a,np.ones_like(a)),1)
            equal(a,np.zeros_like(a)); equal(b,before)
        check('fit_palette','黑白重复像素 K=2 与 K=1','黑白中心（顺序不限）、单中心 .5；不修改输入',palette)
        check('reconstruct','黑白、等距、单颜色与彩色像素','最近颜色；等距选第一个；保持形状和输入',reconstruct)
        check('mse','相同图、全黑全白、半黑半白','标量 0、1、.5；不修改输入',compression_mse)
    return reports
