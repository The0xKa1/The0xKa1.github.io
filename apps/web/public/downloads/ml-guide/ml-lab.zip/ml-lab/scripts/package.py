#!/usr/bin/env python3
"""Build one deterministic, self-contained course archive; never package workspace secrets."""
from pathlib import Path
from zipfile import ZipFile, ZipInfo, ZIP_DEFLATED
import hashlib
import argparse

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT
OUTPUT = ROOT / 'dist/ml-lab.zip'
EXCLUDED = {'.venv', '__pycache__', '.pytest_cache', 'outputs', '.git', 'dist', '.codegraph', '_handoffs'}
SUFFIXES = {'.py', '.md', '.csv', '.txt', '.toml', '.css', '.woff2', '.jpg'}


def package(output=OUTPUT):
    output = Path(output).expanduser().resolve()
    for path in ['app.py', 'requirements.txt', 'README.md', '.streamlit/config.toml']:
        if not (SOURCE / path).is_file():
            raise FileNotFoundError(path)
    files = sorted(p for p in SOURCE.rglob('*') if p.is_file()
                   and not EXCLUDED.intersection(p.relative_to(SOURCE).parts)
                   and (p.suffix in SUFFIXES or p.name == '.gitignore'))
    output.parent.mkdir(parents=True, exist_ok=True)
    with ZipFile(output, 'w', compression=ZIP_DEFLATED) as archive:
        for path in files:
            name = 'ml-lab/' + path.relative_to(SOURCE).as_posix()
            info = ZipInfo(name, date_time=(2026, 9, 26, 0, 0, 0))
            info.compress_type = ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            archive.writestr(info, path.read_bytes())
    with ZipFile(output) as archive:
        assert archive.testzip() is None
        assert len(archive.namelist()) == len(files)
    print(f'{output}\n{len(files)} files · {output.stat().st_size} bytes\nsha256: {hashlib.sha256(output.read_bytes()).hexdigest()}')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description="打包独立食品实验室项目")
    parser.add_argument("--output", type=Path, default=OUTPUT)
    package(parser.parse_args().output)
