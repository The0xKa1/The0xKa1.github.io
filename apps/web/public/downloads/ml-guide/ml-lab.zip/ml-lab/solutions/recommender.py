import numpy as np

def similarity(profile, features):
    """profile 保存 D 维口味偏好，features 保存 N 种食品的属性，形状为 N×D。返回每种食品与偏好的余弦相似度；遇到零向量时，将对应分数设为 0。"""
    denom=np.linalg.norm(features,axis=1)*np.linalg.norm(profile)
    return np.divide(features@profile,denom,out=np.zeros(len(features)),where=denom>0)

def rank_items(scores, excluded, count):
    """按分数从高到低返回食品的原始行号，先排除已选的项。最多返回 count 项；同分时保留菜单中的原有顺序。"""
    return np.array([i for i in np.argsort(-np.asarray(scores),kind='stable') if i not in excluded][:count])
