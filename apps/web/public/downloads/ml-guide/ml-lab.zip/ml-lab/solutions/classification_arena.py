import numpy as np
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier

def build_model(kind, complexity, seed=42):
    """kind 指定逻辑回归、决策树或 RBF 核方法，complexity 必须大于 0。决策树把它转成整数作为最大深度，其他模型把它用作 C。返回模型时先不要拟合。"""
    if kind=='逻辑回归': model=LogisticRegression(C=complexity,max_iter=2000)
    elif kind=='决策树': model=DecisionTreeClassifier(max_depth=int(complexity),random_state=seed)
    elif kind=='RBF 核方法': model=SVC(C=complexity,gamma='scale',probability=True,random_state=seed)
    else: raise ValueError(kind)
    return make_pipeline(StandardScaler(),model)

def accuracy(actual, predicted):
    """比较两个等长、非空的一维标签数组，返回预测正确的比例。例如真实标签为 [0,1]、预测为 [0,0]，准确率就是 0.5。"""
    return float(np.mean(np.asarray(actual)==np.asarray(predicted)))
