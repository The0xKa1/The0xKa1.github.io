import numpy as np
from numpy.lib.stride_tricks import sliding_window_view

def grayscale(image):
    """输入是一张 H×W×3 的 RGB 图，像素值在 0 到 1 之间。把三个通道按权重合成亮度，返回 H×W 的灰度图。纯红像素的结果应约为 0.2126。"""
    return np.asarray(image) @ np.array([.2126,.7152,.0722])

def adjust(image, brightness, contrast):
    """以 0.5 为中心调整对比度，再加上亮度偏移。超出 0 到 1 的部分要裁剪，返回图像的形状保持不变。"""
    return np.clip((np.asarray(image)-.5)*contrast+.5+brightness,0,1)

def mean_filter(image, size=3):
    """输入二维灰度图和一个奇数窗口大小。用窗口内的均值替换像素，边缘用复制填充，返回图像与输入一样大。"""
    if size<1 or size%2==0: raise ValueError('窗口必须是正奇数')
    return sliding_window_view(np.pad(image,size//2,mode='edge'),(size,size)).mean(axis=(-2,-1))

def edge_strength(image):
    """计算横向和纵向的相邻像素差，再合成梯度幅度。最右列的横向差、最下行的纵向差设为零，输出形状为 H×W。"""
    dx=np.diff(image,axis=1,append=image[:,-1:])
    dy=np.diff(image,axis=0,append=image[-1:,:])
    return np.sqrt(dx*dx+dy*dy)
