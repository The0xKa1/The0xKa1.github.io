"""MNIST 卷积网络参考实现；仅调用网络函数时导入 PyTorch。"""
import numpy as np


def normalize(images):
    """(N,28,28) 的 0–255 像素转 float32 (N,1,28,28)，范围 0–1。"""
    images=np.asarray(images)
    if images.ndim!=3 or images.shape[1:]!=(28,28):raise ValueError('输入需要 (N,28,28)')
    if not np.isfinite(images).all() or np.any((images<0)|(images>255)):raise ValueError('像素须为 0–255 的有限值')
    return images[:,None,:,:].astype(np.float32)/255


def build_network(hidden=128):
    """两层卷积和池化，接隐藏层及十分类 logits。"""
    from torch import nn
    return nn.Sequential(nn.Conv2d(1,16,3,padding=1),nn.ReLU(),nn.MaxPool2d(2),
        nn.Conv2d(16,32,3,padding=1),nn.ReLU(),nn.MaxPool2d(2),nn.Flatten(),
        nn.Linear(32*7*7,hidden),nn.ReLU(),nn.Linear(hidden,10))


def train_step(model,optimizer,x,y):
    """清空梯度，计算交叉熵并更新，返回更新前的 float 损失。"""
    import torch.nn.functional as F
    model.train();optimizer.zero_grad()
    loss=F.cross_entropy(model(x),y)
    loss.backward();optimizer.step()
    return float(loss.detach())


def evaluate(model,x):
    """eval/no_grad，返回 numpy 预测 (N,) 与概率 (N,10)。"""
    import torch
    model.eval()
    with torch.no_grad():probabilities=torch.softmax(model(x),dim=1).cpu().numpy()
    return probabilities.argmax(1),probabilities
