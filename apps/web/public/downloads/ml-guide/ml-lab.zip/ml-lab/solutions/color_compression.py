import numpy as np
from sklearn.cluster import KMeans

def fit_palette(pixels, colors, seed=42):
    """输入 N×3 的 RGB 像素，取值在 0 到 1 之间，以及要保留的颜色数 K。只用这些像素拟合，返回 K×3 的调色板。"""
    return KMeans(n_clusters=colors,n_init=3,random_state=seed).fit(pixels).cluster_centers_

def reconstruct(image, palette):
    """对 H×W×3 图像中的每个像素，找到调色板里距离最近的颜色，用它替换原值。返回图像的形状应与输入相同。"""
    flat=image.reshape(-1,3)
    ids=((flat[:,None,:]-palette[None,:,:])**2).sum(2).argmin(1)
    return palette[ids].reshape(image.shape)

def mse(original, compressed):
    """把所有像素、所有通道的误差平方后取平均。两张图完全相同时，结果应为 0。"""
    return float(np.mean((original-compressed)**2))
