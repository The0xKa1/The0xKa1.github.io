"""Q-learning 参考实现。"""
import numpy as np


def choose_action(values, epsilon, rng):
    """values 为四个 Q 值；rng 为 numpy Generator；返回 0..3。

    epsilon 概率随机探索；否则从所有最大值动作中随机选一个。
    """
    if rng.random() < epsilon:
        return int(rng.integers(4))
    return int(rng.choice(np.flatnonzero(values == np.max(values))))


def update_value(current, reward, next_values, terminated, alpha=.2, gamma=.95):
    """返回更新后的一个 Q 值，不修改数组。

    终止目标=reward；其他情况目标=reward+gamma*max(next_values)。
    达到回合步数上限是截断，仍用 terminated=False。
    """
    target = reward if terminated else reward + gamma * np.max(next_values)
    return float(current + alpha * (target-current))


def exploration_rate(episode, episodes):
    """episode 从 0 开始；返回 max(.05, 1 - episode / (.8 * episodes))；约 76% 时达到下限。"""
    return max(.05, 1. - episode / (.8 * episodes))


def sarsa_update(current, reward, next_value, terminated, alpha=.2, gamma=.95):
    """SARSA 使用下一步实际选中的动作价值；终点不 bootstrap。"""
    target = reward if terminated else reward + gamma * next_value
    return float(current + alpha * (target-current))


def expected_sarsa_update(current, reward, next_values, terminated, epsilon, alpha=.2, gamma=.95):
    """ε-greedy 的期望：ε×均值 + (1−ε)×最大值，含最大值平局。"""
    expected = epsilon * np.mean(next_values) + (1-epsilon) * np.max(next_values)
    target = reward if terminated else reward + gamma * expected
    return float(current + alpha * (target-current))
