# 坤坤的食品实验室：机器学习实践

这个项目包含六个机器学习项目，用 Streamlit 在本机运行。每个实验都有可运行的参考实现，也留出了需要你补全的 Python 函数。

第一次使用可以从[环境配置教程](GETTING_STARTED.md)开始。里面按 Windows、macOS、Linux 写了按键和命令，也解释了终端、路径、虚拟环境以及常见报错。

| 实验 | 练习目录 |
| --- | --- |
| 01 图像处理工作台 | `projects/image_lab` |
| 02 分类边界擂台 | `projects/classification_arena` |
| 03 葡萄酒研究室（分类、回归、聚类与降维） | 入口 `projects/wine_lab`；练习沿用 `wine_classification`、`wine_regression`、`clustering` |
| 04 图片颜色压缩 | `projects/color_compression` |
| 05 手写数字识别（MNIST CNN） | `projects/digits` |
| 06 小车送样 | `projects/gridworld` |

已配置 Python 的读者：在本文件所在目录安装 `requirements.txt`，通过 `python -m streamlit run app.py` 启动。

每个项目的说明都在对应文件夹里，练习写在 `exercises.py`，参考实现放在 `solutions`。选择演示会运行参考实现，切到练习则只运行你保存的函数。修改后再点检查或运行，就会加载新代码；旧结果会标记为待更新。实验记录保存在当前会话中，关掉网页前可以下载成 CSV / JSON。

前四个项目与小车送样无需 PyTorch。手写数字识别需安装 requirements-torch.txt，首次主动下载 MNIST，随后离线使用；训练数据、权重保存在 outputs，不包含在发布包里。上传图片只在本机处理。

维护检查：`python -m pytest -q`。测试使用临时练习骨架，不会改动读者写好的答案。


## 仓库与打包

实验源码在独立的 `ml-lab` Git 仓库维护。笔记网站保存讲解页、预览图和发布用 ZIP。两者通常放在同一个工作目录下，互不包含。

在实验仓库中运行 `python scripts/package.py`，生成 `dist/ml-lab.zip`。打包不会包含 Git 元数据、虚拟环境、缓存或实验输出。

更新网站下载包时，在笔记仓库运行 `python scripts/package-ml-lab.py`；它默认读取旁边的 `ml-lab` 文件夹。放在其他位置时，使用 `python scripts/package-ml-lab.py --source /path/to/ml-lab`。更新指导内容时，也同步修改网站对应页面。

本仓库的初始历史从笔记仓库的 `projects/ml-lab` 目录拆出，原始提交为 `efe73d8abe16b6e088873a2b29e8ee0bf8bc2def`。后续实验代码在这里提交。
