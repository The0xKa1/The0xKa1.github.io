from types import SimpleNamespace
import numpy as np
import pytest
from streamlit.testing.v1 import AppTest
from common.runtime import ROOT, load_functions, source_path
from common.checks import check_project
from projects.gridworld.workshop import new_trip, take_step


def test_collision_terminal_and_failed_update_are_atomic():
    trip = new_trip('S.G\n...')
    fn = load_functions('gridworld','演示')
    take_step(trip,0,fn.update_value)
    assert trip['state']==(0,0) and trip['q'][0,0,0]==-.5
    take_step(trip,0,fn.update_value)
    assert trip['q'][0,0,0]==-.75
    old = trip['q'].copy()
    with pytest.raises(ValueError): take_step(trip,1,lambda *args: np.nan)
    np.testing.assert_array_equal(old,trip['q'])
    assert len(trip['records'])==2 and trip['state']==(0,0)
    take_step(trip,1,fn.update_value)
    take_step(trip,1,fn.update_value)
    assert trip['done'] and trip['last']['new']==5
    assert trip['last']['target']==10 and trip['last']['terminated']
    take_step(trip,3,fn.update_value)
    assert len(trip['records'])==4


def test_one_question_does_not_call_unfinished_functions():
    fn = SimpleNamespace(choose_action=load_functions('gridworld','演示').choose_action)
    reports = check_project('gridworld',fn,only='choose_action')
    assert len(reports)==1 and reports[0]['passed']
    wrong = SimpleNamespace(update_value=lambda *args: 99.)
    reports = check_project('gridworld',wrong,only='update_value')
    assert not reports[0]['passed'] and '实际' in reports[0]['message']


def app():
    at = AppTest.from_file(str(ROOT/'app.py'),default_timeout=60).run()
    at.sidebar.radio[0].set_value('10 格子导航').run()
    return at


def test_manual_delivery_restart_and_map_invalidation():
    at = app()
    at.sidebar.radio[1].set_value('练习').run()
    at.button(key='manual_move_0').click().run()
    assert not at.exception and not at.error
    trip=at.session_state['trip_manual']['trip']
    assert len(trip['records'])==1 and trip['state']==(0,0)
    for action in [1,1,1,2,2,2]:
        at.button(key=f'manual_move_{action}').click().run()
    assert at.session_state['trip_manual']['trip']['done']
    assert at.button(key='manual_move_1').disabled
    at.button(key='restart_manual').click().run()
    assert not at.session_state['trip_manual']['trip']['records']
    at.button(key='manual_move_1').click().run()
    at.button(key='cell_1_0').click().run()
    assert not at.session_state['trip_manual']['trip']['records']


def test_partial_exercise_hot_reload_and_mode_reset(isolated_exercises):
    at=app()
    at.sidebar.radio[1].set_value('练习').run()
    at.button(key='explore_step').click().run()
    assert any('待完成' in w.value for w in at.warning)
    assert not at.session_state['trip_explore']['trip']['records']
    path=isolated_exercises['gridworld']
    import ast
    tree=ast.parse(source_path('gridworld','演示').read_text())
    tree.body=[n for n in tree.body if not isinstance(n,ast.FunctionDef) or n.name=='choose_action']
    path.write_text(ast.unparse(tree))
    at.button(key='stage_check_choose_action').click().run()
    assert at.success and not at.error
    at.button(key='explore_step').click().run()
    assert len(at.session_state['trip_explore']['trip']['records'])==1
    assert not at.exception and not at.error
    at.button(key='learn_move_1').click().run()
    assert at.error  # Missing update must not be silently filled with the answer.
    assert not at.session_state['trip_learn']['trip']['records']
    path.write_text(source_path('gridworld','演示').read_text())
    at.run()
    assert not at.session_state['trip_explore']['trip']['records']
    at.button(key='learn_move_0').click().run()
    assert at.session_state['trip_learn']['trip']['last']['new']==-.5
    at.sidebar.radio[1].set_value('演示').run()
    assert not at.session_state['trip_learn']['trip']['records']
    assert not at.exception


def test_wrong_update_is_visible_and_example_uses_selected_mode(isolated_exercises):
    path=isolated_exercises['gridworld']
    path.write_text('def update_value(*args): return 123.\n')
    at=app()
    at.sidebar.radio[1].set_value('练习').run()
    at.button(key='q_example').click().run()
    assert any('函数返回 123' in m.value for m in at.markdown)
    at.button(key='learn_move_0').click().run()
    assert at.session_state['trip_learn']['trip']['last']['new']==123
    assert any('两个结果不同' in w.value for w in at.warning)
    assert not at.exception
