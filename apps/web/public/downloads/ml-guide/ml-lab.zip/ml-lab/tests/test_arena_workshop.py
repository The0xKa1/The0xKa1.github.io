from types import SimpleNamespace
import numpy as np
from streamlit.testing.v1 import AppTest
from common.runtime import ROOT, load_functions, source_path
from projects.classification_arena.experiment import run, preview, KINDS


def app():
    at=AppTest.from_file(str(ROOT/'app.py'),default_timeout=90).run()
    return at.sidebar.radio[0].set_value('02 分类边界擂台').run()


def test_models_have_independent_parameters_and_same_split():
    fn=load_functions('classification_arena','演示')
    base=run(fn,complexity=3.)
    changed=run(fn,complexity=dict(zip(KINDS,[3.,10.,3.])))
    assert changed['models']['决策树'].steps[-1][1].max_depth==10
    for name in ['逻辑回归','RBF 核方法']:
        np.testing.assert_array_equal(base['boundaries'][name],changed['boundaries'][name])
    np.testing.assert_array_equal(base['train'],changed['train'])
    np.testing.assert_array_equal(base['test'],changed['test'])


def test_preview_only_calls_build_model():
    fn=load_functions('classification_arena','演示')
    result=preview(SimpleNamespace(build_model=fn.build_model),'同心圆',.15,42,'决策树',3.)
    assert len(result['predictions']['决策树'])==120
    assert result['boundaries']['决策树'].shape==(110,110)


def test_partial_accuracy_runs_without_model(isolated_exercises):
    isolated_exercises['classification_arena'].write_text('def accuracy(actual,predicted):\n    return sum(a==b for a,b in zip(actual,predicted))/len(actual)\n')
    at=app().sidebar.radio[1].set_value('练习').run()
    at.button(key='arena_run_accuracy').click().run()
    assert not at.exception and not at.error
    assert at.session_state['arena_trial_accuracy'][1]==.75
    at.selectbox(key='arena_hand_1').set_value(1).run()
    assert any('待更新' in x.value for x in at.info)
    at.button(key='arena_run_accuracy').click().run()
    assert at.session_state['arena_trial_accuracy'][1]==1


def test_partial_model_runs_without_accuracy(isolated_exercises):
    source=source_path('classification_arena','演示').read_text().split('def accuracy(')[0]
    isolated_exercises['classification_arena'].write_text(source)
    at=app().sidebar.radio[1].set_value('练习').run()
    at.button(key='arena_run_model').click().run()
    assert not at.exception and not at.error
    assert 'arena_trial_model' in at.session_state
    at.selectbox(key='arena_shape').set_value('月牙').run()
    assert any('待更新' in x.value for x in at.info)


def test_inspection_does_not_train_and_parameter_changes_invalidate():
    at=app()
    at.button(key='run_classification_arena').click().run()
    at.selectbox(key='arena_choice').set_value('决策树').run()
    at.text_area(key='arena_note').set_value('验证集上的弯曲边界').run()
    assert len(at.session_state['history'])==1
    at.button(key='arena_test').click().run()
    assert any(x.label=='最终测试准确率' for x in at.metric)
    at.select_slider(key='arena_parameter_决策树').set_value(10.).run()
    assert any('待更新' in x.value for x in at.info)
    assert not any(x.label=='最终测试准确率' for x in at.metric)
    assert not at.exception
