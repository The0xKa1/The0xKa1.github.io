from io import BytesIO
from types import SimpleNamespace
import numpy as np
import pytest
from PIL import Image
from streamlit.testing.v1 import AppTest
from common.runtime import ROOT, load_functions, source_path
from projects.color_compression.experiment import fit, rebuild, measure, run, png_bytes


def page():
    at = AppTest.from_file(str(ROOT/'app.py'),default_timeout=90).run()
    at.sidebar.radio[0].set_value('04 图片颜色压缩').run()
    return at


def test_stages_partial_implementation_and_invalidation(isolated_exercises):
    path = isolated_exercises['color_compression']
    path.write_text('from solutions.color_compression import reconstruct\n')
    at = page()
    at.sidebar.radio[1].set_value('练习').run()
    assert len(at.tabs) == 5
    at.button(key='color_run_reconstruct').click().run()
    assert not at.exception and not at.error
    assert 'color_trial_reconstruct' in at.session_state
    at.button(key='color_run_fit').click().run()
    assert at.error  # 缺失函数不会静默使用答案。
    at.radio(key='color_palette_kind').set_value('第 0 阶段手选颜色').run()
    assert any('待更新' in x.value for x in at.info)
    path.write_text('from solutions.color_compression import mse\n')
    at.button(key='color_run_hand_mse').click().run()
    assert at.session_state['color_trial_hand_mse'][1] == .5
    path.write_text('def mse(a,b): return .123\n')
    at.button(key='color_run_hand_mse').click().run()
    assert at.session_state['color_trial_hand_mse'][1] == .123
    assert any('取平均' in x.value for x in at.warning)


def test_complete_stage_flow_and_code_change(isolated_exercises):
    path = isolated_exercises['color_compression']
    path.write_text(source_path('color_compression','演示').read_text())
    at = page()
    at.sidebar.radio[1].set_value('练习').run()
    for key in ['reconstruct','fit','automatic','photo_mse']:
        at.button(key='color_run_'+key).click().run()
        assert not at.exception and not at.error
    at.button(key='run_color_compression').click().run()
    assert len(at.session_state['history']) == 1
    at.select_slider(key='color_export_k').set_value(4).run()
    assert len(at.session_state['history']) == 1
    at.number_input(key='color_seed').set_value(7).run()
    assert any('待更新' in x.value for x in at.info)
    assert not at.exception
    path.write_text(path.read_text()+'\n# changed\n')
    at.run()
    assert any('待更新' in x.value for x in at.info)


def test_validation_and_encoding():
    image = np.zeros((2,3,3))
    for bad in [np.zeros((2,2)),np.full((2,3),np.nan),np.full((2,3),2.)]:
        with pytest.raises(ValueError): fit(SimpleNamespace(fit_palette=lambda *args:bad),image,2)
    palette = np.array([[0.,0,0],[1.,1,1]])
    with pytest.raises(ValueError,match='调色板以外'):
        rebuild(SimpleNamespace(reconstruct=lambda a,b:np.full_like(a,.3)),image,palette)
    for bad in [np.nan, -1, 2, np.array([.5])]:
        with pytest.raises(ValueError): measure(SimpleNamespace(mse=lambda *args:bad),image,image)
    image = np.random.default_rng(42).random((8,9,3))
    before = image.copy()
    r = run(load_functions('color_compression','演示'),image)
    np.testing.assert_array_equal(image,before)
    assert list(r['variants']) == [2,4,8,16,32]
    for row in r['curve'].itertuples():
        data = png_bytes(r['variants'][row.colors])
        assert len(data) == row.png_bytes
        with Image.open(BytesIO(data)) as picture:
            assert picture.mode == 'RGB' and picture.size == (9,8)
            np.testing.assert_array_equal(np.asarray(picture),np.rint(r['variants'][row.colors]*255).astype(np.uint8))
