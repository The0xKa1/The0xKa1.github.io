from types import SimpleNamespace
import numpy as np
import pytest
pytest.importorskip("torch")
from streamlit.testing.v1 import AppTest
from common.runtime import ROOT,load_functions
from common.checks import check_project
from projects.digits import dataset,experiment
from projects.digits.experiment import train,final_test,checked_evaluate,checkpoint_bytes,restore_checkpoint,predict,preprocess
from projects.digits.workshop import network_preview,step_preview,evaluation_preview
from projects.digits.drawing import validate_pixels

@pytest.fixture
def tiny_data(monkeypatch):
    rng=np.random.default_rng(4)
    images=rng.integers(0,256,(200,28,28),dtype=np.uint8)
    labels=np.tile(np.arange(10,dtype=np.uint8),20)
    calls=[]
    def load(test=False):
        calls.append(test)
        return (images[:30],labels[:30]) if test else (images,labels)
    monkeypatch.setattr(dataset,'available',lambda:True)
    monkeypatch.setattr(dataset,'load_split',load)
    monkeypatch.setattr(experiment,'load_split',load)
    return images,labels,calls

def page():
    at=AppTest.from_file(str(ROOT/'app.py'),default_timeout=90).run()
    at.sidebar.radio[0].set_value('05 手写数字识别').run()
    assert not at.exception
    return at

def test_training_isolation_and_checkpoint(tiny_data):
    images,labels,calls=tiny_data
    fn=load_functions('digits','演示')
    r=train(fn,hidden=32,epochs=2,device='cpu',batch_size=64)
    assert calls==[False]
    assert len(r['train_ids'])==180 and len(r['valid_ids'])==20
    assert not set(r['train_ids']) & set(r['valid_ids'])
    assert r['best_epoch']==int(r['curves'].loc[r['curves'].valid_loss.idxmin(),'epoch'])
    restored=restore_checkpoint(fn,checkpoint_bytes(r))
    np.testing.assert_allclose(predict(restored,images[:3]),predict(r,images[:3]),atol=1e-7)
    final=final_test(r)
    assert calls==[False,True] and len(final['samples'])==30
    assert final['matrix'].sum()==30

def test_independent_exercises(tiny_data):
    ref=load_functions('digits','演示');images,labels,_=tiny_data
    assert network_preview(SimpleNamespace(build_network=ref.build_network),32,42)['parameters']>50000
    result=step_preview(SimpleNamespace(train_step=ref.train_step),images[:32],labels[:32],5,.1,42)
    assert result['delta']>0 and len(result['curve'])==6
    np.testing.assert_array_equal(evaluation_preview(SimpleNamespace(evaluate=ref.evaluate))['predictions'],[9,9])
    assert not check_project('digits',SimpleNamespace(train_step=lambda *args:1.),only='train_step')[0]['passed']

def test_page_train_test_stale_and_partial(tiny_data,isolated_exercises):
    at=page()
    assert len(at.tabs)==7 and 'result_digits' not in at.session_state
    at.slider(key='digits_epochs').set_value(1)
    at.selectbox(key='digits_hidden').set_value(32)
    at.selectbox(key='digits_device').set_value('cpu').run()
    at.button(key='run_digits').click().run()
    assert not at.exception and not at.error
    assert len(at.session_state['history'])==1
    at.button(key='digits_test').click().run()
    assert not at.exception and not at.error
    assert len(at.session_state['history'])==2
    at.selectbox(key='digits_hidden').set_value(64).run()
    assert any('待更新' in x.value for x in at.info)
    assert not any(x.label=='最终测试准确率' for x in at.metric)
    isolated_exercises['digits'].write_text('from solutions.digits import normalize\n')
    at.sidebar.radio[1].set_value('练习').run()
    at.button(key='digits_run_normalize').click().run()
    assert not at.exception and not at.error
    at.button(key='run_digits').click().run()
    assert 'result_digits' not in at.session_state
    assert at.warning or at.error

def test_page_without_data(monkeypatch):
    monkeypatch.setattr(dataset,'available',lambda:False)
    monkeypatch.setattr(dataset,'load_split',lambda *a,**k:pytest.fail('automatic data read'))
    at=page()
    assert at.button(key='run_digits').disabled
    assert any('不会自动下载或训练' in x.value for x in at.info)

def test_bad_evaluator_restores_weights():
    import torch
    model=torch.nn.Linear(784,10)
    old={k:v.clone() for k,v in model.state_dict().items()}
    def bad(model,x):
        with torch.no_grad():model.bias.fill_(10)
        return np.zeros(2,dtype=int),np.ones((2,10))/10
    with pytest.raises(ValueError,match='改变模型'):checked_evaluate(SimpleNamespace(evaluate=bad),model,torch.zeros(2,784))
    for name,value in model.state_dict().items():assert torch.equal(value,old[name])

def test_drawing_preprocessing():
    image=np.zeros((280,280),np.uint8);image[30:200,70:90]=255
    result=preprocess(image)
    np.testing.assert_array_equal(result,preprocess(255-image,'black'))
    assert result.shape==(28,28) and result.dtype==np.uint8
    yy,xx=np.indices(result.shape)
    assert abs((xx*result).sum()/result.sum()-13.5)<=.5
    assert abs((yy*result).sum()/result.sum()-13.5)<=.5
    with pytest.raises(ValueError,match='笔迹'):preprocess(np.zeros((280,280)))
    assert validate_pixels([8]*78400).shape==(280,280)
    for bad in [[0]*64,[256]*78400,[np.nan]*78400]:
        with pytest.raises(ValueError):validate_pixels(bad)


def test_dataset_rejects_corruption_and_cleans_partial_download(tmp_path,monkeypatch):
    from io import BytesIO
    name=next(iter(dataset.RESOURCES))
    (tmp_path/name).write_bytes(b'corrupt')
    with pytest.raises(ValueError,match='校验失败'):
        dataset._read(str(tmp_path/name),0)
    monkeypatch.setattr(dataset.urllib.request,'urlopen',lambda *a,**k:BytesIO(b'incomplete'))
    with pytest.raises(ValueError,match='校验失败'):dataset.download(tmp_path)
    assert not list(tmp_path.glob('*.part'))
    assert (tmp_path/name).read_bytes()==b'corrupt'
