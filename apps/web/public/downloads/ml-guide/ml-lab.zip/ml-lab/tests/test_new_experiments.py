import numpy as np
import pytest
from common.runtime import load_functions
from common.pictures import sample_image


def test_image_filter_improves_noise_but_blurs_clean_edges():
    from projects.image_lab.experiment import run
    fn=load_functions('image_lab','演示');image=sample_image()
    r=run(fn,image)
    assert r['metrics']['filtered_mse']<r['metrics']['noisy_mse']
    clean=run(fn,image,noise=0,size=9)
    assert clean['metrics']['noisy_mse']==0 and clean['metrics']['filtered_mse']>0
    assert np.all((r['adjusted']>=0)&(r['adjusted']<=1))


@pytest.mark.parametrize('shape',['月牙','同心圆','交叉棋盘'])
def test_arena_split_and_visible_nonlinearity(shape):
    from projects.classification_arena.experiment import run
    r=run(load_functions('classification_arena','演示'),shape=shape,noise=.1,complexity=10)
    assert len(set(r['train'])|set(r['valid'])|set(r['test']))==600
    assert not set(r['train'])&set(r['valid']) and not set(r['valid'])&set(r['test']) and not set(r['train'])&set(r['test'])
    assert r['metrics']['RBF 核方法']>r['metrics']['逻辑回归']+.03


def test_compression_matches_palette_and_improves_with_colors():
    from projects.color_compression.experiment import run
    r=run(load_functions('color_compression','演示'),sample_image(48))
    unique=np.unique(r['compressed'].reshape(-1,3),axis=0)
    assert len(unique)<=8
    curve=r['curve'].set_index('colors').mse
    assert curve.loc[16]<curve.loc[2]
    assert 1<r['metrics']['theoretical_ratio']<8
