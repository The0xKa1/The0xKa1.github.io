from types import SimpleNamespace
import numpy as np
import pytest
from common.runtime import load_functions
from projects.gridworld.experiment import ALGORITHMS, run, generate_map, parse_map, shortest_distance, evaluate


@pytest.mark.parametrize('shape', [(16, 16), (32, 32), (64, 64), (2, 64), (64, 2)])
def test_large_generated_maps_are_reproducible_and_reachable(shape):
    text = generate_map(*shape, density=.6, seed=5)
    assert text == generate_map(*shape, density=.6, seed=5)
    grid, start, goal = parse_map(text)
    assert grid.shape == shape
    assert shortest_distance(grid, start, goal) == sum(shape)-2
    result = run(load_functions('gridworld', '演示'), text, episodes=2, max_steps=3)
    assert result['q'].shape == (*shape, 4)
    assert result['curve'].truncated.all()


@pytest.mark.parametrize('algorithm', ALGORITHMS)
def test_algorithm_converges_and_evaluation_preserves_q(algorithm):
    fn = load_functions('gridworld', '演示')
    result = run(fn, 'S...\n.##.\n....\n.#.G', episodes=1500, seed=42, algorithm=algorithm)
    before = result['q'].copy()
    evaluation = evaluate(result, episodes=10)
    assert evaluation['metrics']['success_rate'] == 1
    assert evaluation['metrics']['success_path_ratio'] == 1
    np.testing.assert_array_equal(before, result['q'])
    assert evaluation['table'].equals(evaluate(result, episodes=10)['table'])


def test_sarsa_executes_preselected_action_and_bootstraps_on_truncation():
    actions = iter([1, 2, 3])
    seen = []
    def update(current, reward, next_value, terminated, alpha, gamma):
        seen.append(terminated)
        return 7.
    fn = SimpleNamespace(choose_action=lambda *args: next(actions), sarsa_update=update)
    result = run(fn, 'S.G\n...', episodes=1, max_steps=2, strategy='固定', algorithm='SARSA')
    assert [r['action'] for r in result['traces'][1][1]] == [1, 2]
    assert seen == [False, False]
    assert result['curve'].truncated.iloc[0]
    # Neither other update function nor exploration schedule is needed.
    assert result['q'][0, 0, 1] == 7 and result['q'][0, 1, 2] == 7


def test_terminal_sarsa_does_not_sample_another_action():
    actions = iter([1])
    seen = []
    def update(current, reward, next_value, terminated, alpha, gamma):
        seen.append((reward, next_value, terminated))
        return reward
    result = run(SimpleNamespace(choose_action=lambda *args: next(actions), sarsa_update=update),
                 'SG\n..', episodes=1, strategy='固定', algorithm='SARSA')
    assert seen == [(10., 0., True)]
    assert result['curve'].success.iloc[0]


@pytest.mark.parametrize('algorithm', ALGORITHMS)
def test_invalid_update_rejected_and_unfinished_algorithm_not_filled(algorithm):
    fn = load_functions('gridworld', '演示')
    setattr(fn, ALGORITHMS[algorithm], lambda *args: np.inf)
    with pytest.raises(ValueError, match='有限标量'):
        run(fn, 'SG\n..', episodes=1, algorithm=algorithm)
    partial = SimpleNamespace(choose_action=fn.choose_action)
    with pytest.raises(AttributeError):
        run(partial, 'SG\n..', episodes=1, strategy='固定', algorithm=algorithm)


def test_large_map_editor_window_and_algorithm_invalidation():
    from streamlit.testing.v1 import AppTest
    from common.runtime import ROOT
    at = AppTest.from_file(str(ROOT/'app.py'), default_timeout=60).run()
    at.sidebar.radio[0].set_value('06 小车送样').run()
    maps = next(s for s in at.selectbox if s.label == '地图')
    assert maps.value == '扩展 · 16×16'
    assert maps.options == ['扩展 · 16×16', '扩展 · 32×32', '扩展 · 64×64']
    maps.set_value('扩展 · 64×64').run()
    assert not at.exception
    assert len([b for b in at.button if b.key and b.key.startswith('cell_')]) == 144
    next(s for s in at.slider if s.label == '编辑窗口起始行').set_value(53).run()
    next(s for s in at.slider if s.label == '编辑窗口起始列').set_value(53).run()
    at.button(key='cell_62_62').click().run()
    assert not at.exception
    next(s for s in at.selectbox if s.label == '地图').set_value('扩展 · 16×16').run()
    at.button(key='run_gridworld').click().run()
    at.selectbox(key='grid_algorithm').set_value('SARSA').run()
    assert any('待更新' in i.value for i in at.info)
    at.button(key='run_gridworld').click().run()
    assert not at.error and not at.exception
    assert at.session_state['result_gridworld']['config']['algorithm'] == 'SARSA'
    next(s for s in at.select_slider if s.label == '训练回合').set_value(10).run()
    at.button(key='run_gridworld').click().run()
    at.button(key='grid_compare').click().run()
    assert not at.exception and not at.error
    signature, table, _, _ = at.session_state['grid_comparison']
    assert len(table) == 9 and set(table.algorithm) == set(ALGORITHMS)
    count = len(at.session_state['history'])
    at.run()
    assert len(at.session_state['history']) == count
