"""阶段依赖、真实错误结果、历史失效和照片参照语义。"""
import ast
from io import BytesIO
from types import SimpleNamespace
import numpy as np
import pytest
from PIL import Image
from streamlit.testing.v1 import AppTest
from common.checks import check_project
from common.pictures import sample_image
from common.runtime import ROOT, load_functions, source_path
from projects.image_lab.experiment import call_image, run
from projects.image_lab.workshop import filter_pair, png_bytes, array_bytes


def app():
    at = AppTest.from_file(str(ROOT/'app.py'),default_timeout=60).run()
    at.sidebar.radio[0].set_value('01 图像处理工作台').run()
    assert not at.exception
    return at


def partial(path, names):
    tree = ast.parse(source_path('image_lab','演示').read_text())
    tree.body = [n for n in tree.body if not isinstance(n,ast.FunctionDef) or n.name in names]
    path.write_text(ast.unparse(tree))


@pytest.mark.parametrize('name', ['grayscale','adjust','mean_filter','edge_strength'])
def test_single_question_check_only_requires_one_function(name):
    fn = load_functions('image_lab','演示')
    reports = check_project('image_lab',SimpleNamespace(**{name:getattr(fn,name)}),only=name)
    assert len(reports)==1 and reports[0]['passed'], reports


@pytest.mark.parametrize('name,wrong', [
    ('grayscale',lambda x: np.zeros(x.shape[:2])),
    ('adjust',lambda x,b,c: x),
    ('mean_filter',lambda x,size: x),
    ('edge_strength',lambda x: np.zeros_like(x)),
])
def test_single_question_rejects_plausible_wrong_answers(name,wrong):
    reports=check_project('image_lab',SimpleNamespace(**{name:wrong}),only=name)
    assert not reports[0]['passed'] and '实际' in reports[0]['message']


def test_filter_inputs_are_identical_and_real_noise_has_no_mse():
    fn=load_functions('image_lab','演示')
    original=fn.mean_filter
    seen=[]
    def record(image,size):
        seen.append(image.copy())
        return original(image,size)
    fn.mean_filter=record
    pair=filter_pair(fn,sample_image(12),False,.12,42,[3,9],True)
    np.testing.assert_array_equal(seen[0],seen[1])
    np.testing.assert_array_equal(pair['noisy'],seen[0])
    direct=run(fn,sample_image(12),noise=.5,simulated=False)
    assert direct['metrics']=={} and direct['errors'].empty
    np.testing.assert_array_equal(direct['noisy'],direct['gray'])
    assert direct['smooth_edge'].shape==direct['gray'].shape


def test_output_contract_retains_wrong_finite_values_and_isolates_input():
    source=np.zeros((2,3))
    def mutate(image,size):
        image[:]=99
        return image
    result=call_image(SimpleNamespace(mean_filter=mutate),'mean_filter',source,3)
    assert np.all(result==99) and np.all(source==0)
    for wrong in [np.zeros((3,2)),np.full((2,3),np.nan),np.full((2,3),1j)]:
        with pytest.raises(ValueError):
            call_image(SimpleNamespace(mean_filter=lambda *args:wrong),'mean_filter',source,3)
    encoded=png_bytes(result)
    assert np.all(np.array(Image.open(BytesIO(encoded)))==255)
    np.testing.assert_array_equal(np.load(BytesIO(array_bytes(result))),result)


def test_partial_filter_runs_without_gray_and_hot_reload_is_real(isolated_exercises):
    path=isolated_exercises['image_lab']
    at=app()
    at.sidebar.radio[1].set_value('练习').run()
    at.button(key='image_run_filter').click().run()
    assert any('待完成' in x.value for x in at.warning)
    partial(path,{'mean_filter'})
    at.button(key='image_check_mean_filter').click().run()
    assert at.success and not at.error
    at.button(key='image_run_filter').click().run()
    assert not at.exception and not at.error
    assert 'history' not in at.session_state
    old=at.session_state['image_stage_filter']['result']['smooth'].copy()
    at.slider(key='filter_row').set_value(0).run()
    np.testing.assert_array_equal(at.session_state['image_stage_filter']['result']['smooth'],old)
    path.write_text('import numpy as np\ndef mean_filter(image, size=3): return np.full_like(image,.123)\n')
    at.run()
    assert any('待更新' in x.value for x in at.info)
    at.button(key='image_run_filter').click().run()
    assert np.all(at.session_state['image_stage_filter']['result']['smooth']==.123)
    at.radio(key='filter_source').set_value('当前图片（需要 grayscale）').run()
    at.button(key='image_run_filter').click().run()
    assert at.error and 'image_stage_filter' not in at.session_state
    assert not at.exception


def test_each_stage_runs_and_own_checks_never_use_demo_answers(isolated_exercises):
    at=app()
    assert len(at.tabs)==6
    assert not any(e.label=='练习说明与提示' for e in at.expander)
    at.button(key='image_check_grayscale').click().run()
    assert any('待完成' in x.value for x in at.warning)
    for name in ['gray','adjust','hand','filter','edge']:
        at.button(key='image_run_'+name).click().run()
        assert not at.exception and not at.error
    at.sidebar.radio[1].set_value('练习').run()
    assert any('待更新' in x.value for x in at.info)
    partial(isolated_exercises['image_lab'],{'edge_strength','adjust'})
    at.button(key='image_run_edge').click().run()
    at.button(key='image_run_adjust').click().run()
    assert not at.exception and not at.error
    at.slider(key='image_contrast').set_value(0.).run()
    at.button(key='image_run_adjust').click().run()
    assert at.session_state['image_stage_adjust']['result']['restored'] is None


def test_final_comparison_is_self_contained_and_uses_window_names():
    at=app()
    at.button(key='run_image_lab').click().run()
    result=at.session_state['result_image_lab']
    before=result['smooth'].copy()
    assert at.radio(key='image_final_choice_3_9').options==['3×3 滤波结果','9×9 滤波结果']
    assert not any(b.key=='image_save_plan' for b in at.button)
    at.radio(key='image_final_choice_3_9').set_value('9×9 滤波结果').run()
    at.text_area(key='image_note').set_value('盘子上的噪点更少。').run()
    assert len(at.session_state['history'])==1
    np.testing.assert_array_equal(at.session_state['result_image_lab']['smooth'],before)
    # Earlier exercises no longer change this comparison's parameters.
    at.select_slider(key='image_size_a').set_value(5).run()
    at.slider(key='image_brightness').set_value(.2).run()
    assert not any('旧结果待更新，请重新运行实验' in x.value for x in at.info)
    at.selectbox(key='image_final_first').set_value(5).run()
    assert any('待更新' in x.value for x in at.info)
    assert not any(r.key=='image_final_choice_5_9' for r in at.radio)
    at.button(key='run_image_lab').click().run()
    assert at.radio(key='image_final_choice_5_9').options==['5×5 滤波结果','9×9 滤波结果']
    assert len(at.session_state['history'])==2
    assert '5×5' not in at.selectbox(key='image_final_second').options
    assert not at.exception and not at.error


def test_pixel_region_edits_feed_later_stages_and_reset(monkeypatch):
    from projects.image_lab import page, workshop
    at=app()
    assert at.button(key='image_fill_region').disabled
    assert not any(s.key in {'image_pixel_row','image_pixel_col'} for s in at.slider)
    original=at.session_state['image_pixel_edit']['array'].copy()
    # AppTest cannot send pointer events to a component; emulate its selected rectangle.
    # The actual pointer-to-Python path is checked in the browser.
    monkeypatch.setattr(workshop,'pixel_canvas',lambda image,selection,key:[1,2,5,7])
    at.run()
    assert not at.button(key='image_fill_region').disabled
    at.button(key='image_fill_region').click().run()
    edited=at.session_state['image_pixel_edit']['array']
    np.testing.assert_allclose(edited[2:7,1:5],np.broadcast_to([1,0,0],(5,4,3)))
    np.testing.assert_array_equal(edited[:2],original[:2])
    at.button(key='image_run_gray').click().run()
    np.testing.assert_allclose(at.session_state['image_stage_gray']['result'][2:7,1:5],.2126)
    at.button(key='image_undo_region').click().run()
    np.testing.assert_array_equal(at.session_state['image_pixel_edit']['array'],original)
    at.button(key='image_fill_region').click().run()
    at.button(key='image_restore_region').click().run()
    np.testing.assert_array_equal(at.session_state['image_pixel_edit']['array'],original)
    at.button(key='image_undo_region').click().run()
    assert not np.array_equal(at.session_state['image_pixel_edit']['array'],original)
    monkeypatch.setattr(workshop,'pixel_canvas',lambda image,selection,key:selection)
    at.button(key='image_reset_pixels').click().run()
    assert at.session_state['image_pixel_edit']['selection'] is None
    np.testing.assert_array_equal(at.session_state['image_pixel_edit']['array'],original)
    monkeypatch.setattr(page,'read_image',lambda _:np.full((1,1,3),.4))
    at.run()
    assert not at.exception
    at.button(key='run_image_lab').click().run()
    assert not at.exception and not at.error
    assert at.session_state['result_image_lab']['smooth'].shape==(1,1)


def test_region_bounds_single_pixel_and_original_preserved():
    from projects.image_lab.pixel_editor import normalize_selection,paint_region
    image=np.full((4,7,3),.4)
    result=paint_region(image,[6,3,7,4],[0,0,0])
    assert np.all(result[3,6]==0) and np.all(image==.4)
    assert np.count_nonzero(result!=image)==3
    assert normalize_selection(None,image.shape) is None
    for invalid in [[-1,0,2,2],[0,0,8,4],[1,1,1,2],[0,.5,2,2],[],[0,0,True,2]]:
        with pytest.raises(ValueError): normalize_selection(invalid,image.shape)


def test_real_photo_is_in_offline_package(tmp_path):
    from scripts.package import package
    from zipfile import ZipFile
    photo=ROOT/'projects/image_lab/assets/fruit-photo.jpg'
    with Image.open(photo) as im:
        assert im.size==(1280,1013)
    output=tmp_path/'lab.zip'
    package(output)
    with ZipFile(output) as archive:
        assert archive.read('ml-lab/projects/image_lab/assets/fruit-photo.jpg')==photo.read_bytes()
        assert 'ml-lab/projects/image_lab/assets/README.md' in archive.namelist()
        assert not any('/.codegraph/' in name or '/_handoffs/' in name for name in archive.namelist())
