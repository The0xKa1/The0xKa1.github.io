import ast
from types import SimpleNamespace
import numpy as np
import pytest
from streamlit.testing.v1 import AppTest
from common.runtime import ROOT,load_functions,source_path
from common.data import wine_split
from projects.wine_lab import flow
from projects.wine_lab.page import STEPS


def app():
    at=AppTest.from_file(str(ROOT/'app.py'),default_timeout=90).run()
    return at.sidebar.radio[0].set_value('03 葡萄酒研究室').run()


def step(at,n):
    # All tab bodies render, as in labs 01 and 02; select the scoped body for assertions.
    at.run()
    return at.tabs[n]
def run(at,n):return at.button(key=f'wine_flow_run_{n}').click().run()


def test_chain_uses_same_rows_features_and_sample_identity():
    dev,test,ydev,ytest=wine_split()
    cf=load_functions('wine_classification','演示');rf=load_functions('wine_regression','演示');gf=load_functions('clustering','演示')
    part=flow.split(SimpleNamespace(split_data=cf.split_data),dev,ydev,42)
    features=['alcohol','flavanoids','proline']
    c=flow.classify(SimpleNamespace(build_model=cf.build_model,evaluate=cf.evaluate),part,features,1.,3,42)
    r=flow.regress(rf,part,features)
    g=flow.group(gf,dev,features,3,42,False)
    assert r['features']==['flavanoids','proline']
    assert set(r['samples'].index)==set(part['Xv'].index)==set(c['predictions']['逻辑回归'].index)
    assert set(g['groups'].index)==set(dev.index)
    assert not set(g['groups'].index)&set(test.index)
    f=flow.final(cf,rf,c,r,'逻辑回归',dev,test,ydev,ytest)
    assert set(f['samples'].index)==set(test.index)


def test_partial_work_can_save_real_partition(isolated_exercises):
    project='wine_classification'
    tree=ast.parse(source_path(project,'演示').read_text())
    tree.body=[n for n in tree.body if not isinstance(n,ast.FunctionDef) or n.name=='split_data']
    isolated_exercises[project].write_text(ast.unparse(tree))
    at=app().sidebar.radio[1].set_value('练习').run()
    step(at,1);run(at,1)
    assert not at.exception and not at.error
    assert 1 in at.session_state['wine_flow_results']
    step(at,2);run(at,2)
    assert at.error and 2 not in at.session_state['wine_flow_results']
    isolated_exercises[project].write_text('def split_data(*a):\n    raise ValueError("保存划分错误")\n')
    step(at,1);run(at,1)
    assert any('保存划分错误' in x.value for x in at.error)
    assert 1 not in at.session_state['wine_flow_results']


def test_sequential_ui_and_invalidation():
    at=app()
    assert len(at.sidebar.radio[0].options)==7
    assert [t.label for t in at.tabs]==STEPS
    assert not any(b.key in ['wine_flow_next','wine_flow_back'] for b in at.button)
    assert not any(s.label=='本章练习' for s in at.selectbox)
    step(at,5)
    assert any('先完成或重新运行' in x.value for x in at.info)
    step(at,1)
    for n in [1,2,3,4]:
        step(at,n);run(at,n)
        assert not at.exception and not at.error,[x.value for x in at.error]
    focus=at.session_state['wine_flow_config']['focus']
    assert focus in at.session_state['wine_flow_results'][3]['result']['samples'].index
    step(at,5)
    assert not at.exception
    step(at,6);run(at,6)
    assert any(m.label=='测试分类准确率' for m in at.metric)
    step(at,0)
    at.multiselect(key='wine_flow_features').set_value(['alcohol','flavanoids']).run()
    step(at,3)
    assert any('先完成或重新运行' in x.value for x in at.info)
    step(at,6)
    assert not at.tabs[6].metric
    step(at,2);run(at,2)
    assert set(at.session_state['wine_flow_results'])=={1,2}


def test_code_change_invalidates_dependent_steps(isolated_exercises):
    for project in ['wine_classification','wine_regression','clustering']:
        isolated_exercises[project].write_text(source_path(project,'演示').read_text())
    at=app().sidebar.radio[1].set_value('练习').run()
    for n in [1,2,3,4]:step(at,n);run(at,n)
    path=isolated_exercises['wine_classification']
    path.write_text(path.read_text()+'\n# changed\n')
    step(at,5)
    assert any('先完成或重新运行' in x.value for x in at.info)
    assert not at.tabs[6].metric
