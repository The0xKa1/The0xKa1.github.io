"""python -m streamlit run app.py"""
import importlib
import streamlit as st
from common.ui import lesson, history_panel

st.set_page_config(page_title='坤坤的食品实验室', page_icon='🧪', layout='wide')
st.markdown('''<style>
.stApp {background:#fff;color:#253044}
.block-container {max-width:1160px;padding-top:2.5rem;padding-bottom:4rem}
h1 {font-size:2rem!important;letter-spacing:-.03em;font-weight:650!important}
h2 {font-size:1.4rem!important;margin-top:1.5rem!important}
h3 {font-size:1.12rem!important}
[data-testid="stSidebar"] {background:#f7f8fa;border-right:1px solid #e5e7eb}
[data-testid="stMetricValue"] {font-size:1.7rem}
.stButton button {border-radius:6px;box-shadow:none}
[data-testid="stCaptionContainer"], [data-testid="stCaptionContainer"] p {color:#566174!important}
</style>''', unsafe_allow_html=True)
PROJECTS = {
    '01 图像处理工作台': ('image_lab', '给图片加噪声，再比较滤波前后的细节。'),
    '02 分类边界擂台': ('classification_arena', '比较逻辑回归、决策树和 RBF 核方法的分类边界。'),
    '03 葡萄酒研究室': ('wine_lab', '用同一张成分表完成分类、含量预测与无监督分组。'),
    '04 图片颜色压缩': ('color_compression', '减少图片的颜色数量，比较重建图与原图。'),
    '05 手写数字识别': ('digits', '训练 MNIST 卷积网络，识别手写数字并导出模型。'),
    '06 小车送样': ('gridworld', '点击格子设置地图，训练小车绕开墙壁。'),
}
st.sidebar.title('食品实验室')
st.sidebar.caption('机器学习实践 / 六个项目')
selection = st.sidebar.radio('选择实验', ['开始与环境配置'] + list(PROJECTS))
mode = st.sidebar.radio('运行模式', ['演示', '练习'])
st.sidebar.divider()
st.sidebar.write('第一次可以先选“演示”。')
st.sidebar.caption('切到“练习”后，会运行你在 exercises.py 中保存的函数。')
if selection == '开始与环境配置':
    from pathlib import Path
    st.caption('坤坤的食品实验室 · 机器学习实践')
    st.title('机器学习实验')
    st.write('左侧有六个项目，选好后点“运行实验”。如果还不熟悉 Python 环境，下面的配置教程写了各个系统的操作步骤。')
    route,setup=st.tabs(['实验路线','环境配置 · 从零开始'])
    with route:
        for title,(_,description) in PROJECTS.items():
            st.subheader(title)
            st.write(description)
        st.info('刚接触这些内容，可以先做图像处理和分类边界。聚类学完后接着做图片压缩，能看到同一种算法的另一种用法。各实验都可以单独运行，其余的按兴趣选择。')
    with setup: st.markdown((Path(__file__).parent/'GETTING_STARTED.md').read_text())
else:
    project, subtitle = PROJECTS[selection]
    st.caption('坤坤的食品实验室 · 机器学习实践')
    st.title('小车送样' if project == 'gridworld' else selection[3:])
    st.write(subtitle)
    st.caption('正在使用参考实现' if mode == '演示' else '正在使用我的函数')
    if project == 'wine_lab':
        st.caption('各部分共用成分选择和样本划分，可以在标签页之间切换、比较结果。')
    elif project in {'gridworld', 'image_lab', 'classification_arena', 'color_compression', 'digits'}:
        st.caption(f'练习文件：projects/{project}/exercises.py。按下面的阶段阅读说明、填写函数并检查。')
    else:
        lesson(project)
    importlib.import_module(f'projects.{project}.page').render(mode)
    history_panel(project)
