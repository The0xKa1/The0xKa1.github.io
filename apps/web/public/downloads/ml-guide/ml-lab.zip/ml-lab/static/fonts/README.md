字体与笔记网站一致，来自 lxgw-wenkai-screen-webfont 1.1.0 的 LXGW WenKai Screen R。

源文件：https://cdn.jsdelivr.net/npm/lxgw-wenkai-screen-webfont@1.1.0/lxgwwenkaiscreenr.css

授权：SIL Open Font License 1.1，见 OFL.txt。
